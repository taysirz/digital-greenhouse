/* Digital Greenhouse 3.1.0 — integrated experience */
'use strict';
const $ = id => document.getElementById(id);
let backgroundDegraded = false;
function showStartupAlert(message) {
  const panel = $('startupAlert');
  if (!panel) return;
  panel.textContent = String(message || '');
  panel.classList.toggle('hidden', !message);
}
function defaultPopupState() {
  return {
    schemaVersion: 25,
    aiCompanion: { serviceAccessToken: '', enabled: false, consentAt: null, allowCloudAI: false, includeRoutineContext: false, localPageAnalysisEnabled: false, lastRunAt: null, lastAttemptAt: null, lastStatus: 'off', lastError: null, lastDecision: null, history: [], runs: [], feedback: [], memory: { totalFeedback: 0, actionStats: {}, plansGenerated: 0, plansApplied: 0 }, dailyPlan: null, planRuns: [] },
    profile: { onboardingComplete: false, dataCollection: { enabled: false, consentAt: null, consentVersion: 0, endpoint: (globalThis.DGServiceConfig?.defaultEndpoint || '') }, routineNotes: '', goalNotes: '', routineBaseline: { studyMinutesPerDay: null, exerciseDaysPerWeek: null, readingMinutesPerDay: null, sleepSchedule: null, sleepNudgesEnabled: false, primaryType: '', minutesPerDay: null }, tone: 'gentle', routineWindow: { enabled: false, label: 'Study time', start: '17:00', end: '19:00' }, dailyObjectives: ['Work toward your main goal for 20 minutes', 'Move your body or get outside', 'Make time for a hobby, reading, connection or rest'], dailyObjectiveMode: 'adaptive' },
    plant: { growthPoints: 0, health: 70, healthModelVersion: 1, growthDays: 0, qualifiedDates: [], milestones: [] },
    lifeGrowth: { objectiveCompletions: {}, activityLog: [], rewardLedger: [], activeActivity: null, dailyTimedMinutes: {}, dailyTimedMinutesByType: {}, weeklyProgressBonusDates: {}, metricBonusDates: {} },
    digitalAwareness: { remindersEnabled: true, reminderMinutes: 20, activeFocusSession: null, focusSessions: [] },
    digitalProtection: { adBlockEnabled: true, adultSiteBlockingEnabled: true, communityFilterListsEnabled: true, aiToolBlockingEnabled: false, aiContentInterruptionEnabled: true, aiContentThresholdMinutes: 5, aiToolDomains: [], customBlockedDomains: [], allowlist: [], gardenGuardEnabled: false, distractionGuardEnabled: true, distractionEnforcement: 'block', distractionThresholdMinutes: 5, distractionCooldownMinutes: 15, temporaryAutoBlocks: {}, blockedEvents: [] },
    wellbeing: { selfRating: 3, note: '' },
    browsing: { trackingEnabled: true, pointIntervalMinutes: 2, dailyNetPoints: {}, dailyMinutesByCategory: {}, dailyEffectiveProductiveMinutes: {}, tabSignals: {}, pageSignals: {}, pointEvents: [] }
  };
}
function normalizePopupState(raw) {
  const d = defaultPopupState();
  const s = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const obj = value => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const merged = { ...d, ...s };
  for (const key of ['profile','plant','lifeGrowth','digitalAwareness','digitalProtection','wellbeing','browsing','aiCompanion']) merged[key] = { ...d[key], ...obj(s[key]) };
  merged.aiCompanion.memory = { ...d.aiCompanion.memory, ...obj(merged.aiCompanion.memory) };
  merged.profile.routineWindow = { ...d.profile.routineWindow, ...obj(merged.profile.routineWindow) };
  merged.profile.routineBaseline = { studyMinutesPerDay: null, exerciseDaysPerWeek: null, readingMinutesPerDay: null, sleepSchedule: null, sleepNudgesEnabled: false, primaryType: '', minutesPerDay: null, ...obj(merged.profile.routineBaseline) };
  const rb = merged.profile.routineBaseline;
  if (!['studying','exercise','reading','hobby','social','rest','hydration','coding','writing','creative','chores','custom'].includes(rb.primaryType)) rb.primaryType = '';
  const normaliseMinutes = value => value === null || value === '' || value === undefined || !Number.isFinite(Number(value)) ? null : Math.max(0, Math.min(480, Math.round(Number(value))));
  rb.studyMinutesPerDay = normaliseMinutes(rb.studyMinutesPerDay);
  rb.readingMinutesPerDay = normaliseMinutes(rb.readingMinutesPerDay);
  rb.exerciseDaysPerWeek = rb.exerciseDaysPerWeek === null || rb.exerciseDaysPerWeek === '' || rb.exerciseDaysPerWeek === undefined || !Number.isFinite(Number(rb.exerciseDaysPerWeek)) ? null : Math.max(0, Math.min(7, Math.round(Number(rb.exerciseDaysPerWeek))));
  rb.sleepNudgesEnabled = rb.sleepNudgesEnabled === true;
  const sleep = obj(rb.sleepSchedule);
  const bedtime = /^\d{2}:\d{2}$/.test(sleep.bedtime || '') ? sleep.bedtime : '';
  const wakeTime = /^\d{2}:\d{2}$/.test(sleep.wakeTime || '') ? sleep.wakeTime : '';
  rb.sleepSchedule = bedtime || wakeTime ? { bedtime: bedtime || null, wakeTime: wakeTime || null } : null;
  rb.minutesPerDay = !rb.primaryType ? null : normaliseMinutes(rb.minutesPerDay);
  merged.lifeGrowth.dailyTimedMinutes = obj(merged.lifeGrowth.dailyTimedMinutes); merged.lifeGrowth.dailyTimedMinutesByType = obj(merged.lifeGrowth.dailyTimedMinutesByType); merged.lifeGrowth.weeklyProgressBonusDates = obj(merged.lifeGrowth.weeklyProgressBonusDates); merged.lifeGrowth.metricBonusDates = obj(merged.lifeGrowth.metricBonusDates);
  merged.browsing.dailyEffectiveProductiveMinutes = obj(merged.browsing.dailyEffectiveProductiveMinutes);
  if (!Array.isArray(merged.profile.dailyObjectives) || merged.profile.dailyObjectives.length !== 3) merged.profile.dailyObjectives = d.profile.dailyObjectives;
  // Resolve migrations from the raw persisted mode/objective labels so default merge values
  // cannot silently hide a user's previously customised priorities.
  merged.profile.dailyObjectiveMode = globalThis.DGGrowth?.resolveDailyObjectiveMode
    ? globalThis.DGGrowth.resolveDailyObjectiveMode(obj(s.profile).dailyObjectiveMode, merged.profile.dailyObjectives, d.profile.dailyObjectives)
    : (['adaptive','custom'].includes(obj(s.profile).dailyObjectiveMode) ? obj(s.profile).dailyObjectiveMode : (merged.profile.dailyObjectives.every((label, i) => String(label || '').trim() === d.profile.dailyObjectives[i]) ? 'adaptive' : 'custom'));
  if (!Array.isArray(merged.plant.qualifiedDates)) merged.plant.qualifiedDates = [];
  merged.lifeGrowth.objectiveCompletions = obj(merged.lifeGrowth.objectiveCompletions);
  for (const key of ['dailyNetPoints','dailyMinutesByCategory','tabSignals','pageSignals']) merged.browsing[key] = obj(merged.browsing[key]);
  if (!Array.isArray(merged.browsing.pointEvents)) merged.browsing.pointEvents = [];
  for (const key of ['customBlockedDomains','allowlist','aiToolDomains']) if (!Array.isArray(merged.digitalProtection[key])) merged.digitalProtection[key] = [];
  return merged;
}
const DAY = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const DEFAULT_OBJECTIVES = ['Work toward your main goal for 20 minutes','Move your body or get outside','Make time for a hobby, reading, connection or rest'];
const dirtySettingsGroups = new Set();
const settingGroupIds = {
  profile: ['routineNotes','goalNotes','coachTone','objective1','objective2','objective3','dailyObjectiveMode','routineBaselineType','routineBaselineMinutes','routineStudyMinutes','routineExerciseDays','routineReadingMinutes','routineSleepBedtime','routineSleepWake','routineSleepNudges','routineWindowEnabled','routineWindowLabel','routineWindowStart','routineWindowEnd'],
  protection: ['adBlockEnabled','adultBlocking','communityFiltersEnabled','gardenGuard','distractionGuard','aiToolBlocking','aiContentInterruption','aiContentThresholdMinutes','distractionEnforcement','distractionThresholdMinutes','distractionCooldownMinutes','blockedDomains','allowlistDomains','aiToolDomains'],
  tracking: ['pointInterval','trackingEnabled'],
  focus: ['remindersEnabled','reminderMinutes'],
  collection: ['sharingConsent'],
  agent: ['agentEnabled','agentAutoFocus']
};
const settingGroupById = Object.fromEntries(Object.entries(settingGroupIds).flatMap(([group,ids])=>ids.map(id=>[id,group])));
function hasCurrentDataConsent(state) { const dc = state?.profile?.dataCollection || {}; return Boolean(dc.enabled === true && dc.consentAt && Number(dc.consentVersion) === Number(window.DGData?.CONSENT_VERSION || 5)); }
function markSettingsDirty(event) {
  const target = event?.target;
  if (!target) return;
  const group = target.classList?.contains('routine-window-day') ? 'profile' : settingGroupById[target.id];
  if (group) dirtySettingsGroups.add(group);
}
function clearSettingsDirty(group) { dirtySettingsGroups.delete(group); }
document.addEventListener('input', markSettingsDirty, true);
document.addEventListener('change', markSettingsDirty, true);
const DEFAULT_AI_TOOLS = ['chatgpt.com','gemini.google.com','claude.ai','perplexity.ai','copilot.microsoft.com','poe.com','character.ai','deepseek.com','meta.ai'];
let currentState = null, selectedDuration = 50, toastTimer = null;
function send(message){ return chrome.runtime.sendMessage(message); }
async function getState(){
  let messageError = null;
  try {
    const r = await send({type:'DG_GET_STATE'});
    if (r?.ok && r.state && typeof r.state === 'object') {
      backgroundDegraded = false;
      return normalizePopupState(r.state);
    }
    messageError = new Error(r?.error || 'The background worker returned no saved state.');
  } catch (error) { messageError = error; }
  // The popup should remain usable as a view even if Chrome's service worker briefly
  // fails to answer. Read the saved local snapshot before falling back to safe defaults.
  try {
    const stored = await chrome.storage.local.get('dgState');
    if (stored?.dgState && typeof stored.dgState === 'object') {
      backgroundDegraded = true;
      return normalizePopupState(stored.dgState);
    }
  } catch (storageError) { messageError ||= storageError; }
  backgroundDegraded = true;
  console.warn('Digital Greenhouse is using popup fallback state:', messageError);
  return normalizePopupState(defaultPopupState());
}
function toast(message, bad=false){ const el=$('toast'); el.textContent=message;el.style.background=bad?'#8e4536':'#1f452f';el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2800); }
function dateEventPoints(s){return Number(s?.browsing?.dailyNetPoints?.[DAY()]||0);}
function plantStage(s){
  const days=Math.max(0,Number(s?.plant?.growthDays??s?.plant?.qualifiedDates?.length)||0);
  const stages=[{min:0,name:'Seedling',emoji:'🌱',next:7},{min:7,name:'Sprout',emoji:'🌿',next:30},{min:30,name:'Growing plant',emoji:'🪴',next:90},{min:90,name:'Established plant',emoji:'🌷',next:180},{min:180,name:'Sapling',emoji:'🌳',next:365},{min:365,name:'Young tree',emoji:'🌲',next:730},{min:730,name:'Flourishing tree',emoji:'🌳',next:null}];
  const stage=[...stages].reverse().find(x=>days>=x.min)||stages[0];let percent=100,desc='A steady start';
  if(stage.next){percent=Math.max(0,Math.min(100,((days-stage.min)/(stage.next-stage.min))*100));desc=`${days} of ${stage.next} growth days`;}
  else desc='Two years of qualifying growth';
  let emoji=stage.emoji;if(Number(s?.plant?.health??100)<25)emoji='🥀';else if(Number(s?.plant?.health??100)<45)emoji='🌾';
  return {...stage,days,percent,desc,displayEmoji:emoji};
}
function activeFocus(s){const x=s?.digitalAwareness?.activeFocusSession;return x&&Date.now()<Date.parse(x.endsAt)?x:null;}
function domainOf(url){try{return new URL(url).hostname.toLowerCase().replace(/^www\./,'');}catch{return '';}}
function inferredSignal(s, domain){const tabSignals=Object.values(s?.browsing?.tabSignals||{});return tabSignals.find(x=>x?.domain===domain)||s?.browsing?.pageSignals?.[domain]||null;}
async function currentTab(){
  try {
    if (document.documentElement.classList.contains('dashboard-mode') || document.documentElement.classList.contains('miniapp-tab-mode')) {
      const sourceId = Number(new URLSearchParams(location.search).get('sourceTabId'));
      if (Number.isInteger(sourceId) && sourceId > 0) {
        try { const source = await chrome.tabs.get(sourceId); if (/^https?:\/\//i.test(source?.url || '')) return source; } catch {}
      }
      const all = await chrome.tabs.query({ currentWindow: true });
      return [...(all || [])].reverse().find(t => /^https?:\/\//i.test(t?.url || '')) || null;
    }
    const tabs=await chrome.tabs.query({active:true,currentWindow:true});return tabs?.[0]||null;
  } catch{return null;}
}
function renderDashboardDetails(s){
  const host=$('dashboardOverview'); if(!host) return;
  const today=DAY(), b=s.browsing||{}, minutes=(category,date=today)=>Math.max(0,Number(b.dailyMinutesByCategory?.[`${date}:${category}`])||0);
  const points=Number(s.plant?.growthPoints)||0, net=Number(b.dailyNetPoints?.[today]||0);
  const active=Number(b.dailyActiveMinutes?.[today]||0), productive=minutes('productive'), distracting=minutes('distracting');
  const focus=s.digitalAwareness?.activeFocusSession&&Date.now()<Date.parse(s.digitalAwareness.activeFocusSession.endsAt)?s.digitalAwareness.activeFocusSession:null;
  const recentFocus=(s.digitalAwareness?.focusSessions||[]).filter(x=>Date.parse(x.endedAt||x.startedAt||0)>=Date.now()-7*86400000);
  const put=(id,value)=>{const el=$(id);if(el)el.textContent=String(value);};
  put('dashPoints',points.toLocaleString());put('dashTodayNet',`${net>0?'+':''}${net} points today`);put('dashActiveMinutes',`${active}m`);put('dashProductiveMinutes',`${productive}m`);put('dashDistractingMinutes',`${distracting}m`);put('dashFocusSummary',focus?`Active · ${Math.max(0,Math.ceil((Date.parse(focus.endsAt)-Date.now())/60000))}m left`:`${recentFocus.length} sessions this week`);
  const activity=$('dashboardActivityFeed'); if(activity){activity.replaceChildren();const events=[...(b.pointEvents||[])].filter(x=>x&&x.createdAt).sort((a,c)=>Date.parse(c.createdAt)-Date.parse(a.createdAt)).slice(0,7);if(!events.length){const empty=document.createElement('p');empty.className='dashboard-empty';empty.textContent='Your activity history will appear here as the greenhouse records progress.';activity.append(empty);} else for(const ev of events){const row=document.createElement('div');row.className='dashboard-feed-row';const main=document.createElement('div');const title=document.createElement('b');title.textContent=String(ev.label||'Progress update').slice(0,120);const meta=document.createElement('small');meta.textContent=`${new Date(ev.createdAt).toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}${ev.domain?` · ${String(ev.domain).slice(0,80)}`:''}`;main.append(title,meta);const score=document.createElement('strong');const delta=Number(ev.points)||0;score.className=delta<0?'negative':'positive';score.textContent=`${delta>0?'+':''}${delta}`;row.append(main,score);activity.append(row);}}
  const agent=$('dashboardAgentFeed'); if(agent){agent.replaceChildren();const history=[...(s.aiCompanion?.history||[])].sort((a,c)=>Date.parse(c.createdAt||0)-Date.parse(a.createdAt||0)).slice(0,5);if(!history.length){const empty=document.createElement('p');empty.className='dashboard-empty';empty.textContent='Your AI notes will appear here after the brain makes its first decision.';agent.append(empty);}else for(const item of history){const card=document.createElement('article');card.className='dashboard-agent-row';const title=document.createElement('b');title.textContent=String(item.title||item.action||'Greenhouse decision').slice(0,130);const message=document.createElement('p');message.textContent=String(item.message||'').slice(0,280);card.append(title,message);if(item.reason||(Number(item.confidence)>0)){const why=document.createElement('small');why.textContent=`${Number(item.confidence)>0?`Model confidence estimate: ${Math.round(Math.max(0,Math.min(1,Number(item.confidence)))*100)}%. `:''}${item.reason?`Reason: ${String(item.reason).slice(0,180)}`:''}`;card.append(why);}const meta=document.createElement('small');meta.textContent=`${item.createdAt?new Date(item.createdAt).toLocaleString():''}${item.feedback?` · ${item.feedback.replace('_',' ')}`:''}${item.preview?' · preview':''}`;card.append(meta);agent.append(card);}}
  const chart=$('dashboardWeekChart');if(chart){chart.replaceChildren();const days=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;days.push({key,label:d.toLocaleDateString([], {weekday:'short'}),productive:minutes('productive',key),distracting:minutes('distracting',key)});}const max=Math.max(15,...days.flatMap(d=>[d.productive,d.distracting]));for(const day of days){const col=document.createElement('div');col.className='dashboard-day';const bars=document.createElement('div');bars.className='dashboard-bars';const pbar=document.createElement('span');pbar.className='productive-bar';pbar.style.height=`${Math.max(day.productive?4:1,day.productive/max*100)}%`;pbar.title=`${day.productive} productive minutes`;const dbar=document.createElement('span');dbar.className='distracting-bar';dbar.style.height=`${Math.max(day.distracting?4:1,day.distracting/max*100)}%`;dbar.title=`${day.distracting} distracting minutes`;bars.append(pbar,dbar);const label=document.createElement('small');label.textContent=day.label;col.append(bars,label);chart.append(col);}}
}

function renderRoutineStep(s) {
  const card = $('routineStepCard'), message = $('routineStepMessage');
  if (!card || !message) return;
  const engine = globalThis.DGGrowth;
  if (!engine || typeof engine.suggestNextRoutineStep !== 'function') {
    message.textContent = 'Choose a starting routine in Setup and Greenhouse will suggest a gentle next step.';
    return;
  }
  const suggestion = engine.suggestNextRoutineStep(s);
  message.textContent = suggestion.message;
  card.dataset.routineStatus = suggestion.ready ? (suggestion.readyToIncrease ? 'ready-to-grow' : 'steady') : suggestion.reason;
}
function renderObjectives(s){
  const list=$('objectives'); if(!list)return; list.replaceChildren();
  const engine=globalThis.DGGrowth;
  const tasks=engine&&typeof engine.buildDailyObjectives==='function'
    ? engine.buildDailyObjectives(s,new Date())
    : (Array.isArray(s.profile?.dailyObjectives)?s.profile.dailyObjectives:DEFAULT_OBJECTIVES).map((label,i)=>({key:`objective-${i+1}`,label,type:'custom',targetMinutes:10,icon:['🌱','🌤️','🎨'][i]}));
  const claims=s.lifeGrowth?.objectiveCompletions?.[DAY()]||{};
  for(const task of tasks){
    const id=task.key, done=claims[id];
    const display=engine?.objectiveDisplayTask?engine.objectiveDisplayTask(task,done):{...task,label:done?.label||task.label,type:done?.type||task.type,targetMinutes:done?.targetMinutes??task.targetMinutes,icon:done?'✓':task.icon,completed:Boolean(done),points:Number(done?.points)||0};
    const button=document.createElement('button');button.type='button';button.className='objective'+(done?' done':'');button.disabled=Boolean(done);
    const icon=document.createElement('span');icon.className='task-icon';icon.textContent=done?'✓':display.icon||'🌱';
    const text=document.createElement('span');text.className='task-text';
    const title=document.createElement('b');title.textContent=String(display.label||'A small step').slice(0,100);
    const meta=document.createElement('small');
    meta.textContent=done
      ? `Completed today · ${done.completedAt?new Date(done.completedAt).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'}):'saved'}`
      : Number(display.targetMinutes)>=5 ? `${Math.max(5,Math.min(180,Number(display.targetMinutes)))} min target · optional, at your pace` : 'A quick step · optional, at your pace';
    text.append(title,meta);
    const award=document.createElement('span');award.className='task-award';award.textContent=done?`+${Number(done.points)||0} earned`:'Complete · +5 base';
    button.append(icon,text,award);
    button.addEventListener('click',async()=>{
      button.disabled=true;
      try{
        const result=await send({type:'DG_COMPLETE_OBJECTIVE',key:id,activityType:task.type||'custom',label:task.label,objectiveMode:task.mode||'custom',targetMinutes:task.targetMinutes});
        if(!result?.ok)throw new Error(result?.error||'Could not record the step.');
        currentState=result.state||await getState();render(currentState);
        const earned=Number(result.completion?.points)||0;
        toast(result.alreadyComplete?'Already counted today.':earned?`Nice step. +${earned} points 🌱`:'Step saved. Today’s reward limit has been reached.');
      }catch(e){button.disabled=false;toast(e.message,true);}
    });
    list.append(button);
  }
}

function render(s){
  if(!s)return;
  try { renderView(normalizePopupState(s)); }
  catch (error) {
    console.error('Digital Greenhouse popup render failed:', error);
    showStartupAlert(`The mini app could not render its saved state (${error?.message || 'unknown error'}). Your local data has not been erased. Reload the extension from chrome://extensions and reopen it.`);
  }
}
function renderActivityTimer(s) {
  const activity = s.lifeGrowth?.activeActivity;
  const focus = activeFocus(s);
  const active = activity && ['running','paused'].includes(activity.status) ? activity : null;
  const elapsed = active ? Math.max(0, Number(activity.accumulatedSeconds)||0) + (activity.status === 'running' && activity.lastResumedAt ? Math.max(0, Math.min(4*3600, (Date.now()-Date.parse(activity.lastResumedAt))/1000)) : 0) : 0;
  const minutes = Math.floor(elapsed/60);
  const status = $('activityTimerStatus');
  if (status) status.textContent = !active ? (focus ? 'Focus is active. The activity timer is paused so it cannot earn growth during Focus.' : "No activity running. Start only when you are ready; time-based rewards diminish and share a daily cap.") : `${activity.label || activity.type} · ${minutes} active minute${minutes===1?'':'s'} · ${activity.status==='paused'?'paused':'running'}${activity.pauseReason==='focus-started'?' · paused by Focus':''}. Finish when done to record duration-based growth.`;
  const show = (id, visible) => { const el=$(id); if(el) el.classList.toggle('hidden', !visible); };
  show('startActivityTimer', !active); show('pauseActivityTimer', Boolean(active && activity.status==='running')); show('resumeActivityTimer', Boolean(active && activity.status==='paused')); show('finishActivityTimer', Boolean(active));
  const type = $('activityType'), label = $('activityLabel');
  if (type) type.disabled = Boolean(active);
  if (label) label.disabled = Boolean(active);
  if (type && !active && document.activeElement !== type && !type.dataset.userSelected) type.value = 'studying';
  if (label && !active && document.activeElement !== label) label.value = '';
  const metricWrap = $('activityMetric'), quantity = $('activityQuantity'), quantityUnit = $('activityQuantityUnit');
  if (metricWrap) metricWrap.classList.toggle('hidden', type?.value !== 'exercise');
  if (quantity) quantity.disabled = !active;
  if (quantityUnit) quantityUnit.disabled = !active;
  if (!active && quantity && document.activeElement !== quantity) quantity.value = '';
  if (!active && quantityUnit && document.activeElement !== quantityUnit) quantityUnit.value = 'reps';
  if (focus) show('startActivityTimer', false);
}
async function activityTimerAction(action) {
  const map = { start:'DG_ACTIVITY_START', pause:'DG_ACTIVITY_PAUSE', resume:'DG_ACTIVITY_RESUME', finish:'DG_ACTIVITY_FINISH' };
  const message = { type: map[action] };
  if (action === 'start') { message.activityType = $('activityType')?.value || 'studying'; message.label = $('activityLabel')?.value || ''; }
  if (action === 'finish' && currentState?.lifeGrowth?.activeActivity?.type === 'exercise') {
    const amount = String($('activityQuantity')?.value || '').trim();
    if (amount) { message.quantityValue = Number(amount); message.quantityUnit = $('activityQuantityUnit')?.value || 'reps'; }
  }
  const result = await send(message);
  if (!result?.ok) throw new Error(result?.error || 'Could not update the activity timer.');
  currentState = result.state || await getState(); render(currentState);
  if (action === 'finish') {
    const activity = result.activity || {};
    const metricBonus = Math.max(0, Number(activity.pointBreakdown?.metricProgressBonus) || 0);
    const measured = Number(activity.quantityValue) > 0 && activity.quantityUnit
      ? ` · ${activity.label || 'Exercise'}: ${Number(activity.quantityValue).toLocaleString()} ${activity.quantityUnit}` : '';
    const breakdownLabels={basePoints:'effort',progressBonus:'personal progress',goalBonus:'goal match',varietyBonus:'variety',weeklyConsistencyBonus:'consistency',metricProgressBonus:'measured progress'};
    const breakdown=Object.entries(activity.pointBreakdown||{}).filter(([key,value])=>breakdownLabels[key]&&Number(value)>0).map(([key,value])=>`${breakdownLabels[key]} +${Number(value)}`).join(' · ');
    toast(`Activity saved${measured} · ${activity.actualMinutes || 0} minutes · +${result.points || 0} points${breakdown ? ` (${breakdown})` : ''} 🌱`);
  }
  else toast(action === 'start' ? 'Activity timer started.' : action === 'pause' ? 'Activity timer paused.' : 'Activity timer resumed.');
}
function renderView(s){
  currentState=s;
  const stage=plantStage(s);const pts=Number(s.plant?.growthPoints)||0;const health=Math.round(Number(s.plant?.health??100));
  $('plantEmoji').textContent=stage.displayEmoji;$('plantStage').textContent=stage.name;$('points').textContent=pts>0?`+${pts}`:String(pts);$('healthLabel').textContent=health<25?'Needs gentle care':health<45?'Taking a slow patch':'Growing at your pace';$('plantMeta').textContent=`${stage.days} qualifying growth ${stage.days===1?'day':'days'}`;$('growthBar').style.width=`${stage.percent}%`;$('growthProgressText').textContent=stage.next?`${Math.max(0,stage.next-stage.days)} growth days to next stage`:'Your long-term tree stage is here';$('healthValue').textContent=`${health}% health`;
  const net=dateEventPoints(s);$('todayNet').textContent=`${net>0?'+':''}${net} today`;$('todayNet').style.color=net<0?'#a35239':'#406649';
  const profile=s.profile||{};const firstName=String(profile.displayName||'').trim().split(/\s+/)[0];$('greeting').textContent=firstName?`Welcome back, ${firstName}.`:'Every plant starts somewhere.';$('onboardingBanner').classList.toggle('hidden',Boolean(profile.onboardingComplete));
  const focus=activeFocus(s);$('trackingChip').textContent=focus?'Focus active':s.browsing?.trackingEnabled===false?'Tracking paused':'Observing';$('trackingChip').className='chip '+(focus?'active':s.browsing?.trackingEnabled===false?'neutral':'');
  const currentDomain=window._currentDomain||'';const signal=currentDomain?inferredSignal(s,currentDomain):null;const category=signal&&['productive','distracting','neutral'].includes(signal.category)?signal.category:'neutral';$('currentDomain').textContent=currentDomain||'Browser start page';$('currentCategory').textContent=category==='productive'?'Helpful page':category==='distracting'?'Possible distraction':'Still learning';$('currentCategory').className=`category ${category}`;$('siteDot').style.background=category==='productive'?'#5b9c5e':category==='distracting'?'#c4785b':'#a8b5a5';const correction=s.browsing?.pageCorrections?.[currentDomain];$('siteHelp').textContent=correction?`You marked this site ${correction.category==='productive'?'useful':correction.category==='distracting'?'distracting':'neutral'}. This correction stays on this device and overrides automatic classification.`:signal?`${Math.round((Number(signal.confidence)||0)*100)}% confidence · page assessment stays on this device; unclear pages stay neutral.`:'Open a regular webpage to see its local page assessment.';['markPageUseful','markPageDistracting','resetPageCategory','allowCurrentFocus'].forEach(id=>{const el=$(id);if(el)el.disabled=!currentDomain||!window._currentTabId;});
  renderObjectives(s);renderRoutineStep(s);renderActivityTimer(s);renderFocus(s);renderProtection(s);renderSettings(s);renderCollectionSettings(s);renderAgent(s);renderDashboardDetails(s);
  if (backgroundDegraded) showStartupAlert('Greenhouse opened in safe view mode because the background worker did not respond. Your saved data is being displayed locally, but actions may need an extension reload.');
  else showStartupAlert('');
}
function renderFocus(s){const f=activeFocus(s);$('focusStatus').textContent=f?(f.integrityLock?'Garden Guard is locked 🔒':'Strict Focus is active 🔒'):'Ready when you are';$('focusDescription').textContent=f?`Locked until ${new Date(f.endsAt).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}. No early exit inside the extension. Points pause; scheduled wellbeing prompts still work on allowed pages.`:'Default session: 50 minutes. Review your allowlist before starting; Focus cannot stop Chrome itself being disabled.';$('startFocus').classList.toggle('hidden',Boolean(f));$('endFocus').classList.toggle('hidden',!f || f.strict===true);$('durationOptions').querySelectorAll('button').forEach(b=>{b.disabled=Boolean(f);b.classList.toggle('selected',Number(b.dataset.duration)===selectedDuration);});if(!dirtySettingsGroups.has('focus')){$('remindersEnabled').checked=s.wellbeing?.remindersEnabled!==false;$('reminderMinutes').value='20';}}
function renderProtection(s){
  const p=s.digitalProtection||{};
  if(!dirtySettingsGroups.has('protection')){
    for(const [id,val] of [['adBlockEnabled',p.adBlockEnabled!==false],['adultBlocking',Boolean(p.adultSiteBlockingEnabled)],['communityFiltersEnabled',p.communityFilterListsEnabled!==false],['gardenGuard',Boolean(p.gardenGuardEnabled)],['distractionGuard',p.distractionGuardEnabled!==false],['aiToolBlocking',Boolean(p.aiToolBlockingEnabled)],['aiContentInterruption',Boolean(p.aiContentInterruptionEnabled)]]){const el=$(id);if(el&&document.activeElement!==el)el.checked=val;}
    for(const [id,val] of [['blockedDomains',(p.customBlockedDomains||[]).join('\n')],['allowlistDomains',(p.allowlist||[]).join('\n')],['aiToolDomains',(p.aiToolDomains||DEFAULT_AI_TOOLS).join('\n')]])if(document.activeElement!==$(id))$(id).value=val;
    for(const [id,val] of [['distractionEnforcement',p.distractionEnforcement==='remind'?'remind':'block'],['distractionThresholdMinutes',String([3,5,8,10,15].includes(Number(p.distractionThresholdMinutes))?Number(p.distractionThresholdMinutes):5)],['distractionCooldownMinutes',String([5,10,15,30,60].includes(Number(p.distractionCooldownMinutes))?Number(p.distractionCooldownMinutes):15)],['aiContentThresholdMinutes',String([3,5,10,15].includes(Number(p.aiContentThresholdMinutes))?Number(p.aiContentThresholdMinutes):5)]])if($(id)&&document.activeElement!==$(id))$(id).value=val;
  }
  const now=Date.now(),events=Array.isArray(p.blockedEvents)?p.blockedEvents:[],today=new Date().toDateString(),todayCount=events.filter(e=>new Date(e.at||0).toDateString()===today).reduce((sum,e)=>sum+(Number(e.attempts)||1),0),active=Object.values(p.temporaryAutoBlocks||{}).filter(x=>Number(x?.expiresAt??x)>now).length;
  const status=$('protectionStatus');if(status)status.textContent=`${todayCount} blocked attempt${todayCount===1?'':'s'} today · ${active} temporary distraction stop${active===1?'':'s'} active. Feed/short-video pages are timed from active scrolling; other distractions use the selected threshold.`;const filterStatus=$('communityFilterStatus');if(filterStatus){const cs=p.communityFilterStatus||{};const stamp=cs.updatedAt&&Number.isFinite(Date.parse(cs.updatedAt))?new Date(cs.updatedAt).toLocaleString():null;filterStatus.textContent=p.communityFilterListsEnabled===false?'Community lists are disabled. Bundled offline rules remain available.':stamp?`Last successful update: ${stamp} · ${Number(cs.adDomains)||0} ad/tracker domains · ${Number(cs.adultDomains)||0} adult domains.${cs.lastError?` Partial update: ${String(cs.lastError).slice(0,140)}`:''}`:cs.lastError?`Community lists have not updated yet: ${String(cs.lastError).slice(0,180)} Bundled rules remain active.`:'Community lists are enabled; they update automatically when online. Click “Update community lists now” to fetch them immediately.';}
}
function renderSettings(s){
  const p=s.profile||{};
  const storedObjectives=Array.isArray(p.dailyObjectives)&&p.dailyObjectives.length===3?p.dailyObjectives:DEFAULT_OBJECTIVES;
  const storedMode=['adaptive','custom'].includes(p.dailyObjectiveMode)?p.dailyObjectiveMode:(storedObjectives.every((label,i)=>String(label||'').trim()===DEFAULT_OBJECTIVES[i])?'adaptive':'custom');
  if(!dirtySettingsGroups.has('profile')){
    const rb=p.routineBaseline||{};
    const vals=[['routineBaselineType',['studying','exercise','reading','hobby','social','rest','hydration','coding','writing','creative','chores','custom'].includes(rb.primaryType)?rb.primaryType:''],['routineBaselineMinutes',rb.minutesPerDay===null||rb.minutesPerDay===undefined?'':String(rb.minutesPerDay)],['routineStudyMinutes',rb.studyMinutesPerDay===null||rb.studyMinutesPerDay===undefined?'':String(rb.studyMinutesPerDay)],['routineExerciseDays',rb.exerciseDaysPerWeek===null||rb.exerciseDaysPerWeek===undefined?'':String(rb.exerciseDaysPerWeek)],['routineReadingMinutes',rb.readingMinutesPerDay===null||rb.readingMinutesPerDay===undefined?'':String(rb.readingMinutesPerDay)],['routineSleepBedtime',rb.sleepSchedule?.bedtime||''],['routineSleepWake',rb.sleepSchedule?.wakeTime||'']];
    for(const [id,val] of vals)if(document.activeElement!==$(id)&&$(id))$(id).value=val;
    if($('routineSleepNudges')&&document.activeElement!==$('routineSleepNudges'))$('routineSleepNudges').checked=rb.sleepNudgesEnabled===true;
    for(const [id,val] of [['routineNotes',p.routineNotes||''],['goalNotes',p.goalNotes||''],['coachTone',['gentle','playful','direct'].includes(p.tone)?p.tone:'gentle']])if(document.activeElement!==$(id))$(id).value=val;
    ['objective1','objective2','objective3'].forEach((id,i)=>{if(document.activeElement!==$(id))$(id).value=storedObjectives[i]||DEFAULT_OBJECTIVES[i];});
    if($('dailyObjectiveMode')&&document.activeElement!==$('dailyObjectiveMode'))$('dailyObjectiveMode').value=storedMode;
    if($('routineWindowEnabled')&&document.activeElement!==$('routineWindowEnabled'))$('routineWindowEnabled').checked=Boolean(p.routineWindow?.enabled);
    if($('routineWindowLabel')&&document.activeElement!==$('routineWindowLabel'))$('routineWindowLabel').value=String(p.routineWindow?.label||'Study time');
    if($('routineWindowStart')&&document.activeElement!==$('routineWindowStart'))$('routineWindowStart').value=/^\d{2}:\d{2}$/.test(p.routineWindow?.start||'')?p.routineWindow.start:'17:00';
    if($('routineWindowEnd')&&document.activeElement!==$('routineWindowEnd'))$('routineWindowEnd').value=/^\d{2}:\d{2}$/.test(p.routineWindow?.end||'')?p.routineWindow.end:'19:00';
    for(const box of document.querySelectorAll('.routine-window-day'))if(document.activeElement!==box){const days=Array.isArray(p.routineWindow?.days)?p.routineWindow.days:[1,2,3,4,5,6,0];box.checked=days.includes(Number(box.value));}
  }
  const shownMode=dirtySettingsGroups.has('profile')?($('dailyObjectiveMode')?.value||storedMode):storedMode;
  if($('customObjectiveEditor'))$('customObjectiveEditor').classList.toggle('hidden',shownMode!=='custom');
  if(!dirtySettingsGroups.has('tracking')){
    if(document.activeElement!==$('pointInterval'))$('pointInterval').value=String(Number(s.browsing?.pointIntervalMinutes)||2);
    if(document.activeElement!==$('trackingEnabled'))$('trackingEnabled').checked=s.browsing?.trackingEnabled!==false;
  }
}
function renderCollectionSettings(s){
  const dc=s.profile?.dataCollection||{}, consent=hasCurrentDataConsent(s);
  if(!dirtySettingsGroups.has('collection') && document.activeElement!==$('sharingConsent')) $('sharingConsent').checked=consent;
  const status=$('collectionStatus');
  const endpoint=String(dc.endpoint||window.DGServiceConfig?.defaultEndpoint||'').trim();
  let msg='Sharing is off. Your Greenhouse data stays on this device.',bad=false;
  if(consent && !endpoint){msg='Consent saved, but the publisher has not connected the hosted service yet. Nothing has been uploaded.';bad=true;}
  else if(consent && dc.lastSyncError){msg=`Sharing is on, but the last upload failed: ${String(dc.lastSyncError).slice(0,180)}. Greenhouse will retry automatically.`;bad=true;}
  else if(consent && dc.lastSyncedAt){msg=`Sharing is on · last successful upload ${new Date(dc.lastSyncedAt).toLocaleString()}.`;}
  else if(consent){msg='Consent saved. The first full-data upload is starting automatically.';}
  else if(dc.everEnabled && dc.consentRevokedAt && !dc.remoteRevocationConfirmedAt) { msg='Sharing is off on this device. The server stop request will retry when the service reconnects; earlier records remain until deletion.'; bad=true; }
  else if(dc.everEnabled) msg='Sharing is off. No new uploads will be sent; earlier server data remains until you request deletion.';
  status.textContent=msg;status.classList.toggle('error',bad);
  if($('downloadServerData'))$('downloadServerData').disabled=!(dc.everEnabled||dc.enabled);
  if($('deleteRemoteData'))$('deleteRemoteData').disabled=!(dc.everEnabled||dc.enabled);
  
}
function renderAgent(s) {
  const a = s.aiCompanion || {};
  const setChecked = (id, value) => { const el=$(id); if (el && document.activeElement !== el) el.checked = Boolean(value); };
  if(!dirtySettingsGroups.has('agent')) {
    setChecked('agentEnabled', a.enabled);
    setChecked('agentAutoFocus', a.autoStartFocusOnDistraction);
  }
  const pageAIStatus = $('pageAIConsentStatus'); if (pageAIStatus) pageAIStatus.textContent = a.enabled && a.consentAt && a.fullContextConsentAt && Number(a.fullContextConsentVersion) >= 2 && a.localPageAnalysisEnabled ? ((window.DGServiceConfig?.mode === 'hosted' && hasCurrentDataConsent(s)) || a.allowCloudAI ? 'Page understanding is on · Greenhouse AI is connected through your Setup choice.' : 'Page understanding is on · local AI only.') : 'Page understanding is part of the AI Brain. Local rules remain active when it is off.';
  const label = $('agentStatusLabel');
  label.textContent = !a.enabled ? 'Off — waiting for you' : a.lastStatus === 'thinking' ? 'Thinking through your recent pattern…' : a.lastStatus === 'acted' ? 'Active — last decision took action' : a.lastStatus === 'observed-no-action' ? 'Active — last check chose not to interrupt' : a.lastStatus === 'error' ? 'Needs attention — see status below' : 'Enabled — monitoring patterns locally';
  const dataConsent = hasCurrentDataConsent(s);
  const brainReady = Boolean(dataConsent && a.enabled && a.consentAt && a.fullContextConsentAt && Number(a.fullContextConsentVersion) >= 2);
  if ($('coachConsentGate')) $('coachConsentGate').classList.toggle('hidden', dataConsent);
  if ($('coachControls')) $('coachControls').classList.toggle('hidden', !dataConsent);
  if ($('agentEnabled')) $('agentEnabled').disabled = !dataConsent;
  // Hosted AI permission follows the single all-or-nothing sharing consent.
  if ($('agentAutoFocus')) $('agentAutoFocus').disabled = !dataConsent;
  if ($('runAgentNow')) $('runAgentNow').disabled = !brainReady;
  if ($('askCoach')) $('askCoach').disabled = !brainReady;
  if ($('createDailyPlan')) $('createDailyPlan').disabled = !brainReady;
  const status = $('agentStatus');
  let text = !a.enabled ? 'AI is off. Save settings to get started.' : a.lastError ? `Needs attention: ${String(a.lastError).slice(0,150)}` : a.lastRunAt ? `Last check: ${new Date(a.lastRunAt).toLocaleString()}.` : 'Ready when recent activity is available.'; if(a.lastProvider) text += ` · ${a.lastProvider === 'cloud' ? (a.lastCloudProvider === 'groq' ? 'Groq' : 'Ollama Cloud') : 'Local Qwen'}${a.lastModel ? ` · ${a.lastModel}` : ''}.`;
  status.textContent = text; status.classList.toggle('error', Boolean(a.lastError));
  const latest = $('agentLatest'); latest.replaceChildren();
  const strong = document.createElement('b'); strong.textContent = 'Latest thought'; latest.append(strong);
  const p = document.createElement('p'); let thoughtDetails = null;
  if (a.lastDecision) {
    const d = a.lastDecision;
    p.textContent = `${String(d.title || 'Greenhouse thought').slice(0,90)}${d.message ? ` — ${String(d.message).slice(0,260)}` : ''}`;
    if (d.reason || d.feedback || (Number.isFinite(Number(d.confidence)) && Number(d.confidence) > 0)) {
      const extra = document.createElement('details'); extra.className = 'thought-details';
      const summary = document.createElement('summary'); summary.textContent = 'Why this suggestion?';
      const detail = document.createElement('p');
      const bits = [];
      if (d.reason) bits.push(`Reason: ${String(d.reason).slice(0,180)}`);
      if (d.feedback) bits.push(`Your feedback: ${d.feedback === 'helpful' ? 'helpful' : 'not now'}`);
      if (Number.isFinite(Number(d.confidence)) && Number(d.confidence) > 0) bits.push(`Confidence estimate: ${Math.round(Math.max(0,Math.min(1,Number(d.confidence)))*100)}%`);
      detail.textContent = bits.join(' · '); extra.append(summary, detail); thoughtDetails = extra;
    }
  } else p.textContent = 'No decision yet. Save settings, then choose Think now.';
  latest.append(p); if (thoughtDetails) latest.append(thoughtDetails);
  const history = $('agentHistory'); history.replaceChildren();
  const historyDisclosure = document.querySelector('.agent-history-details');
  const historyRows = Array.isArray(a.history) ? a.history.slice(-3).reverse() : [];
  if (historyDisclosure) historyDisclosure.classList.toggle('hidden', historyRows.length === 0);
  for (const d of historyRows) {
    const item = document.createElement('div'); item.className = 'agent-history-item';
    const title = document.createElement('b'); title.textContent = `${d.preview ? 'PREVIEW · ' : ''}${d.action || 'thought'} · ${new Date(d.createdAt || Date.now()).toLocaleString()}`;
    const body = document.createElement('p'); body.textContent = `${d.message || ''}${Number.isFinite(Number(d.confidence)) && Number(d.confidence) > 0 ? ` · confidence estimate ${Math.round(Math.max(0,Math.min(1,Number(d.confidence)))*100)}%` : ''}${d.reason ? ` · reason: ${String(d.reason).slice(0,180)}` : ''}${d.feedback ? ` · feedback: ${d.feedback}` : ''}`;
    item.append(title, body); history.append(item);
  }
  const plan = a.dailyPlan || null, planView = $('dailyPlanView'), planStatus = $('dailyPlanStatus');
  if (planView && planStatus) {
    planView.replaceChildren();
    if (plan && Array.isArray(plan.objectives) && plan.objectives.length === 3) {
      const summary = document.createElement('p'); summary.className = 'daily-plan-status'; summary.textContent = `${plan.summary || 'A plan for today'}${plan.strategy ? ` · ${plan.strategy}` : ''}`; planView.append(summary);
      plan.objectives.forEach((obj, index) => {
        const row = document.createElement('div'); row.className = 'daily-plan-item';
        const number = document.createElement('span'); number.className = 'daily-plan-index'; number.textContent = String(index + 1);
        const copy = document.createElement('div'); const label = document.createElement('b'); label.textContent = String(obj.label || 'Small priority').slice(0,100); const meta = document.createElement('small'); meta.textContent = String(obj.type || 'custom').replace('_',' ') + ' · adjustable, not mandatory'; copy.append(label, meta);
        const time = document.createElement('span'); time.className = 'daily-plan-time'; time.textContent = `${Math.max(5, Math.min(120, Number(obj.targetMinutes) || 20))} min`;
        row.append(number, copy, time); planView.append(row);
      });
      planStatus.textContent = plan.appliedAt ? `Applied ${new Date(plan.appliedAt).toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})} · editable in Setup.` : `Ready to review · ${new Date(plan.createdAt || Date.now()).toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}.`;
      $('applyDailyPlan').disabled = Boolean(plan.appliedAt);
    } else {
      planStatus.textContent = a.lastPlanError ? `Could not create a plan: ${String(a.lastPlanError).slice(0,230)}` : 'Build a three-step plan from your recent progress and the AI’s learned feedback.';
      planStatus.classList.toggle('error', Boolean(a.lastPlanError)); $('applyDailyPlan').disabled = true;
    }
    $('createDailyPlan').disabled = !(dataConsent && a.enabled && a.consentAt && a.fullContextConsentAt && Number(a.fullContextConsentVersion) >= 2);
    $('createDailyPlan').title = a.enabled && a.consentAt && a.fullContextConsentAt ? 'Create a new plan using complete consented context' : 'Enable the AI Brain and save full-context consent first';
  }
  const memory = a.memory || {}, total = Number(memory.totalFeedback) || 0, stats = memory.actionStats || {};
  const preferred = Object.entries(stats).filter(([,v]) => (Number(v?.helpful)||0) >= 2 && (Number(v?.helpful)||0) > (Number(v?.not_now)||0)).sort((x,y) => ((Number(y[1].helpful)||0)-(Number(y[1].not_now)||0))-((Number(x[1].helpful)||0)-(Number(x[1].not_now)||0))).slice(0,2).map(([action]) => action.replace('suggest_','').replace('_',' '));
  const memoryEl = $('agentMemorySummary');
  if (memoryEl) {
    const focus = memory.focusOutcomes || {};
    const focusStarted = Number(focus.started) || 0, focusCompleted = Number(focus.completed) || 0, focusInterrupted = Number(focus.interrupted) || 0;
    const finishRate = focusStarted ? Math.round(focusCompleted / focusStarted * 100) : null;
    const browsing = s.browsing || {}, today = new Date();
    const keys = Array.from({length:7},(_,i)=>{const d=new Date(today.getFullYear(),today.getMonth(),today.getDate()-i);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;});
    const sumCat = (type,dayKeys) => dayKeys.reduce((sum,day)=>sum+Math.max(0,Number(browsing.dailyMinutesByCategory?.[`${day}:${type}`])||0),0);
    const prod = Math.round(sumCat('productive',keys)), distract = Math.round(sumCat('distracting',keys));
    const feedbackText = total ? `${total} feedback signal${total===1?'':'s'} remembered locally.${preferred.length ? ` Approaches that tend to help: ${preferred.join(', ')}.` : ' More feedback helps identify your preferences.'}` : 'Feedback builds private, local learning. Preview-card feedback never changes what the AI learns.';
    const focusText = focusStarted ? ` AI-suggested Focus: ${focusCompleted} completed, ${focusInterrupted} interrupted (${finishRate}% completion among starts).` : '';
    const corrections = browsing.pageCorrections || {}; const correctionCount = Object.keys(corrections).length; const usefulCorrections = Object.values(corrections).filter(x => x?.category === 'productive').length; const distractingCorrections = Object.values(corrections).filter(x => x?.category === 'distracting').length;
    const contextPatternCount = Object.keys(memory.contextStats || {}).length;
    const insights = Array.isArray(a.localInsights?.items) ? a.localInsights.items.slice(0, 2).map(item => `${String(item.title || '').slice(0, 70)}: ${String(item.message || '').slice(0, 150)}`) : [];
    const insightText = insights.length ? ` Local insights: ${insights.join(' ')}` : '';
    memoryEl.textContent = `Learning memory · ${feedbackText}${focusText} Context patterns remembered: ${contextPatternCount}. Recent 7-day page signals: ${prod} productive min and ${distract} possible-distraction min; treat both as estimates. Personal page corrections: ${correctionCount} (${usefulCorrections} useful, ${distractingCorrections} distracting). ${Number(memory.plansApplied)||0} AI plan${Number(memory.plansApplied)===1?'':'s'} applied.${insightText}`;
  }
}
function goScreen(screen){document.querySelectorAll('.screen').forEach(el=>el.classList.toggle('active',el.id===`screen-${screen}`));document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.screen===screen));$('app').dataset.screen=screen;}
function domains(text){ return globalThis.DGDomainUtils.normalizeDomains(text); }
function validatedDomains(text, label){
  const raw = String(text || '').split(/[\n,;\s]+/).map(x=>x.trim()).filter(Boolean);
  if(raw.length>250) throw new Error(`${label}: enter no more than 250 domains at a time.`);
  const invalid = raw.filter(token=>globalThis.DGDomainUtils.normalizeDomains(token).length===0);
  if(invalid.length) throw new Error(`${label}: couldn't recognise ${invalid.slice(0,3).join(', ')}${invalid.length>3?' and more':''}. Use a domain such as example.com, or paste its full URL.`);
  return domains(text);
}
async function saveProtection(){const s=await getState();const customBlockedDomains=validatedDomains($('blockedDomains').value,'Sites to block');const allowlist=validatedDomains($('allowlistDomains').value,'Focus allowlist');const aiToolDomains=validatedDomains($('aiToolDomains').value,'AI-tool domains');s.digitalProtection={...(s.digitalProtection||{}),adBlockEnabled:$('adBlockEnabled').checked,adultSiteBlockingEnabled:$('adultBlocking').checked,communityFilterListsEnabled:$('communityFiltersEnabled').checked,gardenGuardEnabled:$('gardenGuard').checked,distractionGuardEnabled:$('distractionGuard').checked,distractionEnforcement:$('distractionEnforcement').value==='remind'?'remind':'block',distractionThresholdMinutes:Number($('distractionThresholdMinutes').value)||5,distractionCooldownMinutes:Number($('distractionCooldownMinutes').value)||15,aiToolBlockingEnabled:$('aiToolBlocking').checked,aiContentInterruptionEnabled:$('aiContentInterruption').checked,aiContentThresholdMinutes:Number($('aiContentThresholdMinutes')?.value)||5,customBlockedDomains,allowlist,aiToolDomains};const r=await send({type:'DG_SAVE_PROTECTION',protection:s.digitalProtection});if(!r?.ok)throw new Error(r?.error||'Could not save protection.');clearSettingsDirty('protection');currentState=await getState();render(currentState);toast(`Protection settings saved · ${r.rulesInstalled??'rules'} site rules applied.`);}
async function saveProfile(){const objectives=[$('objective1').value.trim(),$('objective2').value.trim(),$('objective3').value.trim()].map((x,i)=>x||DEFAULT_OBJECTIVES[i]).map(x=>x.slice(0,100));const start=$('routineWindowStart').value||'17:00',end=$('routineWindowEnd').value||'19:00';const routineDays=[...document.querySelectorAll('.routine-window-day:checked')].map(box=>Number(box.value)).filter(day=>Number.isInteger(day)&&day>=0&&day<=6);const routineWindow={enabled:$('routineWindowEnabled').checked,label:$('routineWindowLabel').value.trim().slice(0,50)||'your planned routine',start,end,days:routineDays};if(routineWindow.enabled&&start===end)throw new Error('Choose different routine start and end times.');if(routineWindow.enabled&&!routineDays.length)throw new Error('Choose at least one day for your routine window.');const primaryType=$('routineBaselineType').value;const rawBaseline=$('routineBaselineMinutes').value;const rawStudy=$('routineStudyMinutes').value;const rawExerciseDays=$('routineExerciseDays').value;const rawReading=$('routineReadingMinutes').value;const bedtime=$('routineSleepBedtime').value;const wakeTime=$('routineSleepWake').value;const routineBaseline={studyMinutesPerDay:rawStudy===''?null:Math.max(0,Math.min(480,Number(rawStudy)||0)),exerciseDaysPerWeek:rawExerciseDays===''?null:Math.max(0,Math.min(7,Math.round(Number(rawExerciseDays)||0))),readingMinutesPerDay:rawReading===''?null:Math.max(0,Math.min(480,Number(rawReading)||0)),sleepSchedule:(bedtime||wakeTime)?{bedtime:bedtime||null,wakeTime:wakeTime||null}:null,sleepNudgesEnabled:$('routineSleepNudges')?.checked===true,primaryType:['studying','exercise','reading','hobby','social','rest','hydration','coding','writing','creative','chores','custom'].includes(primaryType)?primaryType:'',minutesPerDay:rawBaseline===''?null:Math.max(0,Math.min(480,Number(rawBaseline)||0))};if(!routineBaseline.primaryType)routineBaseline.minutesPerDay=null;const profile={routineNotes:$('routineNotes').value.trim().slice(0,1200),goalNotes:$('goalNotes').value.trim().slice(0,800),routineBaseline,tone:$('coachTone').value,dailyObjectives:objectives,dailyObjectiveMode:$('dailyObjectiveMode')?.value==='custom'?'custom':'adaptive',routineWindow,onboardingComplete:true};const result=await send({type:'DG_SAVE_PROFILE',profile});if(!result?.ok)throw new Error(result?.error||'Could not save your starting point.');clearSettingsDirty('profile');currentState=await getState();render(currentState);toast('Your starting point and routine window are saved on this device. 🌱');}
async function toggleTracking(){const result=await send({type:'DG_SAVE_TRACKING_SETTINGS',enabled:$('trackingEnabled').checked,pointIntervalMinutes:Number($('pointInterval').value)||2});if(!result?.ok)throw new Error(result?.error||'Could not save browsing-awareness settings.');await send({type:'DG_TICK_NOW'});clearSettingsDirty('tracking');currentState=await getState();render(currentState);toast('Browsing awareness settings saved.');}
async function askCoach(){const s=await getState();if(!hasCurrentDataConsent(s)){toast('Give data consent in Setup before using Coach.',true);goScreen('settings');return;}if(!s.aiCompanion?.enabled||!s.aiCompanion?.consentAt||!s.aiCompanion?.fullContextConsentAt||Number(s.aiCompanion?.fullContextConsentVersion)<2){toast('Enable the Coach in its settings first.',true);return;}const prompt=$('coachQuestion').value.trim();if(prompt.length<3){toast('Write a little about what you need help with.',true);return;}$('askCoach').disabled=true;$('askCoach').textContent='Thinking…';const resultBox=$('coachResult');resultBox.classList.remove('hidden');resultBox.textContent='Connecting to Greenhouse AI…';try{const context={routineNotes:String(s.profile?.routineNotes||'').slice(0,1200),goals:String(s.profile?.goalNotes||'').slice(0,800),tone:s.profile?.tone||'gentle',currentGrowthPoints:Number(s.plant?.growthPoints)||0,activitySummary:{periodDays:7,totalSessions:(s.browsing?.pointEvents||[]).filter(e=>Date.now()-Date.parse(e.createdAt||0)<7*86400000).length,activeDays:(s.plant?.qualifiedDates||[]).filter(d=>Date.now()-Date.parse(`${d}T00:00:00`)<7*86400000).length,byType:[]}};const personalContext=JSON.parse(JSON.stringify(s)); if(personalContext.aiCompanion) delete personalContext.aiCompanion.serviceAccessToken; // Never send the service token inside the context object.
  const response=await window.DGAI.request('/v1/coach',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({dataConsentVersion:window.DGData.CONSENT_VERSION,dataConsentAt:s.profile?.dataCollection?.consentAt,mode:'routine',prompt,context,personalContext,allowCloudFallback:Boolean(s.aiCompanion?.allowCloudAI)}) ,signal:AbortSignal.timeout(100000)},s);const data=await response.json().catch(()=>({}));if(!response.ok||!data.ok)throw new Error(data.error||`Backend returned HTTP ${response.status}`);const provider=data.provider==='cloud'?(data.cloudProvider==='groq'?'Groq':'Ollama Cloud'):'Local Ollama';resultBox.textContent=`${data.answer||'The coach did not return an answer.'}\n\n— ${provider}${data.model?` · ${data.model}`:''}${data.fallbackUsed?' · cloud fallback used':''}`;
 }catch(e){resultBox.textContent=`I couldn't reach the coach. ${e.message||'Check the configured Greenhouse service and its AI provider.'}\n\nYour plant, tracking, Focus and protection continue working without AI.`;toast('AI coaching unavailable.',true);}finally{const latest=await getState();$('askCoach').disabled=!(hasCurrentDataConsent(latest)&&latest.aiCompanion?.enabled&&latest.aiCompanion?.consentAt&&latest.aiCompanion?.fullContextConsentAt&&Number(latest.aiCompanion?.fullContextConsentVersion)>=2);$('askCoach').textContent='Ask Greenhouse ✨';}}
async function saveAgentSettings() {
  const state = await getState();
  if (!hasCurrentDataConsent(state)) { toast('Give data consent in Setup before enabling Coach or the AI Brain.', true); goScreen('settings'); return; }
  const enabled = $('agentEnabled').checked;
  const autoStartFocusOnDistraction = $('agentAutoFocus').checked;
  const allowCloudAI = enabled && hasCurrentDataConsent(state);
  $('saveAgentSettings').disabled = true; $('saveAgentSettings').textContent = 'Saving…';
  try {
    const result = await send({ type: 'DG_AGENT_SAVE_SETTINGS', settings: { enabled, allowCloudAI, autoStartFocusOnDistraction } });
    if (!result?.ok) throw new Error(result?.error || 'Could not save AI settings.');
    clearSettingsDirty('agent'); currentState = await getState(); render(currentState);
    toast(enabled ? 'Coach is enabled. Proactive AI stays within its cooldown and daily limits. 🌱' : 'Coach settings saved.');
  } finally { $('saveAgentSettings').disabled = false; $('saveAgentSettings').textContent = 'Save settings'; }
}
async function createDailyPlan() {
  const button = $('createDailyPlan'), status = $('dailyPlanStatus'); button.disabled = true; button.textContent = 'Thinking…'; status.textContent = 'The AI is comparing your recent patterns with what it has learned. This can take a little while.'; status.classList.remove('error');
  try { const result = await send({ type: 'DG_AGENT_CREATE_PLAN' }); if (!result?.ok) throw new Error(result?.error || 'Could not create a daily plan.'); currentState = result.state || await getState(); render(currentState); toast('Your daily plan is ready to review. 🌱'); }
  catch (error) { status.textContent = error?.message || 'The daily plan could not be created.'; status.classList.add('error'); toast('Daily plan could not be created.', true); }
  finally { button.textContent = 'Build today’s plan'; const latest = await getState(); button.disabled = !(hasCurrentDataConsent(latest) && latest.aiCompanion?.enabled && latest.aiCompanion?.consentAt && latest.aiCompanion?.fullContextConsentAt && Number(latest.aiCompanion?.fullContextConsentVersion) >= 2); }
}
async function applyDailyPlan() {
  const button = $('applyDailyPlan'); button.disabled = true;
  try { const result = await send({ type: 'DG_AGENT_APPLY_PLAN' }); if (!result?.ok) throw new Error(result?.error || 'Could not apply the plan.'); currentState = result.state || await getState(); render(currentState); toast('Today’s priorities updated. You can change them in Setup any time. 🌿'); }
  catch (error) { toast(error?.message || 'Could not apply the plan.', true); currentState = await getState(); render(currentState); }
}
async function previewAgentAction() {
  $('previewAgentAction').disabled = true;
  try {
    const result = await send({ type: 'DG_AGENT_PREVIEW_ACTION' });
    if (!result?.ok) throw new Error(result?.error || 'Could not show the preview card.');
    currentState = await getState(); render(currentState);
    toast('Sample AI-style action displayed. No API call was made.');
  } catch (error) { toast(error?.message || 'Could not show the preview card.', true); }
  finally { $('previewAgentAction').disabled = false; }
}
async function runAgentNow() {
  const gateState = await getState(); if (!hasCurrentDataConsent(gateState) || !gateState.aiCompanion?.enabled || !gateState.aiCompanion?.consentAt || !gateState.aiCompanion?.fullContextConsentAt || Number(gateState.aiCompanion?.fullContextConsentVersion) < 2) { toast('Enable the AI Brain and save full-context consent first.', true); return; }
  $('runAgentNow').disabled = true; $('runAgentNow').textContent = 'Thinking…';
  $('agentStatus').textContent = 'Thinking with local Qwen…'; $('agentStatus').classList.remove('error');
  try {
    const sourceTabId = (() => { try { return new URL(location.href).searchParams.get('sourceTabId'); } catch { return null; } })();
    const result = await send({ type: 'DG_AGENT_RUN_NOW', sourceTabId });
    if (!result?.ok) throw new Error(result?.error || 'The AI brain could not run.');
    const outcome = result.result || {};
    if (outcome.skipped) {
      const skipMessages = {
        'unsupported-page': 'No real AI decision was made: no normal website tab was available. Open a regular webpage and try Think now again.',
        'no-active-tab': 'No real AI decision was made: Greenhouse could not find a webpage to use as context.',
        'window-not-focused': 'No real AI decision was made: bring Chrome to the front and try again.',
        'user-idle': 'No real AI decision was made: Chrome reports that the computer is idle. Move the mouse or press a key, then retry.',
        'already-running': 'The AI brain is already working on a decision. Wait for it to finish.',
        'daily-limit': 'The AI brain reached its safety limit of three decisions in 24 hours.',
        'not-enough-activity-yet': 'There is not enough recent activity for a useful decision yet. Use a regular webpage and try again.'
      };
      const message = outcome.message || skipMessages[outcome.reason] || `No real AI decision was made (${String(outcome.reason || 'skipped')}).`;
      currentState = await getState(); render(currentState);
      $('agentStatus').textContent = message; $('agentStatus').classList.toggle('error', !['already-running'].includes(outcome.reason));
      toast(message, outcome.reason !== 'already-running');
      return;
    }
    if (!outcome.decision) throw new Error('The backend replied without saving an AI decision. Check the backend terminal for details.');
    currentState = await getState(); render(currentState);
    const d = outcome.decision;
    toast(d.action === 'none' ? 'A real AI check completed; Greenhouse decided not to interrupt.' : 'A real AI decision was saved. Review it under Latest thought.');
  } catch (error) {
    $('agentStatus').textContent = error?.message || 'AI brain failed. Check backend setup.'; $('agentStatus').classList.add('error');
    toast('AI brain did not run.', true);
  } finally { $('runAgentNow').disabled = false; $('runAgentNow').textContent = 'Think now'; }
}
async function testAI(){
  const el=$('aiStatus'); el.textContent='Testing the actual AI model response…';
  try {
    let s=await getState();
    if(!hasCurrentDataConsent(s)) throw new Error('Accept the single data-sharing and hosted-AI consent first.');
    if(!window.DGData?.ensureServiceAccessToken) throw new Error('Automatic service enrollment is unavailable. Reload the extension.');
    await window.DGData.ensureServiceAccessToken();
    s=await getState();
    const r=await window.DGAI.request('/v1/ai/test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({dataConsentVersion:window.DGData.CONSENT_VERSION,dataConsentAt:s.profile?.dataCollection?.consentAt,allowCloudFallback:true}),signal:AbortSignal.timeout(50000)},s);
    const d=await r.json().catch(()=>({}));
    if(!r.ok||!d.ok) throw new Error(d.error||`AI request failed (HTTP ${r.status}).`);
    el.textContent=`AI is responding · ${d.providerLabel||d.provider||'configured model'}${d.model?` · ${d.model}`:''}. ${String(d.reply||'Real model response received.').slice(0,120)}`;
    toast('Real AI request succeeded. 🌱');
  } catch(e){
    el.textContent=`AI needs attention: ${String(e?.message||e).slice(0,220)}`;
    toast('Real AI request failed. See diagnostics for the cause.',true);
  }
}
async function quickCheckin(type){const labels={exercise:'Movement check-in',reading:'Reading check-in',hobby:'Hobby check-in',rest:'Rest and recovery check-in'};const key=`quick-${type}`;try{const r=await send({type:'DG_COMPLETE_OBJECTIVE',key,activityType:type,label:labels[type]});if(!r?.ok)throw new Error(r?.error||'Could not record check-in.');currentState=r.state||await getState();render(currentState);toast(r.alreadyComplete?'That check-in was already counted today.':`Logged gently: +${r.completion.points} adaptive points 🌿`);}catch(e){toast(e.message,true);}}
async function saveReminders(){const settings={remindersEnabled:$('remindersEnabled').checked,reminderMinutes:20};const r=await send({type:'DG_SAVE_REMINDERS',settings});if(!r?.ok)throw new Error(r?.error||'Could not save reminders.');clearSettingsDirty('focus');currentState=await getState();render(currentState);toast(settings.remindersEnabled?'20-minute check-ins and hourly water/outdoor breaks saved.':'Wellbeing reminders paused.');}
async function previewReminder(){const r=await send({type:'DG_TEST_REMINDER'});if(!r?.ok)throw new Error(r?.error||'Could not show a reminder card.');toast('Preview card sent to the current webpage. No Chrome notification was used.');}
async function saveDataCollection(){
  if(!window.DGData)throw new Error('The privacy settings module did not load. Reload the extension and try again.');
  const enabled=$('sharingConsent').checked;
  try {
    const configured=await window.DGData.configure({enabled,endpoint:window.DGData.DEFAULT_ENDPOINT||undefined,consentAccepted:enabled});
    clearSettingsDirty('collection');currentState=await getState();render(currentState);
    if(!configured.enabled){const remote=configured.revocationResult;if(remote?.confirmed===false)toast('Sharing is off here. The server could not confirm the stop request; reconnect to finish revocation.',true);else if(remote?.ok===false)toast('Sharing is off here. Server revocation is pending until the service is reachable.',true);else toast('Sharing is off. Server AI and new uploads are disabled; previous server records remain until you request deletion.');return;}
    const syncResult=configured.syncResult||{};
    if(syncResult.ok){toast('Consent saved. Greenhouse has started automatic sharing. 🌱');}
    else {toast(`Consent saved. Automatic sharing will retry: ${String(syncResult.error||'service unavailable').slice(0,150)}`,true);}
  } catch(error) {
    clearSettingsDirty('collection');
    currentState=await getState();render(currentState);
    // Keep the checkbox aligned with stored consent when a save is rejected.
    $('sharingConsent').checked=hasCurrentDataConsent(currentState);
    toast(String(error?.message||'Could not save your data-sharing choice.'),true);
  }
}
async function downloadServerData(){if(!window.DGData?.exportRemoteData)throw new Error('Server export is unavailable.');const data=await window.DGData.exportRemoteData();const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='digital-greenhouse-server-data.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);toast('Server copy downloaded.');}
async function deleteRemoteData(){if(!confirm('Request deletion of the data this installation previously sent to the configured server? Local plant progress and settings will remain.'))return;const result=await window.DGData.deleteRemote();currentState=await getState();render(currentState);toast(result.nothingFound?'No server data was found; sharing is now off.':'Server data deletion requested successfully; sharing is now off.');}
function exportData(){chrome.storage.local.get(null).then(all=>{const safeStorage=window.DGData?.sanitizeStoredData?window.DGData.sanitizeStoredData(all):all;const safe={format:'digital-greenhouse-local-data-export-v5',exportedAt:new Date().toISOString(),includedStorageKeys:Object.keys(safeStorage),excluded:'Installation tokens, service access tokens, API keys and other fields named as secrets are removed.',storage:safeStorage};const blob=new Blob([JSON.stringify(safe,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='digital-greenhouse-my-local-data.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);toast('Your local data export is ready.');}).catch(e=>toast(`Could not export local data: ${e.message||'export failed'}`,true));}
async function resetData(){const existing=await getState();const activeStrict=existing.digitalAwareness?.activeFocusSession;if(activeStrict?.strict===true&&Date.now()<Date.parse(activeStrict.endsAt)){toast('Garden Guard is locked. Resetting the extension from inside the app is disabled until the session expires.',true);return;}const dc=existing.profile?.dataCollection||{};const remoteMayExist=Boolean(dc.everEnabled||dc.lastSyncedAt);const question=remoteMayExist?'Reset local Greenhouse data and request deletion of the server copy first? Local scores, history and settings will be erased.':'Reset your local Greenhouse routine, scores and history? This cannot be undone. Protection and blocking rules will return to starter defaults.';if(!confirm(question))return;if(remoteMayExist){try{await window.DGData.deleteRemote();}catch(error){toast(`Reset cancelled so your server-deletion credentials are not lost: ${error.message||'deletion failed'}`,true);return;}}await chrome.storage.local.clear();const r=await getState();currentState=r;render(r);toast('Local data reset. Starter defaults restored.');}

async function setCurrentPageCategory(category) {
  if (!window._currentDomain || !window._currentTabId) { toast('Open a regular webpage first.', true); return; }
  const result = await send({ type: 'DG_SET_PAGE_CATEGORY', category, tabId: window._currentTabId });
  if (!result?.ok) throw new Error(result?.error || 'Could not update this site category.');
  currentState = result.state || await getState(); render(currentState);
  toast(result.message || 'Page category updated.');
}
async function allowCurrentPageInFocus() {
  if (!window._currentDomain || !window._currentTabId) { toast('Open a regular webpage first.', true); return; }
  const result = await send({ type: 'DG_ADD_CURRENT_TO_FOCUS_ALLOWLIST', tabId: window._currentTabId });
  if (!result?.ok) throw new Error(result?.error || 'Could not add this site to Focus.');
  currentState = result.state || await getState(); render(currentState); toast(result.message || 'Site added to Focus allowlist.');
}
// Navigation and controls
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>goScreen(b.dataset.screen)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>goScreen(b.dataset.go)));
document.querySelectorAll('[data-duration]').forEach(b=>b.addEventListener('click',()=>{selectedDuration=Number(b.dataset.duration)||50;$('durationOptions').querySelectorAll('button').forEach(x=>x.classList.toggle('selected',x===b));}));
$('refresh').addEventListener('click',async()=>{try{const tab=await currentTab();window._currentDomain=domainOf(tab?.url);window._currentTabId=tab?.id||null;const s=await getState();render(s);toast('Greenhouse refreshed.');}catch(e){toast(e.message,true);}});
if($('openDashboard')) $('openDashboard').addEventListener('click',async()=>{try{const tab=await currentTab();await send({type:'DG_OPEN_DASHBOARD',sourceTabId:tab?.id||window._currentTabId,screen:'grow'});toast('Full dashboard opened in a tab.');}catch(e){toast(e.message||'Could not open dashboard.',true);}});
if($('dashboardRunAgent')) $('dashboardRunAgent').addEventListener('click',runAgentNow);
$('startFocus').addEventListener('click',async()=>{const r=await send({type:'DG_START_FOCUS',durationMinutes:selectedDuration});if(!r?.ok){toast(r?.error||'Could not start Focus.',true);return;}currentState=await getState();render(currentState);toast(`Focus started for ${selectedDuration} minutes. Points are paused.`);});
$('endFocus').addEventListener('click',async()=>{const r=await send({type:'DG_END_FOCUS'});if(!r?.ok){toast(r?.error||'Could not end Focus.',true);return;}currentState=await getState();render(currentState);toast('Focus ended. Welcome back.');});
$('saveReminders').addEventListener('click',()=>saveReminders().catch(e=>toast(e.message,true)));$('testReminder').addEventListener('click',()=>previewReminder().catch(e=>toast(e.message,true)));
$('saveProtection').addEventListener('click',()=>saveProtection().catch(e=>toast(e.message,true)));if($('updateCommunityFilters'))$('updateCommunityFilters').addEventListener('click',async()=>{const button=$('updateCommunityFilters');button.disabled=true;const original=button.textContent;button.textContent='Updating public lists…';try{const result=await send({type:'DG_UPDATE_COMMUNITY_FILTERS'});currentState=await getState();render(currentState);if(!result?.ok)throw new Error(result?.error||'Community filter update failed. Bundled rules remain available.');const st=result.status||currentState.digitalProtection?.communityFilterStatus||{};toast(result.skipped?'Community filter lists are already up to date.':`Community protection lists applied · ${result.rulesInstalled||0} Chrome rules installed.${result.warning?' One source did not update; previous data was retained.':''}`);}catch(error){toast(String(error?.message||'Could not update community filters.'),true);currentState=await getState();render(currentState);}finally{button.disabled=false;button.textContent=original;}});
$('markPageUseful').addEventListener('click',()=>setCurrentPageCategory('productive').catch(e=>toast(e.message,true)));$('markPageDistracting').addEventListener('click',()=>setCurrentPageCategory('distracting').catch(e=>toast(e.message,true)));$('resetPageCategory').addEventListener('click',()=>setCurrentPageCategory('automatic').catch(e=>toast(e.message,true)));$('allowCurrentFocus').addEventListener('click',()=>allowCurrentPageInFocus().catch(e=>toast(e.message,true)));
['adBlockEnabled','adultBlocking','communityFiltersEnabled','gardenGuard','distractionGuard','aiToolBlocking','aiContentInterruption','aiContentThresholdMinutes','distractionEnforcement','distractionThresholdMinutes','distractionCooldownMinutes'].forEach(id=>$(id).addEventListener('change',()=>saveProtection().catch(e=>toast(e.message,true))));
if($('dailyObjectiveMode'))$('dailyObjectiveMode').addEventListener('change',()=>{if($('customObjectiveEditor'))$('customObjectiveEditor').classList.toggle('hidden',$('dailyObjectiveMode').value!=='custom');});$('saveProfile').addEventListener('click',()=>saveProfile().catch(e=>toast(e.message,true)));
if($('activityType'))$('activityType').addEventListener('change',()=>{if($('activityType').value!=='studying')$('activityType').dataset.userSelected='true';renderActivityTimer(currentState||{});});
if($('startActivityTimer'))$('startActivityTimer').addEventListener('click',()=>activityTimerAction('start').catch(e=>toast(e.message,true)));if($('pauseActivityTimer'))$('pauseActivityTimer').addEventListener('click',()=>activityTimerAction('pause').catch(e=>toast(e.message,true)));if($('resumeActivityTimer'))$('resumeActivityTimer').addEventListener('click',()=>activityTimerAction('resume').catch(e=>toast(e.message,true)));if($('finishActivityTimer'))$('finishActivityTimer').addEventListener('click',()=>activityTimerAction('finish').catch(e=>toast(e.message,true)));
$('pointInterval').addEventListener('change',()=>toggleTracking().catch(e=>toast(e.message,true)));
$('trackingEnabled').addEventListener('change',()=>toggleTracking().catch(e=>toast(e.message,true)));
$('askCoach').addEventListener('click',askCoach);$('testAI').addEventListener('click',testAI);$('saveAgentSettings').addEventListener('click',()=>saveAgentSettings().catch(e=>toast(e.message,true)));$('runAgentNow').addEventListener('click',runAgentNow);$('previewAgentAction').addEventListener('click',previewAgentAction);$('createDailyPlan').addEventListener('click',createDailyPlan);$('applyDailyPlan').addEventListener('click',applyDailyPlan);
if($('resetLearningMemory')) $('resetLearningMemory').addEventListener('click',async()=>{if(!confirm('Clear Digital Greenhouse’s locally stored AI learning memory? Your plant, points, Focus history and settings will stay.'))return;try{const r=await send({type:'DG_AGENT_RESET_LEARNING'});if(!r?.ok)throw new Error(r?.error||'Could not clear learning memory.');currentState=await getState();render(currentState);toast('Local AI learning memory cleared.');}catch(e){toast(e.message,true);}});$('exportData').addEventListener('click',exportData);$('resetData').addEventListener('click',()=>resetData().catch(e=>toast(e.message,true)));
$('sharingConsent').addEventListener('change',()=>saveDataCollection());if($('downloadServerData'))$('downloadServerData').addEventListener('click',()=>downloadServerData().catch(e=>toast(e.message,true)));if($('deleteRemoteData'))$('deleteRemoteData').addEventListener('click',()=>deleteRemoteData().catch(e=>toast(e.message,true)));
document.querySelectorAll('[data-quick]').forEach(b=>b.addEventListener('click',()=>quickCheckin(b.dataset.quick)));
try {
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.dgState){currentState=changes.dgState.newValue;render(currentState);}});
} catch (error) { console.warn('Could not subscribe to local state changes:', error); }
window.addEventListener('error', event => {
  console.error('Digital Greenhouse popup error:', event.error || event.message);
  showStartupAlert(`Mini app error: ${event.message || event.error?.message || 'unknown error'}. Your saved data has not been erased. Try reloading the extension.`);
});
window.addEventListener('unhandledrejection', event => {
  console.error('Digital Greenhouse popup request failed:', event.reason);
  if (!currentState) showStartupAlert(`Mini app startup request failed: ${event.reason?.message || event.reason || 'unknown error'}. Try reloading the extension.`);
});
(async()=>{
  try {
    const tab=await currentTab(); window._currentDomain=domainOf(tab?.url); window._currentTabId=tab?.id||null;
    const initialScreen=(location.hash||'').slice(1); if(['grow','focus','protect','coach','settings'].includes(initialScreen)) goScreen(initialScreen);
    const s=await getState(); render(s);
    const brain=s.aiCompanion||{}; $('askCoach').disabled=!(hasCurrentDataConsent(s)&&brain.enabled&&brain.consentAt&&brain.fullContextConsentAt&&Number(brain.fullContextConsentVersion)>=2);
  } catch(e) {
    console.error('Digital Greenhouse startup failed:', e);
    showStartupAlert(`Mini app startup failed: ${e?.message || 'unknown error'}. Your local data has not been erased; try reloading the extension.`);
    // Best effort: reveal the usable local-first UI even if tab lookup or startup work fails.
    try { render(normalizePopupState({})); } catch (renderError) { console.error(renderError); }
  }
})();
