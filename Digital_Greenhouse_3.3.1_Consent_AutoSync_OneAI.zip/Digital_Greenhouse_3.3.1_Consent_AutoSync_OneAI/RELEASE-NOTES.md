# Digital Greenhouse 3.3.1 — consent-triggered auto-sync

## Key changes

- One clear all-or-nothing Setup consent starts automatic enrollment and the first complete-dataset sync; no separate upload/give-data button.
- Same server-recorded consent grants hosted AI for the public release. There is no separate cloud-AI checkbox or user-level model selection.
- All public AI routes share the configured primary cloud model: page understanding, Coach, plans, proactive decisions and the real AI test.
- Automatic token enrollment, per-install authentication, data sync, periodic retries and remote revocation are wired. Opt-out stops future sync/AI when the revocation reaches the server; prior snapshots remain until deletion is requested.
- Private `/owner-dashboard` exports data collected from consenting installations to the owner's computer; owner credentials are not embedded in the extension.
- More conservative secret-field redaction for dataset uploads and exports.
- Duplicate service-test button removed, long explanations/advanced controls remain collapsed, and optional Grow activity surfaces use consistent dark theme styling.
- Preserves 3.2.1 page-correction safeguards, dynamic growth, focus, website protection, reminders, the floating widget and dashboard.

## Publisher setup remains necessary

This bundle is not connected to a live host. Set the real HTTPS endpoint once in `service-config.js` (the included `configure-publisher.cjs` validates it), deploy the backend, and add real provider/signing/owner secrets to the hosting environment before distribution. Ordinary users then do not configure URLs, keys or models.

The JSON backend store is beta-only. Real hosted-provider quality/timing, live Chrome acceptance, and the deployed service remain unverified by the included tests.
