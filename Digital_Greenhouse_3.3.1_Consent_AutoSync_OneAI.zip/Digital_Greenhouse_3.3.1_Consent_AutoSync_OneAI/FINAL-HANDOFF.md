# Digital Greenhouse 3.3.1 — handoff 🌱

This patch keeps the 3.3 extension's existing features while targeting the user's three requested changes: one AI experience, consent-triggered data collection to the project owner, and a less crowded interface.

## Implemented

- A single all-or-nothing Setup consent triggers automatic server enrollment and initial full-data upload—no separate “give data” button.
- The public AI service uses one configured primary cloud model for page understanding, Coach, daily plans, proactive decisions, and the real AI connection test.
- No ordinary user enters a hosted URL, access token, API key, or separate hosted-AI toggle in the extension.
- Background full-data sync and retry are connected to consent. The server checks active consent before hosted AI/data ingestion. Revocation retries after connection failures.
- A private owner dashboard downloads the server's collected consenting-user dataset to the project owner's laptop.
- Secret filtering tightened; previous remote records are explicitly retained until deletion is requested.
- Collapsed lengthy explanations and advanced tools, removed duplicate AI test controls, and fixed the off-screen optional Grow activity color theme.

## One-time publisher action still required

No actual public service URL or private provider/admin secrets were supplied in the source package; I have not invented them or claimed to deploy a service. Deploy `server/` behind HTTPS, configure its private environment, set the real URL once in `service-config.js` (or run `node configure-publisher.cjs https://YOUR-REAL-SERVICE-HOST`), then distribute that configured build. Until then the hosted URL remains blank and the extension fails closed—no data is uploaded to localhost.

## Verification

`node tests/smoke.cjs` passes the bundled regression suites. Tests use fake/mocked AI responses; they do not verify live model quality, a real hosting deployment or interactive Chrome behavior. The JSON store is for limited beta use only, not broad production deployment.
