const quotes = [
  'You do not need a perfect day. Just choose the next kind step.',
  'An urge can pass without being obeyed.',
  'Rest counts. Learning counts. You count without points.',
  'Come back to what you chose, one minute at a time.',
  'Progress is built from ordinary choices, repeated gently.',
  'You are allowed to pause before a habit chooses for you.'
];
const animals = ['🐈','🐕','🦊','🐼','🐸','🦦'];
const params = new URLSearchParams(location.search);
const reason = params.get('reason') || 'protection';
const focusMode = reason === 'focus';
const distractionMode = reason === 'distraction' || reason === 'doomscroll';
const doomscrollMode = reason === 'doomscroll';
const gardenMode = reason === 'garden';
const animalNode = document.getElementById('animal');
const quoteNode = document.getElementById('quote');
const heading = document.getElementById('heading');
const intro = document.getElementById('intro');
const badge = document.getElementById('reasonBadge');
const timer = document.getElementById('timer');
const status = document.getElementById('status');
const overridePanel = document.getElementById('overridePanel');
const startFocusButton = document.getElementById('startFocus');
animalNode.textContent = animals[Math.floor(Math.random() * animals.length)];
quoteNode.textContent = quotes[Math.floor(Math.random() * quotes.length)];
if (focusMode) {
  badge.textContent = 'Focus is active'; heading.textContent = 'Keep your attention where you chose 🌿';
  intro.textContent = 'This page is not on your useful or essential list. Strict Focus blocks unknown pages until your timer ends.';
  overridePanel.hidden = true; startFocusButton.hidden = true;
} else if (distractionMode) {
  badge.textContent = doomscrollMode ? 'Doomscroll stop' : 'Temporary distraction stop'; heading.textContent = doomscrollMode ? 'The feed is taking a break 🐈' : 'This page is taking a break 🐈';
  intro.textContent = doomscrollMode ? 'Greenhouse counted active scrolling—not just an open tab—and paused this feed after repeated warnings. Your plant is not punished; the goal is to give your attention back.' : 'Greenhouse detected a sustained distracting pattern and stopped this page. Your plant is not punished; the goal is to help you regain choice.';
  const until = Number(params.get('until'));
  if (Number.isFinite(until) && until > Date.now()) {
    timer.style.display = 'block';
    const update = () => {
      const remaining = Math.max(0, until - Date.now());
      if (remaining <= 0) { timer.textContent = 'The temporary stop has ended. You may return deliberately.'; return; }
      const mins = Math.floor(remaining / 60000), secs = Math.floor((remaining % 60000) / 1000);
      timer.textContent = `This domain is paused for ${mins}m ${String(secs).padStart(2,'0')}s more.`;
    };
    update(); setInterval(update, 1000);
  }
} else if (gardenMode) {
  badge.textContent = 'Garden Guard'; heading.textContent = 'Choose from your allowed garden 🌱';
  intro.textContent = 'Garden Guard only lets you visit domains on your allowlist. Add a site in Setup if it belongs in your garden.';
  overridePanel.hidden = true;
} else {
  badge.textContent = 'Digital protection'; heading.textContent = 'This website is blocked';
  intro.textContent = 'This domain matches one of your Digital Greenhouse protection rules. If it is blocked by mistake, review your list in Setup.';
  overridePanel.hidden = true;
}

document.getElementById('back').addEventListener('click', () => {
  if (history.length > 1) history.back(); else status.textContent = focusMode ? 'This page stays blocked until Focus ends.' : 'Use Setup to review your protection settings.';
});
startFocusButton.addEventListener('click', async () => {
  startFocusButton.disabled = true; status.textContent = 'Starting Focus…';
  try {
    const response = await chrome.runtime.sendMessage({ type: 'DG_START_FOCUS', durationMinutes: 50 });
    if (!response?.ok) throw new Error(response?.error || 'Focus could not start.');
    status.textContent = 'Focus is locked for 50 minutes. Points, deductions, productive minutes and plant growth are paused.';
    startFocusButton.textContent = 'Focus started ✓';
  } catch (error) { status.textContent = error?.message || 'Could not start Focus.'; startFocusButton.disabled = false; }
});
document.getElementById('override').addEventListener('click', async () => {
  if (focusMode || gardenMode) { status.textContent = 'Overrides are disabled by strict protection.'; return; }
  let target; try { target = new URL(document.getElementById('target').value); } catch { status.textContent = 'Enter a complete website address beginning with https://'; return; }
  if (!['http:', 'https:'].includes(target.protocol)) { status.textContent = 'Only HTTP and HTTPS websites can be opened.'; return; }
  const button = document.getElementById('override'); button.disabled = true;
  for (let i = 10; i > 0; i--) { status.textContent = `Taking a breath… ${i}`; await new Promise(resolve => setTimeout(resolve, 1000)); }
  try {
    const response = await chrome.runtime.sendMessage({ type: 'DG_BLOCKED_OVERRIDE', url: target.href });
    if (!response?.ok) throw new Error(response?.error || 'The exception could not be enabled.');
    status.textContent = 'Opening this site for 5 minutes…';
  } catch (error) { status.textContent = error?.message || 'Could not apply the exception.'; button.disabled = false; }
});
