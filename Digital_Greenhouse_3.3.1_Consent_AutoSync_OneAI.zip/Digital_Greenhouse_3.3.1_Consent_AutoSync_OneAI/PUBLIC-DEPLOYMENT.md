# Digital Greenhouse 3.3.1 — one-time publisher setup

This guide configures the service once for ordinary users. The extension's Setup is intentionally simpler: one all-or-nothing sharing choice starts automatic enrollment and full-data sync; that server-recorded consent also enables hosted AI. No user enters an endpoint, API key, access token, or separate cloud-AI toggle.

## 1. Deploy the backend

Deploy the `server/` directory as a Node.js 20+ long-running service behind HTTPS. Use a stable origin (for example `https://your-real-service.example`) and configure the host to start `node server.js`. Keep `HOST=0.0.0.0` only on the host where the platform supplies HTTPS ingress.

Do not assume that uploading the source ZIP creates a live service. This repository does not contain a hosted URL, a live API key or a configured hosting account.

## 2. Configure private environment variables

Use `server/.env.public.example` as the variable checklist. In the hosting provider's private secret/environment settings, set:

- `DG_PUBLIC_MODE=true`
- `HOST=0.0.0.0`
- `DG_TOKEN_SECRET` — at least 48 bytes of unpredictable random text, never the example placeholder
- `DG_OWNER_ADMIN_TOKEN` — a separately generated, strong secret used only by the owner data-export page
- `AI_PROVIDER=cloud`
- `CLOUD_AI_PROVIDER=ollama` (the shipped default) or another supported provider the operator is authorized and eligible to use
- The selected provider's real private credential and model name, such as `OLLAMA_API_KEY` and `OLLAMA_CLOUD_MODEL`
- Optional rate limits `DG_PUBLIC_AI_PER_MINUTE_LIMIT` and `DG_PUBLIC_AI_PER_DAY_LIMIT`

Generate independent secrets on a trusted terminal, for example:

```powershell
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

Run it separately for both secrets. Add the real values directly in the hosting provider's secret dashboard. Do not place either secret in the extension, `service-config.js`, repository, screenshot, or distributable ZIP. Do not share the owner token with regular users.

## 3. Configure storage before inviting users

The bundled server currently stores full snapshots in a JSON file. That is suitable only for a limited beta/testing scenario and is not an audited multi-tenant production database. If the host's filesystem is ephemeral, uploads can be lost during redeployments. Before collecting meaningful personal data, attach persistent storage or replace the store with a properly secured database; test user isolation, backups, retention and deletion. Do not launch to a broad audience before privacy/security review.

## 4. Set the public URL once in the extension

Open `service-config.js` in the publisher copy and set `apiBaseUrl` to the real HTTPS **origin only**, e.g. `https://your-real-service.example`. Do not add `/health`, `/api`, credentials, query text or a trailing endpoint path.

Alternatively, run from the extracted extension directory:

```powershell
node configure-publisher.cjs https://your-real-service.example
```

This script validates the URL and changes only the publisher-configured base origin. Then package/distribute this configured copy. Users should never edit that file.

The distributed template intentionally has an empty endpoint until the publisher supplies the real one. A blank endpoint fails closed; the extension never silently sends consented data to `127.0.0.1`.

## 5. Confirm actual AI, not only health

After deploy, check `https://YOUR-SERVICE/health`. This reports reduced service/provider configuration status. It **does not prove that a real model request succeeds**. Install the publisher-configured build, accept the single Setup consent, and use the one **Check setup** action or actual Coach/page/plan features. Confirm that the live provider responds with useful output and verify timeouts, invalid JSON, rate-limit errors and provider outages.

One configured primary cloud model is used for all public AI tasks. Task-specific instructions and schemas vary, but the user does not pick separate models. Data-sharing consent is checked server-side at enrollment; when consent is withdrawn, future hosted AI and ingestion are blocked once revocation reaches the server. The extension retries revocation after temporary connection failures.

## 6. Owner data download

Open `https://YOUR-SERVICE/owner-dashboard`. Enter the private `DG_OWNER_ADMIN_TOKEN` in the owner-only form and choose **Load summary & download JSON**. The JSON download is saved through the browser to the owner's computer. Treat it as sensitive: it may contain routine notes, points, settings, feedback, and recorded browser-use signals for users who consented.

The dashboard's static page can be visited without the owner token, but dataset export itself requires the secret. The owner credential is not stored by the page after the request.

## 7. Consent and data flow

- The user sees one clear, all-or-nothing disclosure covering the dataset, the operator's ability to access/download it, and the hosted AI processing described there.
- Checking consent triggers enrollment and the first full-dataset sync immediately; background sync repeats while consent stays active.
- The owner can export all stored snapshots through the private owner dashboard.
- Unchecking consent disables local hosted-AI/data operations and posts `/v1/revoke`. When the server receives revocation, previously issued access tokens stop working for hosted AI and ingestion. If the extension is offline, it retries the revocation request when it reconnects.
- Revocation stops future collection; it does not delete earlier server records. The user can separately request deletion. The disclosure states this distinction.
- Uploads omit credential/token fields and fail rather than silently uploading a partial snapshot. Data is not anonymous: the owner can associate records with a pseudonymous installation identifier.

## Before broad public use

This is a beta scaffold. Add/verify a hardened persistent database, access controls, encryption/key management, durable request limits, abuse handling, backups and restore tests, retention schedules, monitoring, incident response and a clear deletion workflow. Review the privacy notice and applicable legal requirements. Share data only from users who explicitly consent. Provider quota limits, availability and cost still apply.
