// Digital Greenhouse: local page classifier + persistent draggable mini-widget.
// Only numeric scores/category are sent to the extension worker. Raw page text, forms,
// messages and input values are never sent or stored.
(() => {
  if (window.top !== window || document.getElementById('dg-floating-widget')) return;

  const newVisitId = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  let visitId = newVisitId();
  const hostname = location.hostname.toLowerCase().replace(/^www\./, '');
  const sendRuntimeMessage = (message) => {
    try {
      const pending = chrome.runtime.sendMessage(message);
      if (pending && typeof pending.catch === 'function') pending.catch(() => {});
    } catch {}
  };
  const POSITIVE = [
    /\b(lesson|lecture|course|tutorial|study guide|learn|learning|practice problem|homework|assignment|schoolwork|exam prep|revision|textbook|syllabus|classroom|curriculum|educational|academic|research paper|journal article|university|scholarship)\b/gi,
    /\b(documentation|api reference|developer guide|technical reference|code example|programming|algorithm|syntax|debugging|source code|repository|manual|how[- ]to guide|step[- ]by[- ]step|explained|definition|dictionary|encyclopedia|formula|worked example)\b/gi,
    /\b(mathematics|algebra|geometry|biology|chemistry|physics|history|geography|economics|grammar|language learning|flashcards|quiz|question bank|course notes|lecture notes)\b/gi,
    /\b(calendar|task list|project plan|spreadsheet|word processor|notes workspace|writing editor|research tool|reference library|official documentation)\b/gi
  ];
  const NEGATIVE = [
    /\b(for you|fyp|reels?|shorts?|endless feed|infinite scroll|trending now|viral|memes?|pranks?|reaction videos?|watch next|recommended videos?|autoplay|swipe up|doomscroll|scrolling feed)\b/gi,
    /\b(gossip|celebrity news|drama|fan edits?|livestream|live stream|funny clips?|compilation|binge|entertainment only|gameplay|mobile game|casino|loot box)\b/gi,
    /\b(like and follow|follow for more|subscribe for more|new posts|suggested posts|stories|trending audio|popular creators|watch more|next episode)\b/gi
  ];

  function countMatches(text, patterns) {
    let score = 0;
    for (const pattern of patterns) {
      pattern.lastIndex = 0;
      const matches = text.match(pattern);
      score += Math.min(5, matches ? matches.length : 0);
    }
    return Math.min(24, score);
  }
  function safePageText() {
    const parts = [];
    parts.push(document.title || '');
    for (const selector of ['meta[name="description"]', 'meta[property="og:title"]', 'meta[property="og:description"]']) {
      const node = document.querySelector(selector);
      if (node?.content) parts.push(node.content.slice(0, 500));
    }
    for (const node of document.querySelectorAll('h1,h2,h3,[role="heading"]')) {
      if (node.closest('nav,header,footer,[role="navigation"],[role="log"],[contenteditable="true"]')) continue;
      parts.push((node.innerText || node.textContent || '').slice(0, 180));
      if (parts.join(' ').length > 3500) break;
    }
    // Use article/main text when available, but deliberately exclude forms, chats, message lists,
    // editable fields, navigation, sidebars and common private-message containers.
    const contentRoot = document.querySelector('article') || document.querySelector('main,[role="main"]');
    if (contentRoot) {
      const clone = contentRoot.cloneNode(true);
      clone.querySelectorAll('input,textarea,select,button,form,nav,header,footer,aside,[role="navigation"],[role="log"],[role="textbox"],[contenteditable="true"],[class*="chat" i],[id*="chat" i],[class*="message" i],[id*="message" i],[aria-label*="message" i]').forEach(n => n.remove());
      parts.push((clone.innerText || clone.textContent || '').slice(0, 4500));
    }
    return parts.join(' ').toLowerCase().replace(/\s+/g, ' ').slice(0, 8000);
  }
  function classifyPage() {
    const text = safePageText();
    const title = `${document.title || ''} ${location.pathname}`.toLowerCase();
    let productive = countMatches(text, POSITIVE) + Math.min(5, countMatches(title, POSITIVE));
    let distracting = countMatches(text, NEGATIVE) + Math.min(5, countMatches(title, NEGATIVE));

    // Structural evidence supplements language, so a useful page is not missed just because
    // it has little prose. This is feature scoring, not a fixed list of a few websites.
    const codeBlocks = document.querySelectorAll('pre code, pre, [class*="code-block" i]').length;
    const articleCount = document.querySelectorAll('article').length;
    const meaningfulHeadings = document.querySelectorAll('h1,h2,h3,[role="heading"]').length;
    const videoCount = document.querySelectorAll('video').length;
    const feedSignals = document.querySelectorAll('[class*="feed" i],[id*="feed" i],[class*="reel" i],[class*="shorts" i],[class*="timeline" i],[data-testid*="feed" i],[class*="recommended-video" i]').length;
    const links = document.querySelectorAll('a[href]').length;
    if (codeBlocks >= 2) productive += 2;
    if (articleCount > 0 && meaningfulHeadings >= 3) productive += 1;
    const editorSurface = document.querySelector('[contenteditable="true"],[role="textbox"],[class*="editor" i],[class*="document-canvas" i],[class*="notebook" i]');
    const menuBar = document.querySelector('[role="menubar"],[class*="menubar" i],[class*="toolbar" i]');
    if (editorSurface && menuBar && !/comment|reply|message|chat|post/i.test(title)) productive += 2;
    if (/\/docs?\/|\/reference\/|\/learn\/|\/lesson\/|\/course\/|\/tutorial\/|\/document\/|\/spreadsheets?\/|\/presentation\/|\/notebook\/|\/editor\//i.test(location.pathname)) productive += 2;
    if (/\/reels?\/|\/shorts?\/|\/for-you\/|\/trending\//i.test(location.pathname)) distracting += 4;
    if (feedSignals >= 2) distracting += 2;
    if (videoCount >= 4 && (distracting > 0 || /feed|watch|video|shorts|reels/i.test(title))) distracting += 2;
    const qnaEvidence = document.querySelectorAll('[itemtype*="Question" i],[itemtype*="Answer" i],[class*="accepted-answer" i],[data-testid*="accepted-answer" i]').length;
    if (qnaEvidence > 0 || /accepted answer|worked solution|troubleshooting steps|step-by-step solution/i.test(text)) productive += 2;
    if (links > 80 && feedSignals > 0) distracting += 1;

    let category = 'neutral', confidence = 0.35;
    const difference = Math.abs(productive - distracting);
    if (productive >= 2 && productive - distracting >= 2) {
      category = 'productive';
      confidence = Math.min(0.96, 0.57 + Math.min(0.28, (productive - distracting) * 0.035) + (productive >= 7 ? 0.08 : 0));
    } else if (distracting >= 2 && distracting - productive >= 2) {
      category = 'distracting';
      confidence = Math.min(0.96, 0.57 + Math.min(0.28, (distracting - productive) * 0.035) + (distracting >= 7 ? 0.08 : 0));
    } else if (productive > 0 || distracting > 0) {
      confidence = Math.min(0.54, 0.3 + difference * 0.025);
    }
    // Share only coarse, local-derived page shape with the worker. No page text, URL path,
    // title, domain or input content is added to the AI snapshot from this feature vector.
    let pageKind = 'general';
    const pathname = location.pathname.toLowerCase();
    if (/\/(shorts?|reels?|for-you|trending)(\/|$)/i.test(pathname) || (/shorts|reels|fyp|infinite scroll/i.test(title) && feedSignals > 0)) pageKind = 'short_video';
    else if (feedSignals >= 2 && distracting >= productive) pageKind = 'social_feed';
    else if (editorSurface && menuBar && !/comment|reply|message|chat|post/i.test(title)) pageKind = 'editor';
    else if (codeBlocks >= 2) pageKind = 'technical_reference';
    else if (qnaEvidence > 0 || /\b(question|answer|forum|discussion|community thread)\b/i.test(title)) pageKind = 'forum';
    else if (/\b(search results|search results for)\b/i.test(title) || /\/(search|results)(\/|$)/i.test(pathname)) pageKind = 'search_results';
    else if (/\b(lesson|course|tutorial|practice|quiz|homework|study guide|lecture)\b/i.test(title)) pageKind = 'lesson';
    else if (/\b(documentation|reference|api docs|manual|encyclopedia|dictionary)\b/i.test(title) || /\/(docs?|reference|manual)(\/|$)/i.test(pathname)) pageKind = 'reference';
    else if (videoCount > 0 || /\b(video|watch|player|stream)\b/i.test(title)) pageKind = 'video';
    else if (editorSurface || /\b(document|spreadsheet|presentation|notebook)\b/i.test(title)) pageKind = 'document';
    else if (articleCount > 0 && meaningfulHeadings >= 2) pageKind = 'article';
    else if (menuBar || /\b(calendar|tasks|dashboard|workspace|project)\b/i.test(title)) pageKind = 'productivity_tool';
    const pageFeatures = {
      productiveScore: Math.min(100, productive), distractingScore: Math.min(100, distracting),
      headings: Math.min(100, meaningfulHeadings), codeBlocks: Math.min(100, codeBlocks),
      videos: Math.min(100, videoCount), feedSignals: Math.min(100, feedSignals),
      editorSurface: Boolean(editorSurface), questionAnswerEvidence: Math.min(100, qnaEvidence)
    };
    // Produce coarse labels locally so the AI can reason about likely task context without
    // sending title, URL, page text, messages, or input content. These remain weak hints.
    const localEvidence = `${title} ${text.slice(0, 4200)}`;
    const topicRules = [
      ['learning', /\b(study|studying|lesson|course|textbook|lecture|homework|exam|quiz|practice question|flashcard)\b/i],
      ['reference', /\b(documentation|reference|manual|encyclopedia|dictionary|worked solution|research paper|citation|source material)\b/i],
      ['coding', /\b(programming|javascript|typescript|python|debugging|code editor|terminal|git repository|api endpoint|stack trace)\b/i],
      ['writing', /\b(essay|draft|write|writing|proofread|document editor|report|outline|article editor)\b/i],
      ['productivity', /\b(calendar|task list|project board|kanban|spreadsheet|workspace|schedule|to-do)\b/i],
      ['social', /\b(friends|social feed|comments|group conversation|community post|direct message|timeline)\b/i],
      ['short_video', /\b(shorts|reels|tiktok|fyp|short-form video|infinite scroll)\b/i],
      ['entertainment', /\b(streaming|watch episode|movie|music video|playlist|tv series|entertainment)\b/i],
      ['gaming', /\b(gameplay|video game|gaming|game launcher|multiplayer|walkthrough)\b/i],
      ['shopping', /\b(product listing|shopping cart|price comparison|product review|add to cart|checkout)\b/i],
      ['news', /\b(news article|headlines|breaking news|newsroom|latest news)\b/i],
      ['creative', /\b(design canvas|drawing tool|illustration|photo editor|graphic design|creative workspace)\b/i]
    ];
    const topicHints = topicRules.filter(([, pattern]) => pattern.test(localEvidence)).map(([topic]) => topic).slice(0, 3);
    return { category, confidence, productiveScore: Math.min(100, productive), distractingScore: Math.min(100, distracting), pageKind, pageFeatures, topicHints };
  }

  let localAIReviewRequested = false;
  let localAIReviewInFlight = false;
  let lastLocalAISettingCheckAt = 0;
  function safeLocalAIPageContext() {
    const title = String(document.title || '').replace(/[\r\n\t]+/g, ' ').trim().slice(0, 140);
    const excluded = 'nav,header,footer,aside,[role="navigation"],[role="log"],[role="textbox"],[contenteditable="true"],form,input,textarea,select,button,[class*="chat" i],[id*="chat" i],[class*="message" i],[id*="message" i],[aria-label*="message" i]';
    const headings = [];
    for (const node of document.querySelectorAll('h1,h2,h3,[role="heading"]')) {
      if (node.closest(excluded)) continue;
      const value = String(node.innerText || node.textContent || '').replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 100);
      if (value && !headings.includes(value)) headings.push(value);
      if (headings.length >= 10) break;
    }
    const rootNode = document.querySelector('article') || document.querySelector('main,[role="main"]');
    let excerpt = '';
    if (rootNode && !rootNode.closest('[role="log"],[role="textbox"],[contenteditable="true"],[class*="chat" i],[id*="chat" i],[class*="message" i],[id*="message" i]')) {
      const clone = rootNode.cloneNode(true);
      try { clone.querySelectorAll(excluded).forEach(node => node.remove()); } catch {}
      excerpt = String(clone.innerText || clone.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 1400);
    }
    return { title, headings, excerpt };
  }
  async function reviewUncertainPageWithLocalAI(result) {
    const scoreGap = Math.abs(Number(result.productiveScore || 0) - Number(result.distractingScore || 0));
    // The heuristic remains the instant first-pass. Once the user enables the full-context AI Brain,
    // local Qwen reviews every eligible, visible page once per visit—even confident rules can be wrong.
    // This is local-only, bounded, rate-limited in the worker, and never grants direct block/point authority.
    if (localAIReviewRequested || localAIReviewInFlight || document.visibilityState === 'hidden') return;
    if (Date.now() - lastLocalAISettingCheckAt < 60 * 1000) return;
    lastLocalAISettingCheckAt = Date.now();
    localAIReviewInFlight = true;
    try {
      const setting = await chrome.runtime.sendMessage({ type: 'DG_GET_LOCAL_PAGE_AI_ENABLED' });
      if (!setting?.enabled) return;
      const context = safeLocalAIPageContext();
      if (!context.title && !context.headings.length && !context.excerpt) return;
      localAIReviewRequested = true;
      const reviewResult = await chrome.runtime.sendMessage({
        type: 'DG_AI_CLASSIFY_PAGE', visitId,
        title: context.title, headings: context.headings, excerpt: context.excerpt,
        baselineCategory: result.category, baselineConfidence: result.confidence,
        features: result.pageFeatures
      });
      if (reviewResult?.ok === false && reviewResult?.skipped !== true) localAIReviewRequested = false;
      // The worker writes only a compact classification result to local storage. Its onChanged
      // listener refreshes this widget; the page text itself never returns to or is stored by us.
    } catch {} finally { localAIReviewInFlight = false; }
  }

  let lastSentSignature = '';
  let lastSentAt = 0;
  const ANALYSIS_HEARTBEAT_MS = 60 * 1000;
  function analyzeAndSend() {
    if (document.visibilityState === 'hidden') return;
    try {
      const result = classifyPage();
      const signature = `${result.category}:${result.confidence.toFixed(2)}:${result.pageKind}:${result.topicHints.join(',')}:${result.productiveScore}:${result.distractingScore}:${result.pageFeatures.headings}:${result.pageFeatures.codeBlocks}:${result.pageFeatures.videos}:${result.pageFeatures.feedSignals}:${Number(result.pageFeatures.editorSurface)}:${result.pageFeatures.questionAnswerEvidence}`;
      void reviewUncertainPageWithLocalAI(result);
      const now = Date.now();
      // Refresh the timestamp periodically even on an unchanged page. This keeps the
      // worker's 30-minute freshness check alive without counting another visit.
      if (signature === lastSentSignature && lastSentSignature && now - lastSentAt < ANALYSIS_HEARTBEAT_MS) {
        renderWidgetFromCurrentState(result);
        return;
      }
      lastSentSignature = signature;
      lastSentAt = now;
      sendRuntimeMessage({ type: 'DG_PAGE_ANALYSIS', domain: hostname, visitId, ...result }); // pageKind + bounded feature counts only; never raw page text.
      renderWidgetFromCurrentState(result);
    } catch (error) {
      console.debug('Greenhouse page analysis skipped:', error?.message || error);
    }
  }

  const root = document.createElement('div');
  root.id = 'dg-floating-widget';
  const shadow = root.attachShadow({ mode: 'open' });
  shadow.innerHTML = `<div class="dg-head" id="dg-drag-handle" title="Drag to move the greenhouse widget"><span>🌱 Greenhouse <small>↕ move</small></span><button id="dg-min" type="button" aria-label="Minimize widget">−</button></div>
  <nav class="dg-tabs" aria-label="Quick greenhouse controls"><button class="active" data-dg-view="grow" type="button">Grow</button><button data-dg-view="focus" type="button">Focus</button><button data-dg-view="coach" type="button">Coach</button><button data-dg-view="more" type="button">More</button></nav>
  <section class="dg-pane active" data-dg-pane="grow"><div class="dg-main"><div id="dg-plant">🌱</div><div class="dg-info"><b id="dg-stage">Seedling</b><div id="dg-points">0 points</div><div id="dg-days">0 / 7 growth days</div><div class="dg-track"><div id="dg-progress"></div></div><div id="dg-detection">Reading this page…</div></div></div><div class="dg-classify"><button data-dg-category="productive" type="button">Mark useful</button><button data-dg-category="distracting" type="button">Mark distracting</button><button data-dg-category="automatic" type="button">Auto</button></div><details class="dg-checkins"><summary>Optional off-screen steps</summary><div id="dg-objectives"></div></details></section>
  <section class="dg-pane" data-dg-pane="focus"><div class="dg-pane-title">☘ Focus mode</div><p class="dg-subcopy" id="dg-focus-summary">Choose a session length; points pause while Focus is active.</p><div class="dg-durations"><button data-dg-duration="25" type="button">25m</button><button class="selected" data-dg-duration="50" type="button">50m</button><button data-dg-duration="90" type="button">90m</button></div><button id="dg-focus" type="button" class="dg-primary">Start strict Focus · 50m</button></section>
  <section class="dg-pane" data-dg-pane="coach"><div class="dg-pane-title">✦ Greenhouse brain</div><b id="dg-ai-status">AI coach is off</b><p id="dg-ai-suggestion" class="dg-subcopy">Enable and configure AI from Coach in the mini-app.</p><button id="dg-coach" type="button" class="dg-primary">Think now</button><div class="dg-feedback"><button id="dg-ai-helpful" type="button">Helpful</button><button id="dg-ai-notnow" type="button">Not now</button></div></section>
  <section class="dg-pane" data-dg-pane="more"><div class="dg-pane-title">More controls</div><p class="dg-subcopy">Use the mini-app for everyday controls or open the detailed website for advanced settings and insights.</p><button id="dg-open" type="button" class="dg-primary">Open mini-app ↗</button><button id="dg-dashboard" type="button" class="dg-secondary">Full dashboard website ↗</button><button id="dg-allow-focus" type="button" class="dg-secondary">Allow this site in Focus</button></section>
  <div id="dg-msg" role="status" aria-live="polite"></div>`;
  const css = document.createElement('link');
  css.rel = 'stylesheet';
  css.href = chrome.runtime.getURL('widget.css');
  shadow.prepend(css);
  (document.body || document.documentElement).append(root);
  const $ = id => shadow.querySelector('#' + id);
  // Some browser/API versions do not return a Promise from storage.set when no
  // callback is supplied. Handle both Promise-returning and callback-era behavior.
  function safeStorageSet(items) {
    try {
      const operation = chrome.storage.local.set(items);
      if (operation && typeof operation.catch === 'function') operation.catch(() => {});
    } catch (error) {
      // Widget position/minimized state is a convenience; a storage failure must not
      // stop the rest of the widget from working.
      console.debug('Greenhouse widget preference was not saved:', error?.message || error);
    }
  }
  // The button is part of the widget shadow tree, but rebuild it defensively if a site's
  // DOM behavior or a partial injection removes it before handlers are registered.
  let minimizeButton = $('dg-min');
  if (!minimizeButton) {
    const dragHandle = $('dg-drag-handle');
    if (dragHandle) {
      minimizeButton = document.createElement('button');
      minimizeButton.id = 'dg-min';
      minimizeButton.type = 'button';
      minimizeButton.setAttribute('aria-label', 'Minimize widget');
      minimizeButton.textContent = '−';
      dragHandle.append(minimizeButton);
    }
  }
  let drag = null, suppressClickUntil = 0, lastCategory = 'neutral', lastConfidence = 0, activeView = 'grow', selectedDuration = 50;
  const MIN_VISIBLE = 44;
  function clampPosition(left, top) {
    const rect = root.getBoundingClientRect();
    const maxLeft = Math.max(0, window.innerWidth - Math.min(MIN_VISIBLE, rect.width));
    const maxTop = Math.max(0, window.innerHeight - Math.min(MIN_VISIBLE, rect.height));
    return { left: Math.max(-rect.width + MIN_VISIBLE, Math.min(maxLeft, left)), top: Math.max(0, Math.min(maxTop, top)) };
  }
  function setPosition(pos, persist = false) {
    if (!pos || !Number.isFinite(Number(pos.left)) || !Number.isFinite(Number(pos.top))) return;
    const bounded = clampPosition(Number(pos.left), Number(pos.top));
    root.style.left = `${bounded.left}px`; root.style.top = `${bounded.top}px`; root.style.right = 'auto'; root.style.bottom = 'auto';
    if (persist) safeStorageSet({ dgWidgetPosition: bounded });
  }
  function getPlantStage(s) {
    const days = Math.max(0, Number(s?.plant?.growthDays ?? s?.plant?.qualifiedDates?.length) || 0);
    if (days >= 730) return { name: 'Flourishing tree', emoji: '🌳', from: 730, next: null };
    if (days >= 365) return { name: 'Young tree', emoji: '🌲', from: 365, next: 730 };
    if (days >= 180) return { name: 'Sapling', emoji: '🪴', from: 180, next: 365 };
    if (days >= 90) return { name: 'Established plant', emoji: '🌷', from: 90, next: 180 };
    if (days >= 30) return { name: 'Growing plant', emoji: '🪴', from: 30, next: 90 };
    if (days >= 7) return { name: 'Sprout', emoji: '🌿', from: 7, next: 30 };
    return { name: 'Seedling', emoji: '🌱', from: 0, next: 7 };
  }
  function render(s, signal) {
    const points = Number(s?.plant?.growthPoints) || 0, days = Math.max(0, Number(s?.plant?.growthDays ?? s?.plant?.qualifiedDates?.length) || 0), stage = getPlantStage(s);
    $('dg-plant').textContent = stage.emoji; $('dg-stage').textContent = stage.name; $('dg-points').textContent = `${points.toLocaleString()} points`;
    $('dg-days').textContent = stage.next ? `${days} / ${stage.next} growth days` : `${days} growth days · flourishing`; 
    $('dg-progress').style.width = `${stage.next ? Math.max(0, Math.min(100, ((days - stage.from) / (stage.next - stage.from)) * 100)) : 100}%`;
    const validFocus = s?.digitalAwareness?.activeFocusSession && Date.now() < Date.parse(s.digitalAwareness.activeFocusSession.endsAt);
    $('dg-focus').textContent = validFocus ? 'Focus locked 🔒' : `Start strict Focus · ${selectedDuration}m`;
    const inferred = signal || s?.browsing?.pageSignals?.[hostname] || s?.browsing?.tabSignals && Object.values(s.browsing.tabSignals).find(x => x?.domain === hostname);
    if (inferred && ['productive','distracting','neutral'].includes(inferred.category)) {
      lastCategory = inferred.category; lastConfidence = Number(inferred.confidence) || 0;
    }
    const correction = s?.browsing?.pageCorrections?.[hostname]; const categoryDesc = correction ? `You marked ${correction.category === 'productive' ? 'useful' : correction.category === 'distracting' ? 'distracting' : 'neutral'} · saved locally` : lastCategory === 'productive' && lastConfidence >= 0.58 ? `Detected useful · ${Math.round(lastConfidence * 100)}%` : lastCategory === 'distracting' && lastConfidence >= 0.58 ? `Detected distraction · ${Math.round(lastConfidence * 100)}%` : 'Learning this page · no guess yet';
    $('dg-detection').textContent = validFocus ? `Focus active · points frozen. ${categoryDesc}` : categoryDesc;
    $('dg-focus-summary').textContent = validFocus ? `Focus is active until ${new Date(s.digitalAwareness.activeFocusSession.endsAt).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}. Points are paused.` : 'Choose a session length; points pause while Focus is active.';
    $('dg-focus').textContent = validFocus ? 'Focus locked 🔒' : `Start strict Focus · ${selectedDuration}m`;
    shadow.querySelectorAll('[data-dg-duration]').forEach(btn => { btn.disabled = Boolean(validFocus); btn.classList.toggle('selected', Number(btn.dataset.dgDuration) === selectedDuration); });
    const brain = s.aiCompanion || {}; const latest = brain.lastDecision || (brain.history || []).slice(-1)[0];
    $('dg-ai-status').textContent = !brain.enabled ? 'AI companion is off' : brain.lastStatus === 'thinking' ? 'Thinking…' : brain.lastError ? 'Needs attention' : 'AI companion is enabled';
    $('dg-ai-suggestion').textContent = latest ? `${String(latest.title || latest.action || 'Latest decision')}: ${String(latest.message || 'No message').slice(0,210)}` : (brain.enabled ? 'No decision yet. Select Think now to make the first one.' : 'Enable and configure AI from Coach in the mini-app.');
    const feedbackReady = Boolean(latest?.id && !latest.feedback && !latest.preview);
    $('dg-ai-helpful').disabled = !feedbackReady; $('dg-ai-notnow').disabled = !feedbackReady;
    const objectiveBox = $('dg-objectives'); objectiveBox.replaceChildren();
    const labels = Array.isArray(s.profile?.dailyObjectives) && s.profile.dailyObjectives.length === 3 ? s.profile.dailyObjectives : ['Work toward your main goal for 20 minutes','Move your body or get outside','Make time for a hobby, reading, connection or rest'];
    const today = new Date(); const day = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`; const claims=s.lifeGrowth?.objectiveCompletions?.[day]||{};
    const types=['studying','exercise','hobby']; labels.forEach((label,i)=>{const key=`objective-${i+1}`,done=claims[key];const button=document.createElement('button');button.type='button';button.className='dg-objective';button.dataset.objective=String(i);button.disabled=Boolean(done);const name=document.createElement('span');name.textContent=String(label||`Objective ${i+1}`).slice(0,100);const meta=document.createElement('small');meta.textContent=done?`✓ +${Number(done.points)||0}`:'Mark done';button.append(name,meta);objectiveBox.append(button);});
  }
  function setWidgetView(view) { if(!['grow','focus','coach','more'].includes(view)) return; activeView=view; shadow.querySelectorAll('[data-dg-view]').forEach(b=>b.classList.toggle('active',b.dataset.dgView===view)); shadow.querySelectorAll('[data-dg-pane]').forEach(p=>p.classList.toggle('active',p.dataset.dgPane===view)); }
  async function tell(message, bad=false) { $('dg-msg').textContent=message; $('dg-msg').style.color=bad?'#9b4430':'#3e6947'; }
  async function openFullDashboard(screen='grow') { try { const r=await chrome.runtime.sendMessage({type:'DG_OPEN_DASHBOARD',screen}); tell(r?.ok?'Opened the full dashboard.':(r?.error||'Could not open the dashboard.'),!r?.ok); } catch { tell('Could not open the dashboard. Try the extension icon.',true); } }
  async function runQuickCoach() { const b=$('dg-coach');b.disabled=true;try{const r=await chrome.runtime.sendMessage({type:'DG_AGENT_RUN_NOW'});if(!r?.ok)throw new Error(r?.error||'AI could not run. Check Coach setup in the mini-app.');tell('AI decision saved. Review the suggestion here or its in-page card.');const {dgState}=await chrome.storage.local.get(['dgState']);render(dgState||{});}catch(e){tell(e.message||'AI could not run.',true);}finally{b.disabled=false;} }
  async function correctCurrentPage(category) {
    const result = await chrome.runtime.sendMessage({ type: 'DG_SET_PAGE_CATEGORY', category });
    if (!result?.ok) throw new Error(result?.error || 'Could not update this page category.');
    tell(result.message || 'Page category updated.');
    const { dgState } = await chrome.storage.local.get(['dgState']); render(dgState || {});
  }
  async function allowCurrentPageInFocus() {
    const result = await chrome.runtime.sendMessage({ type: 'DG_ADD_CURRENT_TO_FOCUS_ALLOWLIST' });
    if (!result?.ok) throw new Error(result?.error || 'Could not add this site to Focus.');
    tell(result.message || 'Site added to Focus allowlist.');
    const { dgState } = await chrome.storage.local.get(['dgState']); render(dgState || {});
  }
  async function objectiveClick(index) { const i=Number(index); if(!Number.isInteger(i)||i<0||i>2)return;const stateNow=(await chrome.storage.local.get(['dgState'])).dgState||{};const defaults=['Work toward your main goal for 20 minutes','Move your body or get outside','Make time for a hobby, reading, connection or rest'];const labels=Array.isArray(stateNow.profile?.dailyObjectives)&&stateNow.profile.dailyObjectives.length===3?stateNow.profile.dailyObjectives:defaults;const types=['studying','exercise','hobby'];try{const r=await chrome.runtime.sendMessage({type:'DG_COMPLETE_OBJECTIVE',key:`objective-${i+1}`,activityType:types[i],label:labels[i]});if(!r?.ok)throw new Error(r?.error||'Could not save this check-in.');tell(r.alreadyComplete?'That step is already counted today.':`Nice step — +${r.completion?.points||0} growth points.`);render(r.state||stateNow);}catch(e){tell(e.message||'Could not save this check-in.',true);} }
  async function feedbackLatest(rating) { try{const {dgState}=await chrome.storage.local.get(['dgState']);const latest=dgState?.aiCompanion?.lastDecision||(dgState?.aiCompanion?.history||[]).slice(-1)[0];if(!latest?.id)throw new Error('There is no AI decision to rate yet.');const r=await chrome.runtime.sendMessage({type:'DG_AGENT_FEEDBACK',decisionId:latest.id,rating});if(!r?.ok)throw new Error(r?.error||'Could not save feedback.');tell('Thanks — this feedback will guide future suggestions.');const updated=await chrome.storage.local.get(['dgState']);render(updated.dgState||{});}catch(e){tell(e.message||'Could not save feedback.',true);} }

  function renderWidgetFromCurrentState(signal) {
    chrome.storage.local.get(['dgState']).then(({ dgState }) => render(dgState || {}, signal)).catch(() => {});
  }
  chrome.storage.local.get(['dgState','dgWidgetPosition','dgWidgetMinimized']).then(({ dgState, dgWidgetPosition, dgWidgetMinimized }) => {
    render(dgState || {});
    if (dgWidgetPosition) setPosition(dgWidgetPosition);
    if (dgWidgetMinimized) { root.classList.add('dg-min'); if (minimizeButton) minimizeButton.textContent = '+'; }
  }).catch(() => {});
  chrome.storage.onChanged.addListener(changes => {
    if (changes.dgState) render(changes.dgState.newValue || {});
    if (changes.dgWidgetPosition?.newValue && !drag) setPosition(changes.dgWidgetPosition.newValue);
    if (changes.dgWidgetMinimized) {
      root.classList.toggle('dg-min', Boolean(changes.dgWidgetMinimized.newValue));
      if (minimizeButton) minimizeButton.textContent = root.classList.contains('dg-min') ? '+' : '−';
    }
  });
  if (minimizeButton) {
    minimizeButton.addEventListener('click', () => {
      root.classList.toggle('dg-min');
      minimizeButton.textContent = root.classList.contains('dg-min') ? '+' : '−';
      safeStorageSet({ dgWidgetMinimized: root.classList.contains('dg-min') });
      const rect = root.getBoundingClientRect(); setPosition({ left: rect.left, top: rect.top }, true);
    });
  } else {
    console.warn('Digital Greenhouse widget loaded without its minimize button; other controls remain available.');
  }
  shadow.addEventListener('click', event => {
    const view = event.target.closest('[data-dg-view]'); if (view) { setWidgetView(view.dataset.dgView); return; }
    const duration = event.target.closest('[data-dg-duration]'); if (duration && !duration.disabled) { selectedDuration=Number(duration.dataset.dgDuration)||50; renderWidgetFromCurrentState(); return; }
    const category = event.target.closest('[data-dg-category]'); if (category && !category.disabled) { correctCurrentPage(category.dataset.dgCategory).catch(e => tell(e.message || 'Could not update page category.', true)); return; }
    const objective = event.target.closest('[data-objective]'); if (objective && !objective.disabled) { objective.disabled=true; objectiveClick(objective.dataset.objective); return; }
  });
  $('dg-allow-focus').addEventListener('click', () => allowCurrentPageInFocus().catch(e => tell(e.message || 'Could not allow this site in Focus.', true)));
  $('dg-open').addEventListener('click', async () => {
    if (Date.now() < suppressClickUntil) return;
    try { const result=await chrome.runtime.sendMessage({ type: 'DG_OPEN_MINI_APP' }); tell(result?.fallback ? 'Chrome opened the full dashboard because the popup could not open.' : 'Requested the toolbar mini-app.'); }
    catch { tell('The toolbar mini-app could not open. Use Full dashboard instead.',true); }
  });
  $('dg-dashboard').addEventListener('click', () => { if (Date.now() < suppressClickUntil) return; openFullDashboard('grow'); });
  $('dg-coach').addEventListener('click', () => { if (Date.now() < suppressClickUntil) return; runQuickCoach(); });
  $('dg-ai-helpful').addEventListener('click', () => feedbackLatest('helpful'));
  $('dg-ai-notnow').addEventListener('click', () => feedbackLatest('not_now'));
  $('dg-focus').addEventListener('click', async () => {
    if (Date.now() < suppressClickUntil) return;
    $('dg-focus').disabled = true;
    try {
      const { dgState } = await chrome.storage.local.get(['dgState']);
      const session = dgState?.digitalAwareness?.activeFocusSession;
      const validFocus = session && Date.now() < Date.parse(session.endsAt);
      if (validFocus) { $('dg-msg').textContent = `Strict Focus is locked until ${new Date(session.endsAt).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}. It cannot be ended early inside Digital Greenhouse.`; return; }
      const result = await chrome.runtime.sendMessage({ type: 'DG_START_FOCUS', durationMinutes: selectedDuration });
      $('dg-msg').textContent = result?.ok ? `Strict Focus is on for ${selectedDuration} minutes. Non-essential sites are blocked.` : (result?.error || 'Could not start Focus.');
    } catch { $('dg-msg').textContent = 'Could not change focus mode. Try the Chrome popup.'; }
    finally { $('dg-focus').disabled = false; }
  });
  const handle = $('dg-drag-handle');
  handle.addEventListener('pointerdown', event => {
    if (event.target.closest('button') || event.button !== 0) return;
    const rect = root.getBoundingClientRect();
    drag = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, left: rect.left, top: rect.top, moved: false };
    handle.setPointerCapture?.(event.pointerId); event.preventDefault();
  });
  handle.addEventListener('pointermove', event => {
    if (!drag || event.pointerId !== drag.pointerId) return;
    const dx = event.clientX - drag.startX, dy = event.clientY - drag.startY;
    if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
    setPosition({ left: drag.left + dx, top: drag.top + dy });
  });
  function endDrag(event) {
    if (!drag || (event && event.pointerId !== drag.pointerId)) return;
    const wasMoved = drag.moved, rect = root.getBoundingClientRect(); drag = null;
    if (wasMoved) { suppressClickUntil = Date.now() + 250; setPosition({ left: rect.left, top: rect.top }, true); }
  }
  handle.addEventListener('pointerup', endDrag); handle.addEventListener('pointercancel', endDrag);
  window.addEventListener('resize', () => { const r = root.getBoundingClientRect(); setPosition({ left: r.left, top: r.top }, true); });

  // Analyze once at load and again only when the route/content classification changes.
  analyzeAndSend();
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) { lastUrl = location.href; lastSentSignature = ''; lastSentAt = 0; visitId = newVisitId(); }
    analyzeAndSend();
  }, 15000);
  const mutationObserver = new MutationObserver(() => {
    if (document.visibilityState === 'hidden') return;
    clearTimeout(mutationObserver._timer);
    mutationObserver._timer = setTimeout(analyzeAndSend, 1800);
  });
  mutationObserver.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  // Friendly, local-only scrolling nudge during focus. No text or keystrokes are captured.
  let scrollStartedAt = 0, lastScrollAt = 0, nudgeSentForSession = null, nudgeInFlight = false;
  window.addEventListener('scroll', () => {
    const now = Date.now(); if (!lastScrollAt || now - lastScrollAt > 30000) scrollStartedAt = now; lastScrollAt = now;
  }, { passive: true });
  function showNudge(minutes) {
    if (document.getElementById('dg-focus-toast')) return;
    const toast = document.createElement('div'); toast.id = 'dg-focus-toast'; toast.textContent = `🐈 Tiny pause: you’ve been scrolling during focus for about ${minutes} minutes.`;
    toast.style.cssText = 'all:initial;position:fixed;z-index:2147483647;right:18px;bottom:18px;max-width:310px;padding:13px 15px;border:1px solid #cddfcd;border-radius:16px;background:#fbfff7;color:#264832;box-shadow:0 8px 32px #0002;font:13px/1.45 system-ui,sans-serif;';
    const close = document.createElement('button'); close.type = 'button'; close.textContent = 'Got it'; close.style.cssText = 'display:block;margin-top:8px;border:0;border-radius:8px;padding:6px 10px;background:#e5f2e4;color:#244a30;font-weight:700;cursor:pointer;'; close.addEventListener('click', () => toast.remove()); toast.append(close); (document.body || document.documentElement).append(toast);
  }
  setInterval(async () => {
    if (!scrollStartedAt || Date.now() - lastScrollAt > 30000 || document.visibilityState !== 'visible' || nudgeInFlight) { if (scrollStartedAt && Date.now() - lastScrollAt > 30000) scrollStartedAt = 0; return; }
    try {
      const { dgState } = await chrome.storage.local.get(['dgState']); const session = dgState?.digitalAwareness?.activeFocusSession;
      if (!session || Date.now() >= Date.parse(session.endsAt)) { scrollStartedAt = 0; return; }
      if (nudgeSentForSession === session.id) return;
      const threshold = Math.max(3, Math.min(10, Number(dgState.digitalAwareness?.nudgeAfterMinutes) || 5)); const elapsed = (Date.now() - scrollStartedAt) / 60000;
      if (elapsed < threshold) return;
      nudgeInFlight = true; const result = await chrome.runtime.sendMessage({ type: 'DG_SCROLL_NUDGE', observedMinutes: Math.round(elapsed) }).catch(() => null);
      nudgeSentForSession = session.id; scrollStartedAt = 0; if (result?.show) showNudge(result.observedMinutes || threshold);
    } catch {} finally { nudgeInFlight = false; }
  }, 10000);


  // Count actual recent scroll activity for feed/short-video escalation. We only send bounded
  // seconds and the extension derives the host from sender.url; no page text is sent.
  let scrollLastAccountAt = Date.now(), inactiveScrollReported = false, scrollMessageBusy = false;
  setInterval(async () => {
    const now = Date.now();
    if (scrollMessageBusy) return;
    const active = document.visibilityState === 'visible' && document.hasFocus() && lastScrollAt > 0 && now - lastScrollAt <= 25000;
    const becameInactive = lastScrollAt > 0 && now - lastScrollAt > 60000 && !inactiveScrollReported;
    const deltaSeconds = Math.max(0, Math.min(20, Math.floor((now - scrollLastAccountAt) / 1000)));
    scrollLastAccountAt = now;
    if (!active && !becameInactive) return; scrollMessageBusy = true;
    try {
      await chrome.runtime.sendMessage({ type: 'DG_SCROLL_ACTIVITY', active, deltaSeconds: active ? deltaSeconds : 0 }).catch(() => null);
      if (!active) { inactiveScrollReported = true; lastScrollAt = 0; scrollStartedAt = 0; }
    } catch {} finally { scrollMessageBusy = false; }
  }, 15000);
  // A new scroll activity resets the inactive guard. This timestamp says only that scrolling
  // occurred; it never records which keys were pressed or the values typed into a page.
  window.addEventListener('scroll', () => { inactiveScrollReported = false; }, { passive: true, capture: true });

  // AI-tool site pause: an opt-in, local-only timed intermission on configured AI-tool domains.
  // It is not a detector of AI-written text on arbitrary sites. No page content or input values
  // are ever captured or sent. A Shadow DOM overlay fully masks the page until a deliberate choice.
  const AI_USAGE_KEY = 'dgAiSiteUsage';
  const DEFAULT_AI_DOMAINS = ['chatgpt.com','gemini.google.com','claude.ai','perplexity.ai','copilot.microsoft.com','poe.com','character.ai','deepseek.com','meta.ai'];
  const localDay = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const hostIsInList = (host, list) => Array.isArray(list) && list.some(item => { const d=String(item||'').toLowerCase().replace(/^www\./,''); return host===d || host.endsWith('.'+d); });
  const animalQuotes = [
    ['🐈','A tiny pause can make room for your own idea.'], ['🦦','You can use tools without letting the tool choose your whole day.'],
    ['🦊','Take a breath. What do you want to do with the next five minutes?'], ['🐼','One thoughtful next step is enough for now.'],
    ['🐸','Stretch, sip water, or look away from the screen for a moment.'], ['🐕','You are allowed to use technology intentionally, not endlessly.']
  ];
  let aiPauseHost = null, aiPauseTimer = null, aiPauseCountdown = null, aiPauseUsageBusy = false, aiDisclosureCheckBusy = false, aiPauseOverlayReason = null;
  let lastAiInteractionAt = Date.now(), aiUsageLastTickAt = Date.now();
  function noteAiInteraction() { lastAiInteractionAt = Date.now(); }
  ['pointerdown','keydown','wheel','click'].forEach(type => document.addEventListener(type, noteAiInteraction, { capture: true, passive: true }));
  function removeAiPauseOverlay() {
    if (aiPauseCountdown) clearInterval(aiPauseCountdown); aiPauseCountdown = null;
    if (aiPauseHost?.isConnected) aiPauseHost.remove(); aiPauseHost = null; aiPauseOverlayReason = null;
  }
  async function updateAiUsage(update) {
    const saved = await chrome.storage.local.get([AI_USAGE_KEY]);
    let data = saved?.[AI_USAGE_KEY] && typeof saved[AI_USAGE_KEY] === 'object' ? saved[AI_USAGE_KEY] : { day: localDay(), domains: {} };
    if (data.day !== localDay()) data = { day: localDay(), domains: {} };
    data.domains ||= {};
    const prior = data.domains[hostname] && typeof data.domains[hostname] === 'object' ? data.domains[hostname] : { seconds: 0, cooldownUntil: 0, interruptions: 0 };
    const next = update({ ...prior });
    data.domains[hostname] = next;
    // Bound the local-only state; oldest hosts fall out first.
    const entries = Object.entries(data.domains).slice(-40); data.domains = Object.fromEntries(entries);
    await chrome.storage.local.set({ [AI_USAGE_KEY]: data });
    return next;
  }
  function showAiPauseOverlay(interruptions = 0, reason = 'site-time') {
    if (aiPauseHost?.isConnected || document.visibilityState === 'hidden') return;
    aiPauseOverlayReason = reason;
    const isDisclosure = reason === 'disclosure';
    const title = isDisclosure ? 'A page carries an AI-generated label' : 'Pause before the next prompt';
    const description = isDisclosure
      ? 'A clear AI-generated disclosure was found on this page. Take a moment to review it deliberately, or continue after a short pause.'
      : 'You have been actively using this AI tool for a while. Take a short reset, or continue intentionally after a brief pause.';
    const [animal, quote] = animalQuotes[Math.abs(Number(interruptions) || 0) % animalQuotes.length];
    aiPauseHost = document.createElement('div');
    aiPauseHost.id = 'dg-ai-content-interruption-root';
    aiPauseHost.style.cssText = 'all:initial;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;';
    const sh = aiPauseHost.attachShadow({ mode: 'closed' });
    sh.innerHTML = `<style>:host{all:initial;color-scheme:dark}*{box-sizing:border-box}.veil{position:fixed;inset:0;display:grid;place-items:center;padding:22px;background:radial-gradient(circle at 16% 10%,#353166 0,transparent 38%),radial-gradient(circle at 90% 88%,#124b57 0,transparent 42%),#0c1020;font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;color:#f0f2ff}.card{width:min(520px,100%);padding:clamp(24px,5vw,42px);background:linear-gradient(150deg,rgba(31,34,65,.98),rgba(17,22,43,.98));border:1px solid #3d456e;border-radius:28px;box-shadow:0 24px 80px #0009;text-align:center}.eyebrow{font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:#b8b1ff;font-weight:850}.animal{font-size:72px;line-height:1.2;margin:16px;filter:drop-shadow(0 7px 15px #0007)}.card h1{font-size:clamp(24px,5vw,34px);line-height:1.15;margin:10px 0;color:#f0f2ff}.quote{color:#cbd3f0;line-height:1.6;font-size:15px;margin:0 auto 20px;max-width:390px}.count{min-height:24px;font-weight:800;color:#7ee7d3;margin:12px 0}.actions{display:grid;grid-template-columns:1fr;gap:10px;margin-top:18px}.btn{appearance:none;border:1px solid transparent;border-radius:13px;padding:13px 16px;background:linear-gradient(120deg,#7c70ff,#30c6b1);color:#10152d;font:800 14px system-ui;cursor:pointer}.btn.secondary{background:#292f50;color:#ecedff;border-color:#4a5480}.btn:focus-visible{outline:3px solid #8ce8df;outline-offset:3px}.btn:disabled{opacity:.6;cursor:wait}.fine{font-size:11px;color:#aab4d8;margin-top:18px}@media(prefers-reduced-motion:reduce){.btn{transition:none}}@media(min-width:520px){.actions{grid-template-columns:1fr 1fr}}</style><div class="veil"><section class="card" role="dialog" aria-modal="true" aria-labelledby="dg-title"><div class="eyebrow">A small greenhouse pause</div><div class="animal" aria-hidden="true">${animal}</div><h1 id="dg-title">${title}</h1><p class="quote">${quote}</p><p class="quote">${description}</p><div class="count" id="count"></div><div class="actions"><button class="btn" id="reset">Take a 2-minute reset</button><button class="btn secondary" id="continue">Continue intentionally · 10 seconds</button></div><p class="fine">This pause is stored locally. Greenhouse never reads or uploads your prompts or responses.</p></section></div>`;
    (document.documentElement || document.body).append(aiPauseHost);
    const count = sh.getElementById('count'), reset = sh.getElementById('reset'), cont = sh.getElementById('continue');
    let mode = 'choose', remaining = 0;
    function startCountdown(seconds, nextMode) {
      if (aiPauseCountdown) clearInterval(aiPauseCountdown);
      mode = nextMode; remaining = seconds; reset.disabled = true; cont.disabled = true;
      count.textContent = nextMode === 'reset' ? 'Quiet time · 2:00' : 'Take a breath · 10';
      aiPauseCountdown = setInterval(() => {
        remaining -= 1;
        if (remaining <= 0) {
          clearInterval(aiPauseCountdown); aiPauseCountdown = null; reset.disabled = false; cont.disabled = false;
          if (mode === 'reset') { reset.textContent = 'I’m ready to return'; reset.onclick = async () => { await updateAiUsage(x => ({ ...x, seconds: 0, cooldownUntil: Date.now()+10*60000, lastShownAt: Date.now() })); removeAiPauseOverlay(); }; count.textContent = 'Two minutes complete. Return when ready.'; }
          else { cont.textContent = 'Ready — continue'; cont.onclick = async () => { await updateAiUsage(x => ({ ...x, seconds: 0, cooldownUntil: Date.now()+15*60000, lastShownAt: Date.now() })); removeAiPauseOverlay(); }; count.textContent = 'You’ve taken a deliberate pause.'; }
        } else count.textContent = nextMode === 'reset' ? `Quiet time · ${Math.floor(remaining/60)}:${String(remaining%60).padStart(2,'0')}` : `Take a breath · ${remaining}`;
      }, 1000);
    }
    reset.addEventListener('click', () => { if (mode === 'choose') startCountdown(120,'reset'); });
    cont.addEventListener('click', () => { if (mode === 'choose') startCountdown(10,'continue'); });
  }
  // Replace only content that is explicitly disclosed or semantically marked as AI-generated.
  // Prefer a single media/card container; never replace a whole page, form, chat or navigation.
  let aiItemsReplacedThisPage = 0;
  const MAX_AI_ITEMS_PER_PAGE = 5;
  function safeAiReplacementTarget(marker) {
    if (!marker || !marker.isConnected || !marker.parentElement) return null;
    let node = marker;
    for (let depth = 0; node && depth < 8; depth += 1, node = node.parentElement) {
      if (node === document.body || node === document.documentElement) break;
      let forbidden = false;
      try { forbidden = Boolean(node.matches('nav,header,footer,aside,form,[role="navigation"],[role="log"],[role="textbox"],[contenteditable="true"],[class*="chat" i],[id*="chat" i],[class*="message" i],[id*="message" i],#dg-floating-widget,#dg-ai-content-interruption-root,[data-dg-ai-replacement]')); } catch {}
      if (forbidden) break;
      const tag = String(node.tagName || '').toLowerCase();
      const structured = node.hasAttribute?.('data-ai-generated') && !['false','0','no','none'].includes(String(node.getAttribute('data-ai-generated') || '').toLowerCase())
        || ['true','1','yes'].includes(String(node.getAttribute?.('data-ai-content') || '').toLowerCase())
        || /ai[-_ ]generated/i.test(`${node.className?.baseVal || node.className || ''} ${node.id || ''} ${node.getAttribute?.('data-testid') || ''}`);
      let hasMedia = ['img','video','canvas','picture','svg'].includes(tag);
      try { hasMedia = hasMedia || Boolean(node.querySelector?.('img,video,canvas,picture,svg')); } catch {}
      let hintedCard = false;
      try { hintedCard = node.matches('figure,picture,[role="img"],[role="figure"],[role="article"],article,[data-testid*="post" i],[data-testid*="media" i],[class*="media" i],[class*="image" i],[class*="attachment" i],[class*="post" i],[class*="card" i]'); } catch {}
      // Structured metadata on a content container is strongest. For a plain disclosure badge,
      // require a content/media card so a label does not cause its surrounding page to disappear.
      const suitable = (structured && (hasMedia || (node.innerText || node.textContent || '').trim().length > 80)) || (hintedCard && hasMedia);
      if (!suitable) continue;
      const rect = node.getBoundingClientRect?.();
      if (rect && rect.width > 0 && rect.height > 0) {
        const viewportArea = Math.max(1, window.innerWidth * window.innerHeight);
        if (rect.width * rect.height > viewportArea * 0.88) continue;
      }
      return node;
    }
    return null;
  }
  function replaceAiItem(target, index) {
    if (!target?.isConnected || !target.parentNode || target.closest?.('[data-dg-ai-replacement]')) return false;
    if (aiItemsReplacedThisPage >= MAX_AI_ITEMS_PER_PAGE) return false;
    const rect = target.getBoundingClientRect?.();
    const minHeight = Math.round(Math.max(150, Math.min(320, Number(rect?.height) || 210)));
    const [animal, quote] = animalQuotes[(Math.abs(index) + aiItemsReplacedThisPage) % animalQuotes.length];
    const replacement = document.createElement('div');
    replacement.dataset.dgAiReplacement = 'true';
    replacement.setAttribute('data-dg-ai-replacement', 'true');
    replacement.style.cssText = `display:block;box-sizing:border-box;width:100%;max-width:100%;min-height:${minHeight}px;margin:12px 0;contain:content;`;
    const shadow = replacement.attachShadow({ mode: 'closed' });
    shadow.innerHTML = `<style>:host{display:block;font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;color:#f2f4ff;color-scheme:dark}*{box-sizing:border-box}.card{min-height:${minHeight}px;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:10px;padding:22px;background:radial-gradient(ellipse at 15% 0%,#353166 0,transparent 45%),linear-gradient(145deg,#171b35,#20264a 62%,#123b43);border:1px solid #424971;border-radius:20px;text-align:center;box-shadow:0 18px 52px #070b2080}.animal{font-size:44px;line-height:1.1;filter:drop-shadow(0 5px 10px #0005)}.tag{font-size:10px;font-weight:850;text-transform:uppercase;letter-spacing:.15em;color:#b8b1ff}.quote{max-width:440px;margin:0;font-size:14px;line-height:1.6;color:#e3e7ff}.buttons{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:5px}button{font:750 12px system-ui;border-radius:11px;padding:10px 13px;cursor:pointer;border:1px solid #4c5680;background:#303757;color:#edf0ff}button.primary{background:linear-gradient(120deg,#7c70ff,#30c6b1);color:#11152f;border-color:transparent}</style><section class="card" aria-label="Digital Greenhouse content replacement"><div class="tag">A little greenhouse reset</div><div class="animal" aria-hidden="true">${animal}</div><p class="quote">${quote}</p><p class="quote">This item was explicitly labelled AI-generated. Take a breath, then choose what you want to give your attention to.</p><div class="buttons"><button class="primary" id="keep">Keep the pause</button><button id="restore">Show original</button></div></section>`;
    const parent = target.parentNode;
    try { target.replaceWith(replacement); }
    catch { return false; }
    shadow.getElementById('restore')?.addEventListener('click', () => {
      if (replacement.isConnected) replacement.replaceWith(target);
    }, { once: true });
    shadow.getElementById('keep')?.addEventListener('click', () => {
      const btn = shadow.getElementById('keep');
      if (btn) { btn.disabled = true; btn.textContent = 'Pause kept 🌱'; }
    }, { once: true });
    // If site scripts detached the placeholder while rendering, do not retain page-owned nodes.
    if (!replacement.isConnected && parent?.isConnected) { try { parent.append(target); } catch {} return false; }
    aiItemsReplacedThisPage += 1;
    return true;
  }

  async function tickAiSitePause() {
    if (aiPauseUsageBusy) return; aiPauseUsageBusy = true;
    try {
      const stored = await chrome.storage.local.get(['dgState']); const state = stored?.dgState || {};
      const protect = state.digitalProtection || {};
      const featureEnabled = protect.aiContentInterruptionEnabled === true;
      const isAiToolSite = hostIsInList(hostname, (protect.aiToolDomains?.length ? protect.aiToolDomains : DEFAULT_AI_DOMAINS));
      if (!featureEnabled) { removeAiPauseOverlay(); return; }
      if (!isAiToolSite) { if (aiPauseOverlayReason === 'site-time') removeAiPauseOverlay(); return; }
      const now = Date.now(); const delta = Math.max(0, Math.min(20, Math.floor((now - aiUsageLastTickAt)/1000))); aiUsageLastTickAt = now;
      const active = document.visibilityState === 'visible' && document.hasFocus() && now - lastAiInteractionAt <= 180000 && !aiPauseHost;
      const current = await updateAiUsage(x => {
        x.seconds = Math.max(0, Math.min(86400, Number(x.seconds)||0)); x.cooldownUntil = Math.max(0, Number(x.cooldownUntil)||0); x.interruptions = Math.max(0, Number(x.interruptions)||0);
        if (active && now >= x.cooldownUntil) x.seconds = Math.min(86400, x.seconds + delta);
        return x;
      });
      if (active && now >= current.cooldownUntil && current.seconds >= Math.max(3,Math.min(15,Number(protect.aiContentThresholdMinutes)||5))*60) {
        const shown = await updateAiUsage(x => ({ ...x, seconds: 0, interruptions: Math.min(100000,(Number(x.interruptions)||0)+1), lastShownAt: now, cooldownUntil: now + 15*60000 }));
        showAiPauseOverlay(shown.interruptions - 1);
      }
    } catch {} finally { aiPauseUsageBusy = false; }
  }
  async function tickAiDisclosureReplacement() {
    if (aiDisclosureCheckBusy || aiPauseHost?.isConnected || document.visibilityState === 'hidden') return;
    aiDisclosureCheckBusy = true;
    try {
      const stored = await chrome.storage.local.get(['dgState']);
      const state = stored?.dgState || {};
      const protect = state.digitalProtection || {};
      if (protect.aiContentInterruptionEnabled !== true) return;
      const aiDomains = protect.aiToolDomains?.length ? protect.aiToolDomains : DEFAULT_AI_DOMAINS;
      // AI tools use the sustained-active-time pause. This path only reacts to explicit disclosure
      // markers on other pages and never tries to guess authorship from prose style.
      if (hostIsInList(hostname, aiDomains)) return;
      const detector = globalThis.DGLocalAiDisclosureDetector;
      const find = detector?.findExplicitAiDisclosures;
      const matches = typeof find === 'function' ? find(document, MAX_AI_ITEMS_PER_PAGE) : (detector?.detectExplicitAiDisclosure?.(document) ? [null] : []);
      if (!matches.length) return;
      const now = Date.now();
      const active = document.visibilityState === 'visible' && document.hasFocus() && now - lastAiInteractionAt <= 180000;
      if (!active) return;
      const local = await chrome.storage.local.get([AI_USAGE_KEY]);
      const usage = local?.[AI_USAGE_KEY]?.domains?.[hostname] || {};
      if (Number(usage.disclosureCooldownUntil) > now) return;
      let replaced = 0;
      for (const [index, marker] of matches.entries()) {
        if (!marker) continue;
        const target = safeAiReplacementTarget(marker);
        if (target && replaceAiItem(target, index)) replaced += 1;
        if (replaced >= 3) break; // Keep the experience calm on feed-style pages.
      }
      if (replaced) {
        await updateAiUsage(x => ({ ...x, interruptions: Math.min(100000, (Number(x.interruptions) || 0) + replaced), lastShownAt: now, lastReason: 'explicit-ai-disclosure-item-replacement', disclosureCooldownUntil: now + 10 * 60000 }));
        return;
      }
      // If no safe item container exists (e.g. an explicitly labelled text-only post), fall back
      // to the established full-page pause. Never replace a whole document or ambiguous element.
      if (Number(usage.cooldownUntil) > now) return;
      const shown = await updateAiUsage(x => ({ ...x, seconds: 0, interruptions: Math.min(100000, (Number(x.interruptions) || 0) + 1), lastShownAt: now, lastReason: 'explicit-ai-disclosure', cooldownUntil: now + 30 * 60000 }));
      showAiPauseOverlay(shown.interruptions - 1, 'disclosure');
    } catch {} finally { aiDisclosureCheckBusy = false; }
  }
  setInterval(tickAiSitePause, 15000);
  setInterval(tickAiDisclosureReplacement, 15000);
  tickAiSitePause();
  tickAiDisclosureReplacement();
  try { chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.dgState && changes.dgState.newValue?.digitalProtection?.aiContentInterruptionEnabled === false) removeAiPauseOverlay(); }); } catch {}

  // In-page reminders are handled by notification-content.js so they survive widget startup failures.
})();
