// Digital Greenhouse 3.3.1 — one configured AI service with automatic per-install enrollment.
(() => {
  'use strict';
  const config = globalThis.DGServiceConfig || {};
  const DEFAULT_ENDPOINT = String(config.defaultEndpoint || (config.mode === 'local' ? 'http://127.0.0.1:8787' : '')).trim();
  function cleanEndpoint(raw) {
    const candidate = String(raw || DEFAULT_ENDPOINT || '').trim();
    if (!candidate) throw new Error('The Digital Greenhouse service has not been connected by its publisher yet.');
    let u;
    try { u = new URL(candidate); }
    catch { throw new Error('The configured Greenhouse service address is invalid.'); }
    if (!['http:', 'https:'].includes(u.protocol)) throw new Error('The Greenhouse service URL must use HTTP or HTTPS.');
    if (u.username || u.password || u.search || u.hash || (u.pathname && u.pathname !== '/')) throw new Error('Use the service origin only, without credentials, path, query or fragment.');
    const local = ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname.toLowerCase());
    if (u.protocol === 'http:' && !local) throw new Error('A hosted Greenhouse service must use HTTPS. Plain HTTP is allowed only for localhost development.');
    return u.origin.replace(/\/$/, '');
  }
  function isLocalEndpoint(raw) {
    try { const u = new URL(String(raw || '')); return u.protocol === 'http:' && ['localhost','127.0.0.1','[::1]'].includes(u.hostname.toLowerCase()); }
    catch { return false; }
  }
  function configFromState(state) {
    let endpoint = String(state?.profile?.dataCollection?.endpoint || '').trim();
    if (config.mode === 'hosted' && (!endpoint || isLocalEndpoint(endpoint))) endpoint = DEFAULT_ENDPOINT;
    if (!endpoint) endpoint = DEFAULT_ENDPOINT;
    const token = String(state?.aiCompanion?.serviceAccessToken || '').trim().replace(/^Bearer\s+/i, '');
    return { endpoint: cleanEndpoint(endpoint), token };
  }
  function hasConsent(s) {
    const dc = s?.profile?.dataCollection || {};
    return dc.enabled === true && Boolean(dc.consentAt) && Number(dc.consentVersion) === Number(globalThis.DGData?.CONSENT_VERSION || 5);
  }
  async function readState() {
    const { dgState } = await chrome.storage.local.get('dgState');
    return dgState || {};
  }
  async function perform(url, options, token) {
    const headers = { Accept: 'application/json', ...(options.headers || {}) };
    if (token) headers.Authorization = `Bearer ${token}`;
    return fetch(url, { ...options, headers, cache: 'no-store' });
  }
  async function request(path, options = {}, state = null) {
    let s = state || await readState();
    let { endpoint, token } = configFromState(s);
    const relative = String(path).startsWith('/') ? path : `/${path}`;
    const shouldEnroll = hasConsent(s) && globalThis.DGData?.ensureServiceAccessToken && relative !== '/health' && relative !== '/v1/enroll';
    if (shouldEnroll) {
      const credential = await globalThis.DGData.ensureServiceAccessToken();
      token = credential.token || '';
      endpoint = credential.endpoint || endpoint;
      s = await readState();
    }
    let response = await perform(`${endpoint}${relative}`, options, token);
    if (response.status === 401 && hasConsent(s) && globalThis.DGData?.ensureServiceAccessToken) {
      const credential = await globalThis.DGData.ensureServiceAccessToken({ force: true });
      s = await readState();
      endpoint = credential.endpoint || configFromState(s).endpoint;
      response = await perform(`${endpoint}${relative}`, options, credential.token || '');
    }
    return response;
  }
  globalThis.DGAI = Object.freeze({ DEFAULT_ENDPOINT, cleanEndpoint, configFromState, request });
})();
