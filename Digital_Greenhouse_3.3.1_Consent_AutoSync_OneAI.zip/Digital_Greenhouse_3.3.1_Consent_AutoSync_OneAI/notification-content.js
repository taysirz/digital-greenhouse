// Digital Greenhouse 3.1.0 — in-page reminders, wellbeing flow and strict-lock feedback.
(() => {
  if (window.__dgNotificationBridgeReady) return;
  window.__dgNotificationBridgeReady = true;
  let host = null, dismissTimer = null;
  function removeCard() { if (dismissTimer) clearTimeout(dismissTimer); dismissTimer=null; if (host?.isConnected) host.remove(); host=null; }
  async function send(type, extra={}) { return await chrome.runtime.sendMessage({type,...extra}); }
  function showCard(message) {
    if (window.top !== window || !document.documentElement) return;
    removeCard(); host=document.createElement('div'); host.id='dg-inpage-notification-host';
    host.style.cssText='all:initial;position:fixed;z-index:2147483647;right:18px;top:18px;width:min(360px,calc(100vw - 36px));';
    const shadow=host.attachShadow({mode:'open'}), card=document.createElement('section');
    card.innerHTML=`<style>
      :host{all:initial}*{box-sizing:border-box;font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}
      section{padding:16px;border-radius:20px;border:1px solid #454b72;background:linear-gradient(145deg,#191e3b,#272149 65%,#123b45);color:#f4f6ff;box-shadow:0 18px 48px #0508178c;animation:in .22s ease-out;font-size:13px;line-height:1.5}
      header{display:flex;align-items:center;gap:9px;margin-bottom:9px}.mark{width:34px;height:34px;display:grid;place-items:center;border-radius:12px;background:linear-gradient(135deg,#6e6bf6,#2ac8ad);font-size:18px;color:#fff}
      strong{font-size:14px;line-height:1.3}.close{margin-left:auto;border:0;background:transparent;color:#bdc5e7;font-size:20px;cursor:pointer;padding:0 2px}
      p{margin:0;color:#d0d7f3;font-size:12px}footer{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap}button{border:1px solid transparent;border-radius:12px;padding:9px 11px;font-size:11px;font-weight:800;cursor:pointer;transition:transform .15s,opacity .15s}button:hover{transform:translateY(-1px)}button:disabled{opacity:.6;cursor:wait;transform:none}
      .primary{background:linear-gradient(120deg,#6f73ff,#3ac9bc);color:#080d27}.secondary{background:#323858;color:#e9edff;border-color:#535d87}.close{border:0}@keyframes in{from{opacity:0;transform:translateY(-7px)}to{opacity:1;transform:translateY(0)}}
      @media(prefers-reduced-motion:reduce){section{animation:none}button{transition:none}}@media(max-width:420px){section{padding:12px}}
    </style><section role="status" aria-live="polite"><header><span class="mark">✦</span><strong></strong><button class="close" type="button" aria-label="Dismiss">×</button></header><p></p><footer><button class="primary" type="button">Open Greenhouse</button><button class="secondary" type="button">Got it</button></footer></section>`;
    const title=card.querySelector('strong'), paragraph=card.querySelector('p'), primary=card.querySelector('.primary'), secondary=card.querySelector('.secondary');
    title.textContent=String(message?.title||'A Greenhouse check-in').slice(0,140); paragraph.textContent=String(message?.message||'Pause for a second and choose your next step.').slice(0,650);
    const close=()=>removeCard(); card.querySelector('.close').addEventListener('click',close);
    if (message?.kind==='agent' && message.agentDecisionId) {
      const decisionId=String(message.agentDecisionId).slice(0,80); secondary.textContent='Not now';
      secondary.addEventListener('click',()=>{try{const r=chrome.runtime.sendMessage({type:'DG_AGENT_FEEDBACK',decisionId,rating:'not_now'});if(r?.catch)r.catch(()=>{});}catch{}close();});
      if (message.agentAction==='suggest_focus') {
        const minutes=[25,50,90].includes(Number(message.focusMinutes))?Number(message.focusMinutes):50; primary.textContent=`Start strict Focus · ${minutes}m`;
        primary.addEventListener('click',async()=>{primary.disabled=true;try{const started=await send('DG_START_FOCUS',{durationMinutes:minutes,originDecisionId:decisionId});if(!started?.ok){paragraph.textContent=started?.error||'Focus could not start.';primary.disabled=false;return;}await send('DG_AGENT_FEEDBACK',{decisionId,rating:'helpful'});close();}catch(error){paragraph.textContent=error?.message||'Focus could not start.';primary.disabled=false;}});
      } else {primary.textContent='Helpful';primary.addEventListener('click',()=>{try{const r=chrome.runtime.sendMessage({type:'DG_AGENT_FEEDBACK',decisionId,rating:'helpful'});if(r?.catch)r.catch(()=>{});}catch{}close();});}
    } else if (message?.kind==='wellbeing-checkin') {
      primary.textContent="I'm okay"; secondary.textContent='Start 5-minute reset';
      primary.addEventListener('click',async()=>{primary.disabled=true;try{await send('DG_WELLBEING_CHECKIN_ACK',{response:'acknowledged'});close();}catch(e){paragraph.textContent=e?.message||'Could not save check-in.';primary.disabled=false;}});
      secondary.addEventListener('click',async()=>{secondary.disabled=true;try{const result=await send('DG_BREAK_START',{breakType:'short-reset'});if(!result?.ok)throw new Error(result?.error||'Could not start reset.');paragraph.textContent='Reset started. Step away from the computer for at least five minutes. Greenhouse checks computer inactivity, not your physical location.';primary.textContent='Understood';primary.disabled=false;secondary.textContent='Close';secondary.onclick=close;primary.onclick=close; if(dismissTimer)clearTimeout(dismissTimer);}catch(e){paragraph.textContent=e?.message||'Could not start reset.';secondary.disabled=false;}});
    } else if (message?.kind==='wellbeing-break') {
      primary.textContent='Start water + outside reset'; secondary.textContent='Skip this time';
      primary.addEventListener('click',async()=>{primary.disabled=true;try{const result=await send('DG_BREAK_START',{breakType:'hourly-water-outdoor'});if(!result?.ok)throw new Error(result?.error||'Could not start break.');paragraph.textContent='Reset started. Get water and step away for at least five minutes if possible. You will be asked to confirm; the extension cannot prove you went outdoors.';primary.textContent='Got it';secondary.textContent='Close';secondary.disabled=false;primary.onclick=close;secondary.onclick=close;if(dismissTimer)clearTimeout(dismissTimer);}catch(e){paragraph.textContent=e?.message||'Could not start break.';primary.disabled=false;}});
      secondary.addEventListener('click',async()=>{secondary.disabled=true;try{await send('DG_BREAK_SKIP',{breakId:String(message.breakId||'')});close();}catch{close();}});
    } else if (message?.kind==='wellbeing-break-check') {
      primary.textContent='I took it honestly'; secondary.textContent="I wasn't honest";
      primary.addEventListener('click',async()=>{primary.disabled=true;try{const result=await send('DG_BREAK_CONFIRM',{breakId:String(message.breakId||'')});if(!result?.ok){paragraph.textContent=result?.error||'The check could not be verified.';title.textContent=result?.locked?'Strict 60-minute lock activated 🔒':'Break not verified';primary.textContent='Okay';primary.disabled=false;secondary.textContent='Close';secondary.onclick=close;if(result?.locked)primary.onclick=close;return;}paragraph.textContent=result.log?.rewardPending?'Break logged. Your points and plant growth remain frozen during strict Focus; the reward will be processed after the lock ends.':`Break recorded honestly. ${result.points>0?`You earned ${result.points} adaptive growth points.`:'Your break was logged; the daily reward budget may be full.'}`;primary.textContent='Done';secondary.textContent='Close';primary.onclick=close;secondary.onclick=close;if(dismissTimer)clearTimeout(dismissTimer);}catch(e){paragraph.textContent=e?.message||'Could not confirm this break.';primary.disabled=false;}});
      secondary.addEventListener('click',async()=>{secondary.disabled=true;try{await send('DG_BREAK_ADMIT_LIE',{breakId:String(message.breakId||'')});title.textContent='Strict 60-minute lock activated 🔒';paragraph.textContent='You reported the check-in was not honest. Garden Guard will remain locked for one hour and cannot be ended early inside the extension.';primary.textContent='Understood';primary.onclick=close;secondary.textContent='Close';secondary.onclick=close;if(dismissTimer)clearTimeout(dismissTimer);}catch(e){paragraph.textContent=e?.message||'Could not apply the lock.';secondary.disabled=false;}});
    } else if (message?.kind==='wellbeing-lock') {
      primary.textContent='Understood'; secondary.textContent='Close'; primary.addEventListener('click',close); secondary.addEventListener('click',close);
    } else {
      secondary.addEventListener('click',close); primary.addEventListener('click',()=>{try{const request=chrome.runtime.sendMessage({type:'DG_OPEN_MINI_APP'});if(request&&typeof request.catch==='function')request.catch(()=>{});}catch{}close();});
    }
    shadow.append(card); document.documentElement.append(host); dismissTimer=window.setTimeout(close,message?.kind==='wellbeing-break-check'?60000:14000);
  }
  try { chrome.runtime.onMessage.addListener(message=>{if(message?.type==='DG_IN_APP_NOTIFICATION')showCard(message);}); } catch(error) { console.debug('Greenhouse reminder bridge could not start:',error?.message||error); }
})();
