# Digital Greenhouse 3.3.1 — Consent Auto-Sync & Unified AI 🌱

Digital Greenhouse is a Chrome extension for personal growth, focus, digital wellbeing, website protection and adaptive routines.

## What changed in 3.3.1

- **One data-sharing choice.** When the user accepts the clearly disclosed all-or-nothing Setup consent, the extension enrolls itself and starts uploading the complete supported local dataset automatically. There is no separate “give data” or upload button.
- **One hosted AI experience.** In the public build, one configured primary cloud model serves page understanding, Coach, plans, and proactive decisions. The user does not install Qwen/Ollama, choose a model, enter a key, or grant a separate hosted-AI checkbox.
- **Automatic retries.** Full-data sync runs after consent and periodically in the background. Temporary failures are shown plainly and retried.
- **Opt-out and deletion.** Turning consent off disables hosted AI locally and asks the server to revoke the installation; failed revocation is retried when the service is reachable. Previous server records remain until the user requests deletion.
- **Owner data export.** The private `/owner-dashboard` lets the project owner download the stored datasets for consenting installations to their own computer.
- **Less congested UI.** Duplicate connection controls are removed, long explanations and advanced tools remain collapsed, and optional Grow activity cards use the matching dark jewel palette instead of white surfaces.
- Existing routine, growth, tracking, focus, website protection, community-filter and page-correction safeguards are retained.

## Important: hosted service setup is not included

This ZIP contains the extension and backend source, not a deployed online service or a live AI-provider credential. `service-config.js` intentionally has an empty hosted API address and fails closed instead of silently sending data to localhost. A publisher must deploy the backend, configure private server environment variables, and set the real HTTPS service origin once before repackaging/distributing the public build. After that publisher setup, normal users do not configure the URL, tokens or AI model.

See [`START-HERE.txt`](START-HERE.txt) and [`PUBLIC-DEPLOYMENT.md`](PUBLIC-DEPLOYMENT.md). Until those one-time publisher steps are completed, consent can be saved locally, but the service reports that syncing/hosted AI is not connected and no remote upload occurs.

## Local development

1. Extract the ZIP and load the inner folder containing `manifest.json` through `chrome://extensions` → Developer mode → **Load unpacked**.
2. Copy `server/.env.example` to `server/.env` if it does not exist.
3. Start Ollama and the backend with `server/START-BACKEND.cmd`.
4. For local-only development, set `mode = 'local'` in `service-config.js` and keep `apiBaseUrl` empty. The local router supports your installed Qwen model and does not need a cloud key by default.

## Owner data dashboard

After a public backend is deployed and `DG_OWNER_ADMIN_TOKEN` is set privately, open `https://YOUR-SERVICE/owner-dashboard` and authenticate with that owner token. The page downloads a JSON export to the owner’s computer. Never include the owner token, signing secret, provider key, access tokens or collected export in the extension ZIP or public repository.

## Verification

Run `node tests/smoke.cjs` from this folder. The included tests cover consent-triggered enrollment/sync, one-consent hosted AI routing, owner export, secret filtering, consent revocation, and the existing extension regression tests. They use mocked providers where noted; they do not prove the real hosted model’s availability or quality, or certify live interactive Chrome behavior.

## Public beta limitation

The current backend uses a JSON file store for the small beta. It is **not an audited production data platform**. Before broad public use, move to a managed persistent database, verify tenant isolation, configure backups/retention/deletion and abuse controls, and review the privacy notice and applicable obligations. Do not collect other people’s data without clear informed consent.
