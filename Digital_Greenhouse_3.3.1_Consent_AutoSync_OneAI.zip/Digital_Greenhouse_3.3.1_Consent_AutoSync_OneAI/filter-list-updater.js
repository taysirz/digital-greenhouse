// Digital Greenhouse community-filter updater helpers.
// Only exact, maintainer-controlled HTTPS host lists are consumed. Arbitrary rules, regexes,
// redirects, cosmetic filters and allow-list syntax are deliberately ignored.
(function (root) {
  'use strict';
  const AD_LIST_URL = 'https://small.oisd.nl/domainswild2';
  const ADULT_LIST_URL = 'https://nsfw-small.oisd.nl/domainswild2';
  const ADULT_ID_START = 100000;
  const ADULT_LIMIT = 8000;
  const AD_ID_START = ADULT_ID_START + ADULT_LIMIT;
  const AD_LIMIT = 16000;
  const ID_END = AD_ID_START + AD_LIMIT;
  const MAX_COMMUNITY_RULES = ADULT_LIMIT + AD_LIMIT;
  const RESOURCE_TYPES = ['sub_frame', 'script', 'image', 'stylesheet', 'font', 'media', 'xmlhttprequest', 'ping', 'other', 'websocket'];

  function validDomain(host) {
    if (root.DGDomainUtils?.isDnsName) return root.DGDomainUtils.isDnsName(host);
    if (typeof host !== 'string' || !host || host.length > 253 || host.includes('..')) return false;
    const labels = host.split('.');
    return labels.length >= 2 && labels.every(label => label.length > 0 && label.length <= 63 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label)) && (/^[a-z]{2,}$/i.test(labels.at(-1)) || /^xn--[a-z0-9-]+$/i.test(labels.at(-1)));
  }
  function addIfValid(out, raw) {
    let host = String(raw || '').trim().toLowerCase().replace(/^\uFEFF/, '');
    host = host.replace(/^\*\./, '').replace(/^\|\|/, '').replace(/\^.*$/, '').replace(/\.$/, '');
    if (!host || host.includes('/') || host.includes('*') || host.includes('$') || host.includes(':') || host.includes('@')) return;
    if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host === 'localhost' || host.endsWith('.local')) return;
    if (validDomain(host)) out.add(host);
  }
  function parseDomainList(source) {
    if (typeof source !== 'string') throw new TypeError('Filter-list body must be text.');
    if (source.length > 8 * 1024 * 1024) throw new Error('Filter list exceeded the 8 MiB safety limit.');
    const domains = new Set();
    for (const original of source.split(/\r?\n/)) {
      let line = original.trim().replace(/^\uFEFF/, '');
      if (!line || line.startsWith('#') || line.startsWith('!') || line.startsWith('[') || line.startsWith('@@') || line.includes('##') || line.includes('#@#') || line.startsWith('/')) continue;
      // Accept hosts-file format as well as one-domain-per-line and simple ||domain^ entries.
      if (/^(?:0\.0\.0\.0|127\.0\.0\.1|127\.0\.0\.2|::1)\s+/i.test(line)) {
        const fields = line.split(/\s+/).slice(1);
        for (const host of fields) { if (host.startsWith('#')) break; addIfValid(domains, host); }
        continue;
      }
      const simpleAdblock = line.match(/^\|\|([a-z0-9.-]+)\^?(?:\$[a-z0-9_,~=-]+)?$/i);
      if (simpleAdblock) { addIfValid(domains, simpleAdblock[1]); continue; }
      // Rules with paths, regex, exceptions or options not matching the simple grammar are intentionally skipped.
      if (/^[a-z0-9.-]+\.?$/i.test(line) || /^\*\.[a-z0-9.-]+\.?$/i.test(line)) addIfValid(domains, line);
    }
    return [...domains];
  }
  function boundedSpread(values, limit) {
    const list = Array.isArray(values) ? values : [];
    const max = Math.max(0, Math.floor(Number(limit) || 0));
    if (list.length <= max) return list.slice();
    if (max === 0) return [];
    if (max === 1) return [list[0]];
    // Sample across the whole maintainer-ordered list rather than accidentally taking only A-D domains.
    const out = [];
    for (let i = 0; i < max; i++) out.push(list[Math.floor(i * (list.length - 1) / (max - 1))]);
    return [...new Set(out)];
  }
  function buildRules(options = {}) {
    const communityEnabled = options.communityEnabled !== false;
    const adEnabled = communityEnabled && options.adEnabled === true;
    const adultEnabled = communityEnabled && options.adultEnabled === true;
    const adDomains = boundedSpread(Array.isArray(options.adDomains) ? [...new Set(options.adDomains.filter(validDomain))] : [], AD_LIMIT);
    const adultDomains = boundedSpread(Array.isArray(options.adultDomains) ? [...new Set(options.adultDomains.filter(validDomain))] : [], ADULT_LIMIT);
    const extensionPath = String(options.blockedPagePath || '/blocked.html?reason=adult-community');
    const rules = [];
    if (adultEnabled) {
      for (let i = 0; i < adultDomains.length && i < ADULT_LIMIT; i++) {
        rules.push({ id: ADULT_ID_START + i, priority: 400, action: { type: 'redirect', redirect: { extensionPath } }, condition: { urlFilter: `||${adultDomains[i]}^`, resourceTypes: ['main_frame'] } });
      }
    }
    if (adEnabled) {
      for (let i = 0; i < adDomains.length && i < AD_LIMIT; i++) {
        rules.push({ id: AD_ID_START + i, priority: 1, action: { type: 'block' }, condition: { urlFilter: `||${adDomains[i]}^`, domainType: 'thirdParty', resourceTypes: RESOURCE_TYPES } });
      }
    }
    if (rules.length > MAX_COMMUNITY_RULES || (rules.length && (Math.min(...rules.map(r => r.id)) < ADULT_ID_START || Math.max(...rules.map(r => r.id)) >= ID_END))) {
      throw new Error('Community filter rules exceeded their reserved rule range.');
    }
    return rules;
  }
  root.DGFilterListUpdater = Object.freeze({ AD_LIST_URL, ADULT_LIST_URL, ADULT_ID_START, ADULT_LIMIT, AD_ID_START, AD_LIMIT, ID_END, MAX_COMMUNITY_RULES, RESOURCE_TYPES, parseDomainList, boundedSpread, buildRules });
  if (typeof module !== 'undefined' && module.exports) module.exports = root.DGFilterListUpdater;
})(typeof globalThis !== 'undefined' ? globalThis : this);
