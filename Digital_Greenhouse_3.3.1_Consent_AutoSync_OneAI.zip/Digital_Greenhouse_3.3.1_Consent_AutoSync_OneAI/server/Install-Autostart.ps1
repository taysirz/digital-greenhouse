$ErrorActionPreference = 'Stop'
$serverDir = $PSScriptRoot
$startupDir = [Environment]::GetFolderPath('Startup')
$shortcutPath = Join-Path $startupDir 'Digital Greenhouse Backend.lnk'
$launcher = Join-Path $serverDir 'START-BACKEND-HIDDEN.vbs'
if (-not (Test-Path -LiteralPath $launcher)) { throw 'The hidden backend launcher is missing.' }
$wsh = New-Object -ComObject WScript.Shell
$shortcut = $wsh.CreateShortcut($shortcutPath)
$shortcut.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
$shortcut.Arguments = '/B "' + $launcher + '"'
$shortcut.WorkingDirectory = $serverDir
$shortcut.Description = 'Starts the local-only Digital Greenhouse AI backend after Windows sign-in.'
$shortcut.Save()
Write-Host "Created: $shortcutPath"
Write-Host 'The backend starts only when server/.env exists and port 8787 is not already running. Ollama must also be running for local AI.'
