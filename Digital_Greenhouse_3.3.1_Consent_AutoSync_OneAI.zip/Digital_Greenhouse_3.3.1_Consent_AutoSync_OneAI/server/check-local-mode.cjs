'use strict';
// The Windows personal-use launchers call this guard so a hosted config is not
// accidentally bound to the user's laptop's network interface by a double-click.
const fs = require('node:fs');
const path = require('node:path');
const envPath = path.resolve(process.argv[2] || path.join(__dirname, '.env'));
let source;
try { source = fs.readFileSync(envPath, 'utf8'); }
catch (error) { console.error(`Cannot read the local backend config at ${envPath}: ${error.message}`); process.exit(2); }
const values = {};
for (const rawLine of source.split(/\r?\n/)) {
  const line = rawLine.trim();
  if (!line || line.startsWith('#')) continue;
  const cleaned = line.startsWith('export ') ? line.slice(7).trim() : line;
  const splitAt = cleaned.indexOf('=');
  if (splitAt < 1) continue;
  const key = cleaned.slice(0, splitAt).trim();
  let value = cleaned.slice(splitAt + 1).trim();
  if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
  else value = value.replace(/\s+#.*$/, '').trim();
  values[key] = value;
}
const publicMode = /^(1|true|yes|on)$/i.test(values.DG_PUBLIC_MODE || 'false');
const host = String(values.HOST || '127.0.0.1').toLowerCase();
const localHosts = new Set(['127.0.0.1', 'localhost', '::1', '[::1]']);
if (publicMode || !localHosts.has(host)) {
  console.error('This launcher is only for the local personal-use backend. It refuses public mode or non-loopback HOST settings. Deploy hosted mode behind HTTPS using PUBLIC-DEPLOYMENT.md.');
  process.exit(1);
}
console.log('Local-only backend configuration verified.');
