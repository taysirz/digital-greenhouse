$ErrorActionPreference = 'Stop'
$startupDir = [Environment]::GetFolderPath('Startup')
$shortcutPath = Join-Path $startupDir 'Digital Greenhouse Backend.lnk'
if (Test-Path -LiteralPath $shortcutPath) {
  Remove-Item -LiteralPath $shortcutPath -Force
  Write-Host 'Removed the Digital Greenhouse backend startup shortcut.'
} else {
  Write-Host 'No Digital Greenhouse backend startup shortcut was installed.'
}
