' Digital Greenhouse: opt-in Windows sign-in launcher.
' Starts only the loopback development API when the user has installed this optional startup helper.
Option Explicit
Dim shell, fso, folder, envPath, logPath, config, ts, request, errNum, command
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
envPath = fso.BuildPath(folder, ".env")
logPath = fso.BuildPath(folder, "backend.log")
If Not fso.FileExists(envPath) Then WScript.Quit 0
shell.CurrentDirectory = folder
' Fail closed: never let the sign-in helper expose a hosted/network-binding config from a personal laptop.
On Error Resume Next
errNum = shell.Run("cmd.exe /c node check-local-mode.cjs", 0, True)
If Err.Number <> 0 Then WScript.Quit 0
If errNum <> 0 Then WScript.Quit 0
Err.Clear
On Error GoTo 0
Set ts = fso.OpenTextFile(envPath, 1, False)
config = ts.ReadAll
ts.Close

' Avoid starting a second backend if a manual start is already running.
On Error Resume Next
Set request = CreateObject("WinHttp.WinHttpRequest.5.1")
request.SetTimeouts 400, 400, 400, 700
request.Open "GET", "http://127.0.0.1:8787/health", False
request.Send
errNum = Err.Number
If errNum = 0 Then
  If request.Status = 200 Then WScript.Quit 0
End If
Err.Clear
On Error GoTo 0

' Launch hidden and preserve diagnostics in backend.log; binding is fixed to loopback in .env.
commandLine = "cmd.exe /c cd /d " & Chr(34) & folder & Chr(34) & " && node --env-file=.env server.js >> " & Chr(34) & logPath & Chr(34) & " 2>&1"
shell.Run commandLine, 0, False
