@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js 20.6 or newer from https://nodejs.org/ and reopen this window.
  pause
  exit /b 1
)
for /f "tokens=1,2,3 delims=.v " %%a in ('node --version') do (
  set NODE_MAJOR=%%a
  set NODE_MINOR=%%b
)
if not defined NODE_MAJOR set NODE_MAJOR=0
if not defined NODE_MINOR set NODE_MINOR=0
if %NODE_MAJOR% LSS 20 (
  echo This backend needs Node.js 20.6 or newer. Current version:
  node --version
  pause
  exit /b 1
)
if %NODE_MAJOR% EQU 20 if %NODE_MINOR% LSS 6 (
  echo Node.js 20.6 or newer is required because this launcher uses --env-file. Current version:
  node --version
  pause
  exit /b 1
)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo Created server\.env with local-first AI defaults.
  echo No cloud API key is needed for local Ollama.
  start notepad.exe ".env"
  pause
  exit /b 0
)
node check-local-mode.cjs
if errorlevel 1 (
  echo The personal launcher refused this config. Hosted mode must run on a proper HTTPS host, not directly from this laptop.
  pause
  exit /b 1
)
echo Starting local Digital Greenhouse backend on 127.0.0.1:8787...
echo AI provider mode: local-first hybrid. Simple tasks stay on local Ollama; cloud routing is OFF by default.
echo Confirm qwen2.5:3b is installed with: ollama list
npm start
pause
