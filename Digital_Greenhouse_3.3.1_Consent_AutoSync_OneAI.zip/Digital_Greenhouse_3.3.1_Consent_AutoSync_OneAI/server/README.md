# Digital Greenhouse 3.3.1 backend

The same server can support local development or a separately deployed hosted service. Public mode is a limited beta scaffold, not an audited production platform.

## Local Windows development

1. Install Node.js 20+ and Ollama.
2. Confirm `qwen2.5:3b` is available (`ollama list`); if needed, run `ollama pull qwen2.5:3b`.
3. Copy `.env.example` to `.env` if it does not already exist. Preserve local development defaults.
4. Set `mode = 'local'` in the extension's parent `service-config.js`.
5. Run `START-BACKEND.cmd`; test `http://127.0.0.1:8787/health`. In local mode page classification stays local. Local AI is not shared with other users.
6. Optional Windows autostart helpers are for personal loopback development only. Never use them to expose a personal laptop as a public host.

## Public hosted mode

Use Node.js 20+ behind HTTPS and configure the environment variables in `../PUBLIC-DEPLOYMENT.md`. One-time owner tasks include private provider credentials, `DG_TOKEN_SECRET`, `DG_OWNER_ADMIN_TOKEN`, persistent storage, and setting the public service origin in the extension's `service-config.js`. The owner can then distribute a preconfigured extension; users only need the single data-sharing/hosted-AI consent.

The hosted model key remains only on the server. `/v1/enroll` creates a per-install expiring credential after consent; `/v1/ingest` receives a complete dataset snapshot; `/v1/revoke` disables future AI and ingestion; `/v1/admin/export` serves the owner-only dataset archive; `/owner-dashboard` is the download page. `GET /health` is a status signal only—use actual AI requests to verify the provider.

## Data storage warning

The included file-backed JSON store is only for limited beta/testing. Before broad use, use a persistent database, secure multi-user separation, backups, retention/deletion controls, durable abuse/rate limits, monitoring, and a reviewed privacy/security posture. Do not expose the owner token or model key.
