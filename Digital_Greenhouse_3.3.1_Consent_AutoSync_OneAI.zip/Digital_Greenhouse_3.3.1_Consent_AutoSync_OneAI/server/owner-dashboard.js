(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const button = $('download'), status = $('status'), summary = $('summary');
  button.addEventListener('click', async () => {
    const token = $('ownerToken').value.trim();
    if (token.length < 48) { status.textContent = 'Enter the private owner token configured on your service host.'; status.classList.add('error'); return; }
    button.disabled = true; button.textContent = 'Loading…'; status.classList.remove('error'); status.textContent = 'Requesting the server-side dataset…'; summary.classList.add('hidden');
    try {
      const response = await fetch('/v1/admin/export', { method:'GET', headers:{Authorization:`Bearer ${token}`,Accept:'application/json'}, cache:'no-store', credentials:'same-origin' });
      const body = await response.json().catch(() => ({}));
      if (!response.ok || body.ok !== true) throw new Error(body.error || `Export failed (HTTP ${response.status}).`);
      const metrics = [
        ['Installations', Number(body.installationCount)||0],
        ['Stored snapshots', Number(body.snapshotCount)||0]
      ];
      summary.replaceChildren();
      for (const [label,value] of metrics) { const card=document.createElement('div');card.className='metric';const strong=document.createElement('strong');strong.textContent=value.toLocaleString();const small=document.createElement('span');small.textContent=label;card.append(strong,small);summary.append(card); }
      summary.classList.remove('hidden');
      const blob = new Blob([JSON.stringify(body,null,2)], {type:'application/json'});
      const url = URL.createObjectURL(blob); const a=document.createElement('a');
      a.href=url; a.download=`digital-greenhouse-owner-export-${new Date().toISOString().slice(0,10)}.json`;
      document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),2000);
      status.textContent = `Downloaded ${body.installationCount||0} installation record(s) and ${body.snapshotCount||0} snapshot(s).`;
      // Intentionally don't retain the owner token after use.
      $('ownerToken').value='';
    } catch (error) {
      status.textContent = String(error?.message || 'Could not download server data.'); status.classList.add('error');
    } finally { button.disabled=false; button.textContent='Load summary & download JSON'; }
  });
})();
