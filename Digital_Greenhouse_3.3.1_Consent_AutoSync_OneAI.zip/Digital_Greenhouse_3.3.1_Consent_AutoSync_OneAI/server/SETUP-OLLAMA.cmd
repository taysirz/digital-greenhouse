@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" (
  copy ".env.example" ".env" >nul
  if errorlevel 1 (
    echo Could not create .env from .env.example.
    pause
    exit /b 1
  )
  echo Created server\.env with local-first defaults.
) else (
  echo Existing server\.env found; it will not be overwritten.
)
echo.
echo Digital Greenhouse uses local Ollama by default. No API key is needed.
echo Confirm your local model exists by running: ollama list
echo The default model is qwen2.5:3b. If needed, run: ollama pull qwen2.5:3b
echo.
echo Opening server\.env in Notepad so you can review the local-first settings.
echo Cloud fallback stays OFF unless you deliberately enable it and configure a private key.
echo.
notepad ".env"
echo After saving, run START-BACKEND.cmd to start the local API.
endlocal
