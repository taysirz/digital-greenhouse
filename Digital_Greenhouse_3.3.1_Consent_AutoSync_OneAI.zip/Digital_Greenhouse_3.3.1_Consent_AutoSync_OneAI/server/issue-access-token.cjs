#!/usr/bin/env node
'use strict';
// Run only on the trusted host/admin machine. Never publish generated access tokens.
const crypto = require('node:crypto');
const secret = String(process.env.DG_TOKEN_SECRET || '').trim();
if (Buffer.byteLength(secret, 'utf8') < 48 || /REPLACE|CHANGE_ME|YOUR_SECRET/i.test(secret)) {
  console.error('Set DG_TOKEN_SECRET to the same random secret used by the hosted server (at least 48 bytes).');
  process.exit(1);
}
const subject = String(process.argv[2] || '').trim();
if (!/^[A-Za-z0-9._-]{1,64}$/.test(subject)) {
  console.error('Usage: node --env-file=.env issue-access-token.cjs <user-label> [valid-days 1-90]');
  console.error('Use a non-sensitive label; do not put a real name or email address here.');
  process.exit(2);
}
const days = Number(process.argv[3] || 30);
if (!Number.isInteger(days) || days < 1 || days > 90) {
  console.error('Validity must be a whole number from 1 through 90 days.');
  process.exit(2);
}
const now = Math.floor(Date.now() / 1000);
const payload = Buffer.from(JSON.stringify({
  iss: 'digital-greenhouse', aud: 'dg-public-api', sub: subject,
  iat: now, exp: now + days * 86400,
  jti: crypto.randomBytes(12).toString('hex')
})).toString('base64url');
const signature = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
console.log(`\nDigital Greenhouse access token for ${subject} (expires in ${days} days):\n`);
console.log(`${payload}.${signature}\n`);
console.log('Copy this token to the user privately. It grants access to your hosted AI service until expiry.');
console.log('Never commit it, post it publicly, or embed it in the extension ZIP.');
