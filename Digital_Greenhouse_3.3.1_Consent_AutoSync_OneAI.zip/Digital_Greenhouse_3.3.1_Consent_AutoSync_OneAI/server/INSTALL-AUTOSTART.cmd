@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" (
  echo No server\.env was found.
  echo Run SETUP-OLLAMA.cmd first to create local-first settings.
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or newer is required. Install it from https://nodejs.org/ and reopen this window.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Autostart.ps1"
if errorlevel 1 (
  echo Could not install automatic startup. See the PowerShell error above.
  pause
  exit /b 1
)
echo.
echo Automatic startup installed for this Windows user.
echo The loopback-only backend will start hidden at sign-in; Ollama itself must also be running.
echo Remove it with REMOVE-AUTOSTART.cmd. This does not publish the backend to the internet.
pause
