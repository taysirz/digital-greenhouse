@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Remove-Autostart.ps1"
if errorlevel 1 (
  echo Could not remove the automatic startup shortcut.
  pause
  exit /b 1
)
echo Automatic startup entry removed. A currently running backend is not stopped by this action.
pause
