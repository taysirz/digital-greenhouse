#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const raw = String(process.argv[2] || '').trim();
if (!raw) {
  console.error('Usage: node configure-publisher.cjs https://YOUR-REAL-SERVICE-HOST');
  process.exit(2);
}
let url;
try { url = new URL(raw); }
catch { console.error('Invalid URL. Use the HTTPS origin of the deployed Greenhouse service.'); process.exit(2); }
if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash || (url.pathname && url.pathname !== '/') || !url.hostname || url.hostname.includes('your-service') || /example|placeholder|your-host|your-domain|\.test$|\.invalid$|\.localhost$/i.test(url.hostname)) {
  console.error('Invalid public service origin. Use a real HTTPS host only, without credentials, path, query or fragment.');
  process.exit(2);
}
const configPath = path.join(__dirname, 'service-config.js');
let source;
try { source = fs.readFileSync(configPath, 'utf8'); }
catch { console.error('Could not read service-config.js from this folder.'); process.exit(1); }
const pattern = /const apiBaseUrl = (?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*');/;
if (!pattern.test(source)) { console.error('Could not locate the publisher API URL in service-config.js; no files changed.'); process.exit(1); }
source = source.replace(pattern, `const apiBaseUrl = ${JSON.stringify(url.origin)};`);
try { fs.writeFileSync(configPath, source, 'utf8'); }
catch { console.error('Could not update service-config.js. Check folder permissions.'); process.exit(1); }
console.log(`Saved hosted service origin ${url.origin} to service-config.js.`);
console.log('No provider or owner secret was written. Repackage this configured folder before distributing it to users.');
