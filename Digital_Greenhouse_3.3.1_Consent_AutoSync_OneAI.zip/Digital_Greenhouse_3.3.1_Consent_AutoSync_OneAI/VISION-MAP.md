# Digital Greenhouse vision map — 3.3.0

This map describes source behavior and automated coverage. A passing automated test means the covered path works in its test environment; it does not certify every real browser/session.

## 1. Life Growth

- The plant has a long-term growth lifecycle, adaptive points, a separate plant-health model, guarded objectives, activity timers, and ledger/daily-cap protections against reward farming.
- Meaningful activity types include study, exercise, reading, hobbies/creative work, social connection, hydration, rest, coding/writing, chores, and custom activities.
- Automatic browsing rewards depend on confident productive signals, active foreground use and a daily ceiling. Opening a tab or leaving it idle cannot generate unlimited points. Neutral/uncertain pages do not qualify as useful.
- A user's local page correction overrides later automatic classification for that domain until the correction is reset. Corrections do not bypass explicit site blocks or locked Focus access rules.
- Focus pauses scoring and active activity timers; points are not deducted for distraction.

## 2. Digital Awareness

- 20-minute active-use check-ins and hourly hydration/outdoor prompts use foreground browser activity, not a claim about all Windows application usage.
- Routine windows, category transitions, dwell/scroll signals, page corrections and site learning feed local tracking and contextual coaching.
- Supported doomscroll/feed signals receive an escalating 5/7/9-minute warning ladder and a configured 10-minute firm stop, with reset rules and user correction paths.
- Reminders cannot prove someone performed a physical action, and page signals are imperfect estimates of intent.

## 3. Digital Protection

- Bundled adult/ad-tracker rules and optional approved community lists are applied locally, with validation, bounded rules and last-known-good recovery.
- User-maintained explicit block rules are distinct from page usefulness classification.
- Focus/Garden Guard allowlisting is a strict access-control list only. It is not a list of useful websites and does not determine growth points. There are no hard-coded starter exceptions in current runtime decisions.
- Fresh installs start with no pre-filled allowlist. Strict Focus explains the setup needed when empty; Garden Guard cannot be enabled with an empty list. The update migrates an unchanged old starter list away when doing so cannot interrupt an active strict Focus/Garden Guard configuration.
- Strict Focus cannot be ended early from inside the extension. Chrome extensions cannot stop themselves being disabled/uninstalled or control other browsers/apps.

## 4. AI Brain

- Local Qwen uses the bundled backend integration, bounded inference and validated action outputs. The source supports complexity-aware hybrid routing; cloud processing stays disabled by default, requires explicit separate consent and is not used for page usefulness classification.
- One explicit all-or-nothing data-sharing choice in Setup gates the whole Coach section and its complete supported context. There is no per-category selector. The UI states the actual server storage, processing and retention behavior; it does not promise automatic deletion after two weeks.
- Page usefulness combines local on-page signals and eligible local Qwen review with confidence checks and user corrections. A site's utility depends on the actual page/task, not only its domain. The classifier can still make mistakes and needs real-site evaluation.
- AI-generated-content pausing/replacement reacts to explicit disclosure labels/metadata. It does not claim to reliably detect unlabeled AI-written text.
- AI suggestions do not award points, change protection rules or override independent safety gates.

## 5. Data ownership

- Extension data remains in local Chrome extension storage by default. Full data sharing/sync is all-or-nothing and only after explicit consent; installation secrets are excluded from the sharing payload.
- The complete local export contains every Chrome extension-storage key and may contain private settings/tokens, so it must be kept private. Ollama model files, unrelated Windows files and other websites' local storage are outside that export.
- Remote data deletion/export remains available for the configured local/private backend where applicable. The included backend now has a token-protected hosted deployment mode, but its full-data storage and rate-limit persistence remain beta scaffolding rather than an audited multi-user service.

## 6. Interfaces and visual style

- Toolbar popup, floating widget, dashboard and mini-app continue to share state and growth logic.
- The entire dashboard page and mini-app outer shell now use the midnight-glass dark theme; legacy pale page gutters and dashboard metric/analytics cards were specifically corrected.
- Domain-control fields are tucked under an explanatory **Advanced domain rules** disclosure and distinguish explicit site access/blocking from AI page usefulness.

## 7. Verification status

- All 10 automated Node test files pass in this package, including public-AI connection checks.
- Live interactive Chrome acceptance, actual Qwen response quality/timing, live approved community filter downloads, and Windows startup install/uninstall still need a target-environment check. Details are in `FINAL-ACCEPTANCE.md`.

## 8. Hosted AI connection readiness

- Coach, page review, proactive decisions, daily plans and health checks use the configured Greenhouse service URL rather than a hard-coded localhost API.
- Hosted connections require HTTPS and an individual signed, expiring access token; upstream provider keys stay server-side.
- Public mode enforces token validity and basic per-token request quotas, while the existing Setup data consent and separate cloud-AI permission remain active.
- The bundled public backend is a deployment scaffold. It still needs hosting, real provider secrets, durable multi-tenant storage, token revocation/account management, persistent quotas, operations and privacy review before broad release.
