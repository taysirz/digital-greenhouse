/*
 * Digital Greenhouse publisher configuration.
 * Configure this ONCE before distributing a public build. Never place a provider key,
 * owner-admin token, or token-signing secret here.
 *
 * Public release: set apiBaseUrl to your deployed HTTPS service origin, for example
 *   https://your-service.onrender.com
 * Local development only: set mode to 'local' and leave apiBaseUrl blank.
 * A hosted build with a blank URL fails closed; it will not silently upload to localhost.
 */
(() => {
  'use strict';
  const mode = 'hosted'; // 'hosted' for users; 'local' only for local development.
  const apiBaseUrl = ''; // Publisher: set once to the real HTTPS service URL before distribution.
  const localDefault = 'http://127.0.0.1:8787';
  const configured = mode === 'local' || /^https:\/\//i.test(apiBaseUrl.trim());
  globalThis.DGServiceConfig = Object.freeze({
    mode,
    endpoint: apiBaseUrl.trim().replace(/\/$/, ''),
    defaultEndpoint: mode === 'local' ? localDefault : apiBaseUrl.trim().replace(/\/$/, ''),
    configured,
    isHosted: mode === 'hosted'
  });
})();
