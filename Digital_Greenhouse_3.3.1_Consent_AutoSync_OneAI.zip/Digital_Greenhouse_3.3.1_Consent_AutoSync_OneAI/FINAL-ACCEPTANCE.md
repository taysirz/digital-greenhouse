# Digital Greenhouse 3.3.1 — acceptance record

## Automated checks passed in this build

- JavaScript syntax and manifest/resource/UI ID wiring.
- Existing growth, active browsing, point ceiling, routine windows, Focus, protection, block/redirect, page-correction and community-filter regression coverage.
- Consent-triggered automatic enrollment and initial complete-dataset sync.
- Single server-recorded consent authorizes public hosted AI tasks without a second cloud-AI control.
- Secret fields removed from full-data uploads/AI context; invalid/expired/forged access tokens rejected.
- Owner dashboard/export is separately protected, and exported server datasets omit installation authentication secrets.
- Consent withdrawal deactivates the server installation and blocks future AI requests; old snapshots remain until explicit deletion.
- Optional Grow activity UI has matching dark theme styling, with collapsed advanced explanations and no duplicate test controls.

## Not verified

- Live hosted AI provider behavior, real response quality, rate limit/cost behavior or latency.
- Live interactive Chrome acceptance on every site or every OS.
- Live community-filter downloads or Windows launcher behavior.
- Production-grade persistent database, backup/restore, retention, monitoring and public service hardening.
- Hosted public use itself: this ZIP has an empty publisher URL in `service-config.js` and no private server secrets. The owner must complete `PUBLIC-DEPLOYMENT.md` before the consented auto-sync and hosted AI work for ordinary users.

## Honest status

The code-level consent, enrollment, sync, revocation, hosted AI routing, export and tests are implemented. This package is a **publisher-configurable beta release**, not a deployed production service.
