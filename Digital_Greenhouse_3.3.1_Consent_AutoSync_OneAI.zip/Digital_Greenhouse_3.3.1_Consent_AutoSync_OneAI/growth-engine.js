/* Digital Greenhouse 3.1.0 growth engine.
 * Pure, local-first scoring. It never reads pages or sends network requests.
 */
(function (root) {
  'use strict';

  const MAX_BROWSER_POINTS_PER_DAY = 20;
  const MAX_OFFSCREEN_POINTS_PER_DAY = 35;
  const PRODUCTIVE_TYPES = new Set(['studying','exercise','reading','hobby','social','hydration','rest','coding','writing','creative','chores','custom']);
  const RECOVERY_TYPES = new Set(['rest','social','hydration']);
  const METRIC_UNITS = new Set(['reps','sets','km','miles','laps','steps']);
  const CONTEXT_TYPES = new Set(['learning','reference','coding','writing','productivity','creative','social','entertainment','gaming','shopping','news','exercise','rest','general']);
  const clamp = (v, min, max) => Math.max(min, Math.min(max, Number.isFinite(Number(v)) ? Number(v) : min));
  // Clone Date instances: mutating a date while enumerating recent days must never mutate
  // the caller's timestamp or shift subsequent calculations into the wrong week.
  const dateOf = value => value instanceof Date ? new Date(value.getTime()) : new Date(value || Date.now());
  function dayKey(value = new Date()) {
    const d = dateOf(value);
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
  function recentDayKeys(now = new Date(), count = 7) {
    const keys = [];
    for (let i = count - 1; i >= 0; i--) { const d = dateOf(now); d.setDate(d.getDate() - i); keys.push(dayKey(d)); }
    return keys;
  }
  // Browsing rewards are visible on a normal short study session, then taper to avoid farming.
  // The engine still enforces the shared 20-point daily browser budget.
  function browserPointsAt(effectiveMinutes) {
    const m = Math.max(0, Number(effectiveMinutes) || 0);
    if (m <= 60) return Math.min(MAX_BROWSER_POINTS_PER_DAY, Math.floor(m / 6));
    if (m <= 120) return Math.min(MAX_BROWSER_POINTS_PER_DAY, 10 + Math.floor((m - 60) / 10));
    if (m <= 240) return Math.min(MAX_BROWSER_POINTS_PER_DAY, 16 + Math.floor((m - 120) / 20));
    return Math.min(MAX_BROWSER_POINTS_PER_DAY, 20 + Math.floor((m - 240) / 60));
  }
  // Doomscrolling is measured from recent scroll events, not merely how long a tab stays open.
  // Progress resets when scrolling stops long enough or the user switches to another page.
  function advanceScrollIntervention(previous, { domain = '', deltaSeconds = 0, now = Date.now(), active = true } = {}) {
    const stamp = Number(now) || Date.now();
    const host = String(domain || '').toLowerCase().replace(/^www\./, '').slice(0, 253);
    if (!active) return { progress: { domain: host, seconds: 0, warningStage: 0, lastSignalAt: stamp, stopped: false }, warnings: [], stop: false, seconds: 0 };
    const same = previous && previous.domain === host && Number.isFinite(Number(previous.lastSignalAt)) && stamp >= Number(previous.lastSignalAt) && stamp - Number(previous.lastSignalAt) <= 45000;
    const priorSeconds = same ? clamp(previous.seconds, 0, 600) : 0;
    const priorStage = same ? clamp(previous.warningStage, 0, 3) : 0;
    const add = clamp(deltaSeconds, 0, 20);
    const seconds = Math.min(600, priorSeconds + add);
    const warnings = [];
    for (const [stage, threshold] of [[1,300],[2,420],[3,540]]) if (priorStage < stage && seconds >= threshold) warnings.push({ stage, minutes: threshold / 60 });
    const stop = seconds >= 600 && !(same && previous.stopped === true);
    return {
      progress: { domain: host, seconds, warningStage: Math.max(priorStage, ...warnings.map(x => x.stage), 0), lastSignalAt: stamp, stopped: stop || (same && previous.stopped === true) },
      warnings, stop, seconds
    };
  }

  // Timer rewards are responsive: a genuine two-minute completed activity earns one point,
  // five minutes earns one, and sustained work then accumulates points with diminishing returns.
  // The shared 35-point daily off-screen cap prevents timer farming.
  function progressiveActivityPoints(minutes) {
    const m = Math.max(0, Number(minutes) || 0);
    if (m <= 60) return m >= 2 ? Math.max(1, Math.floor(m / 5)) : 0;
    if (m <= 120) return 12 + Math.floor((m - 60) / 10);
    return Math.min(24, 18 + Math.floor((m - 120) / 20));
  }
  function confidenceWeight({ confidence = 0.65, correction = false, pageKind = 'unknown', topicHints = [] } = {}) {
    // User corrections are feedback, never a confidence multiplier. Confidence must come from
    // independent page/activity evidence even if a correction is present.
    const c = clamp(confidence, 0, 1);
    if (c < 0.58) return 0;
    let weight = 0.45 + ((c - 0.58) / 0.42) * 0.55;
    if (['lesson','reference','technical_reference','editor','document','productivity_tool'].includes(pageKind)) weight += 0.025;
    if (Array.isArray(topicHints) && topicHints.some(x => ['learning','reference','coding','writing','productivity','creative'].includes(x))) weight += 0.025;
    return clamp(weight, 0.45, 1);
  }
  function sumTodayOffscreenPoints(state, day = dayKey()) {
    const events = state?.browsing?.pointEvents || [];
    return events.filter(e => ['objective','activity-timer','consistency-bonus'].includes(e?.source) && dayKey(e.createdAt) === day).reduce((sum,e) => sum + Math.max(0, Number(e.points) || 0), 0);
  }
  function contextTypeFromSignal(pageKind = 'unknown', topicHints = []) {
    const allowed = Array.isArray(topicHints) ? topicHints.filter(x => CONTEXT_TYPES.has(x)) : [];
    if (allowed.length) {
      const priority = ['learning','coding','writing','creative','productivity','reference','social','exercise','rest','entertainment','gaming','shopping','news'];
      return priority.find(x => allowed.includes(x)) || 'general';
    }
    const map = { lesson:'learning', technical_reference:'coding', reference:'reference', editor:'writing', document:'writing', productivity_tool:'productivity', article:'reference', social_feed:'social', short_video:'entertainment', video:'entertainment', forum:'social' };
    return map[pageKind] || 'general';
  }
  function textForGoals(state) {
    const s = state || {};
    const parts = [s.profile?.goalNotes, ...(Array.isArray(s.profile?.dailyObjectives) ? s.profile.dailyObjectives : []), ...(Array.isArray(s.profile?.routineGoals) ? s.profile.routineGoals : [])];
    const objectives = Object.values(s.lifeGrowth?.objectiveCompletions || {}).flatMap(x => Object.values(x || {}).map(y => y?.label));
    return [...parts, ...objectives, ...(s.aiCompanion?.dailyPlan?.objectives || []).map(x => x?.label)].filter(x => typeof x === 'string').join(' ').toLowerCase();
  }
  function goalMatchesType(state, type, label = '') {
    const all = `${textForGoals(state)} ${String(label || '').toLowerCase()}`;
    const words = {
      learning: /study|studying|school|homework|exam|learn|lesson|math|science|revision|course|education|academic/,
      studying: /study|studying|school|homework|exam|learn|lesson|math|science|revision|course|education|academic/,
      reference: /research|read|reading|reference|encyclopedia|learn|study|science|history/,
      coding: /cod(e|ing)|program|developer|debug|software|technical|computer science/,
      writing: /writ(e|ing)|essay|story|journal|language|composition|article/,
      productivity: /routine|task|project|organis|organiz|plan|work|priority|focus/,
      creative: /art|draw|music|design|creative|craft|instrument|paint|compose/,
      exercise: /exercise|fitness|workout|sport|run|walk|gym|strength|movement|push.?up/,
      social: /friend|family|relationship|connect|social|call|visit|community/,
      rest: /rest|sleep|recovery|relax|unwind|break|well.?being/,
      hydration: /water|hydrat|drink/,
      reading: /read|book|novel|literature/,
      hobby: /hobby|interest|practice|creative|music|art|game/,
      chores: /chore|clean|organis|organiz|housework|tidy/,
      custom: /goal|improve|progress|routine/
    };
    return Boolean(words[type] && words[type].test(all));
  }
  function uniqueActivityTypesForDay(state, day) {
    const types = new Set();
    for (const [key, minutes] of Object.entries(state?.lifeGrowth?.dailyTimedMinutesByType || {})) {
      if (key.startsWith(`${day}:`) && Number(minutes) > 0) types.add(key.slice(day.length + 1));
    }
    for (const item of Object.values(state?.lifeGrowth?.objectiveCompletions?.[day] || {})) if (item?.type) types.add(item.type);
    for (const type of state?.browsing?.dailyContextTypes?.[day] || []) types.add(type);
    return types;
  }
  function metricKey(type, label, unit) {
    if (type !== 'exercise' || !METRIC_UNITS.has(String(unit || ''))) return '';
    const normalizedLabel = String(label || '').normalize('NFKC').toLowerCase().trim()
      .replace(/[’']/g, '').replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 60);
    return normalizedLabel ? `exercise:${normalizedLabel}:${unit}` : '';
  }
  // Optional exercise measurements can represent effort in their own right, not just trigger
  // a tiny bonus on top of duration points. Unit-specific scales are deliberately capped and
  // coarse: the user-reported amount is never treated as medically validated performance.
  function metricQuantityPoints(quantityValue, quantityUnit) {
    const amount = Number(quantityValue), unit = String(quantityUnit || '');
    if (!Number.isFinite(amount) || amount <= 0 || amount > 100000 || !METRIC_UNITS.has(unit)) return 0;
    const raw = unit === 'reps' ? amount / 10
      : unit === 'sets' ? amount * 2
      : unit === 'km' ? amount * 2
      : unit === 'miles' ? amount * 3
      : unit === 'laps' ? amount
      : unit === 'steps' ? amount / 1000 : 0;
    return clamp(Math.floor(raw), 0, 12);
  }
  function metricProgressBonus(state, { type = 'custom', label = '', quantityValue = null, quantityUnit = '', metric = '', day = dayKey(), now = new Date() } = {}) {
    const key = metric || metricKey(type, label, quantityUnit);
    const amount = Number(quantityValue);
    if (!key || !Number.isFinite(amount) || amount <= 0 || amount > 100000) return 0;
    const ledgerKey = `${day}:${key}`;
    if (state?.lifeGrowth?.metricBonusDates?.[ledgerKey]) return 0;
    const referenceTime = dateOf(now).getTime();
    const history = (state?.lifeGrowth?.activityLog || []).filter(item => {
      const itemAmount = Number(item?.quantityValue);
      const timestamp = Date.parse(item?.endedAt || item?.startedAt || '');
      return item?.metricKey === key && item?.quantityUnit === quantityUnit && Number.isFinite(itemAmount) && itemAmount > 0
        && Number.isFinite(timestamp) && timestamp < referenceTime && referenceTime - timestamp <= 90 * 86400000;
    }).map(item => Number(item.quantityValue));
    if (!history.length) return 1; // Small one-time calibration bonus for establishing a measurable baseline.
    const best = Math.max(...history);
    const ratio = amount / best;
    if (ratio < 1.05) return 0;
    if (ratio >= 1.2) return 5;
    if (ratio >= 1.1) return 3;
    return 1;
  }
  // A deterministic, non-AI routine step. It never interprets missing data as zero and
  // only raises a target after the user has repeatedly met the current target.
  function suggestNextRoutineStep(state, now = new Date()) {
    const profile = state?.profile || {};
    const baseline = profile.routineBaseline || {};
    const priority = ['studying','exercise','reading','hobby','social','rest','hydration','coding','writing','creative','chores','custom'];
    let type = priority.includes(baseline.primaryType) ? baseline.primaryType : '';
    if (!type && baseline.studyMinutesPerDay !== null && baseline.studyMinutesPerDay !== undefined && baseline.studyMinutesPerDay !== '') type = 'studying';
    if (!type && baseline.readingMinutesPerDay !== null && baseline.readingMinutesPerDay !== undefined && baseline.readingMinutesPerDay !== '') type = 'reading';
    if (!type) return { ready: false, reason: 'choose-priority', message: 'Choose one area to improve and, if you know it, describe your usual routine. “Not sure” is a valid answer.' };
    const stated = configuredRoutineBaseline(state, type);
    if (stated === null) return { ready: false, reason: 'baseline-unknown', type, message: `Tell Greenhouse what ${type === 'studying' ? 'studying' : type} usually looks like for you, or leave it unknown until you are ready.` };
    const day = dayKey(now), keys = recentDayKeys(now, 7);
    const byType = state?.lifeGrowth?.dailyTimedMinutesByType || {};
    const logs = Array.isArray(state?.lifeGrowth?.activityLog) ? state.lifeGrowth.activityLog : [];
    const minutesByDay = Object.fromEntries(keys.map(key => [key, Math.max(0, Number(byType[`${key}:${type}`]) || 0)]));
    for (const item of logs) {
      if (item?.type !== type) continue;
      const stamp = item.endedAt || item.startedAt;
      if (!stamp) continue;
      const key = dayKey(stamp);
      if (Object.prototype.hasOwnProperty.call(minutesByDay, key)) minutesByDay[key] = Math.max(minutesByDay[key], Math.max(0, Number(item.actualMinutes) || 0));
    }
    const target = Math.max(0, Math.min(240, Math.round(stated)));
    const activeDays = keys.filter(key => minutesByDay[key] > 0).length;
    const metDays = keys.filter(key => minutesByDay[key] >= Math.max(1, target)).length;
    const nextTarget = target === 0 ? 5 : Math.min(240, target + Math.max(5, Math.round(target * 0.1)));
    const readyToIncrease = target > 0 && metDays >= 4;
    const suggestedMinutes = target === 0 ? 5 : (readyToIncrease ? nextTarget : target);
    const names = { studying: 'studying or learning', exercise: 'movement', reading: 'reading', hobby: 'your hobby', social: 'connection with people', rest: 'rest and recovery', hydration: 'hydration', coding: 'coding', writing: 'writing', creative: 'creative work', chores: 'chores', custom: 'your chosen priority' };
    let message;
    if (target === 0) message = `Start gently: try ${suggestedMinutes} minutes of ${names[type]}. This is a suggested first step, not a requirement.`;
    else if (readyToIncrease) message = `You've reached your ${target}-minute ${names[type]} target on ${metDays} of the last 7 days. If it still feels comfortable, try ${suggestedMinutes} minutes next.`;
    else message = `Keep your ${target}-minute ${names[type]} target for now. Greenhouse will suggest a small increase after you meet it on 4 of 7 days.`;
    return { ready: true, type, baselineMinutes: target, suggestedMinutes, activeDays, metDays, readyToIncrease, day, message };
  }
  const ACTIVITY_LABELS = {
    studying: 'learning', exercise: 'movement', reading: 'reading', hobby: 'your hobby',
    social: 'connection', rest: 'rest and recovery', hydration: 'hydration', coding: 'coding',
    writing: 'writing', creative: 'creative work', chores: 'chores', custom: 'a personal priority'
  };
  const ACTIVITY_ICONS = { studying: '📖', exercise: '🌤️', reading: '📚', hobby: '🎨', social: '💬', rest: '☁️', hydration: '💧', coding: '💻', writing: '✍️', creative: '🧩', chores: '🧹', custom: '🌱' };

  function objectiveLabelForType(type, minutes = null) {
    const n = Number(minutes);
    const timed = Number.isFinite(n) && n >= 5 ? Math.round(n) : null;
    const phrase = timed ? `${timed} minutes` : null;
    const labels = {
      studying: () => timed ? `Study or learn something for ${phrase}` : 'Make a small start on something you want to learn',
      exercise: () => timed ? `Move or get outside for ${phrase}` : 'Move your body or get outside for a little while',
      reading: () => timed ? `Read something for ${phrase}` : 'Read a little of something you enjoy',
      hobby: () => timed ? `Spend ${phrase} on a hobby you enjoy` : 'Make a little time for a hobby you enjoy',
      social: () => timed ? `Connect with someone for ${phrase}` : 'Connect with someone who matters to you',
      rest: () => timed ? `Take a guilt-free ${Math.max(5,Math.round(n))}-minute recovery break` : 'Take a guilt-free recovery break',
      hydration: () => 'Pause and have some water',
      coding: () => timed ? `Practise coding for ${phrase}` : 'Make a small step on a coding project',
      writing: () => timed ? `Write for ${phrase}` : 'Write a little, without needing to perfect it',
      creative: () => timed ? `Make or practise something creative for ${phrase}` : 'Make or practise something creative',
      chores: () => timed ? `Make one small responsibility easier in ${phrase}` : 'Make one small responsibility easier',
      custom: () => timed ? `Take one small step toward a goal for ${phrase}` : 'Take one small step toward a goal that matters to you'
    };
    return (labels[type] || labels.custom)();
  }

  // Map a user's own objective to a supported category. Ambiguous/unrecognised tasks stay
  // custom instead of silently inheriting an unrelated category from their position in the UI.
  function inferActivityTypeFromText(text, fallback = 'custom') {
    const t = String(text || '').normalize('NFKC').toLowerCase();
    const tests = [
      ['coding', /\b(code|coding|programming|debug|software|developer|python|javascript)\b/],
      ['hydration', /\b(water|hydrate|hydration|drink water)\b/],
      ['studying', /\b(study|studying|school|homework|exam|revision|revise|lesson|math|maths|science|learn|learning|course|class)\b/],
      ['reading', /\b(read|reading|book|books|novel|chapter|pages)\b/],
      ['exercise', /\b(exercise|workout|work out|fitness|gym|run|running|walk|walking|stretch|movement|sport|outside|push.?ups?|sit.?ups?)\b/],
      ['social', /\b(friend|friends|family|social|call someone|talk to|connect|connection|visit|relationship)\b/],
      ['rest', /\b(rest|sleep|recover|recovery|relax|relaxation|break|wind.?down|well.?being|wellbeing)\b/],
      ['writing', /\b(write|writing|essay|story|journal|composition|draft)\b/],
      ['creative', /\b(art|draw|drawing|paint|painting|design|create|creative|craft|instrument|compose|music practice)\b/],
      ['chores', /\b(chore|chores|clean|cleaning|tidy|organise|organize|housework)\b/],
      ['hobby', /\b(hobby|hobbies|interest|interests|practice a hobby|personal project)\b/]
    ];
    for (const [type, pattern] of tests) if (pattern.test(t)) return type;
    return PRODUCTIVE_TYPES.has(fallback) ? fallback : 'custom';
  }

  function priorDaysBefore(now = new Date(), count = 7) {
    const end = dateOf(now); end.setHours(12, 0, 0, 0); end.setDate(end.getDate() - 1);
    const keys = [];
    for (let i = count - 1; i >= 0; i--) { const d = dateOf(end); d.setDate(d.getDate() - i); keys.push(dayKey(d)); }
    return keys;
  }

  function dailyMinutesForType(state, type, days) {
    const byType = state?.lifeGrowth?.dailyTimedMinutesByType || {};
    const logs = Array.isArray(state?.lifeGrowth?.activityLog) ? state.lifeGrowth.activityLog : [];
    return Object.fromEntries(days.map(day => {
      let minutes = Math.max(0, Number(byType[`${day}:${type}`]) || 0);
      // Activity logs and the aggregate minutes map can describe the same session. Use the
      // greater daily total, not their sum, to avoid inflating progress when building a plan.
      const logged = logs.filter(item => item?.type === type && dayKey(item?.endedAt || item?.startedAt || 0) === day)
        .reduce((total, item) => total + Math.max(0, Number(item?.actualMinutes) || 0), 0);
      minutes = Math.max(minutes, logged);
      const checkins = Object.values(state?.lifeGrowth?.objectiveCompletions?.[day] || {}).filter(item => item?.type === type);
      const confirmedAdaptiveTarget = checkins.reduce((best, item) => {
        const target = item?.mode === 'adaptive' ? Number(item.targetMinutes) : 0;
        return Number.isFinite(target) && target >= 5 && target <= 180 ? Math.max(best, target) : best;
      }, 0);
      // A user-confirmed adaptive objective counts its own planned target toward the 7-day
      // progression model. Custom free-form check-ins count for variety only unless a timer records
      // actual minutes; they must not accidentally inflate a time-based baseline.
      const anyCheckin = checkins.length > 0;
      return [day, Math.max(minutes, confirmedAdaptiveTarget, anyCheckin ? 1 : 0)];
    }));
  }

  function adaptiveTargetMinutes(state, type, now = new Date(), defaultMinutes = 10) {
    const days = priorDaysBefore(now, 7);
    const observed = dailyMinutesForType(state, type, days);
    const amounts = days.map(day => observed[day] || 0);
    const active = amounts.filter(value => value > 0).sort((a,b) => a-b);
    const stated = configuredRoutineBaseline(state, type);
    // Unknown is not zero: without a declared baseline or local history use a moderate starter
    // target, and only grow after repeated history supports it.
    let target;
    if (stated !== null) target = stated === 0 ? 5 : Math.round(stated / 5) * 5;
    else if (active.length) target = Math.round(active[Math.floor((active.length - 1) / 2)] / 5) * 5;
    else target = defaultMinutes;
    target = clamp(target, 5, 60);
    const metDays = amounts.filter(value => value >= target).length;
    const readyToIncrease = metDays >= 4;
    if (readyToIncrease) target = Math.min(60, target + Math.max(5, Math.round(target * 0.1 / 5) * 5));
    return { minutes: clamp(target, 5, 60), metDays, readyToIncrease, observedDays: active.length, baselineKnown: stated !== null };
  }

  function resolveDailyObjectiveMode(savedMode, savedObjectives, defaultObjectives = []) {
    if (savedMode === 'adaptive' || savedMode === 'custom') return savedMode;
    const defaults = Array.isArray(defaultObjectives) && defaultObjectives.length === 3 ? defaultObjectives : [];
    const labels = Array.isArray(savedObjectives) && savedObjectives.length === 3 ? savedObjectives : defaults;
    return labels.every((label, index) => String(label || '').trim() === String(defaults[index] || '')) ? 'adaptive' : 'custom';
  }

  function objectiveDisplayTask(task, completion) {
    const current = task && typeof task === 'object' ? task : {};
    if (!completion || typeof completion !== 'object') return { ...current, completed: false };
    // A completed slot remains attached to the task the user actually confirmed, even if they
    // change their routine settings or custom labels later in the same day.
    const type = PRODUCTIVE_TYPES.has(completion.type) ? completion.type : (current.type || 'custom');
    const storedTarget = Number(completion.targetMinutes);
    const targetMinutes = Number.isFinite(storedTarget) && storedTarget >= 5 && storedTarget <= 180 ? storedTarget : current.targetMinutes ?? null;
    return {
      ...current,
      label: String(completion.label || current.label || 'Completed step').slice(0, 120),
      type,
      targetMinutes,
      mode: completion.mode === 'adaptive' || completion.mode === 'custom' ? completion.mode : (current.mode || 'custom'),
      icon: ACTIVITY_ICONS[type] || current.icon || '🌱',
      completed: true,
      points: Math.max(0, Number(completion.points) || 0),
      completedAt: completion.completedAt || null
    };
  }

  function buildDailyObjectives(state, now = new Date()) {
    const profile = state?.profile || {};
    const saved = Array.isArray(profile.dailyObjectives) && profile.dailyObjectives.length === 3
      ? profile.dailyObjectives : ['Work toward your main goal for 20 minutes', 'Move your body or get outside', 'Make time for a hobby, reading, connection or rest'];
    const mode = profile.dailyObjectiveMode === 'custom' ? 'custom' : 'adaptive';
    const day = dayKey(now);
    if (mode === 'custom') {
      return saved.map((raw, index) => {
        const label = String(raw || '').trim().slice(0, 100) || `Objective ${index + 1}`;
        const matchedMinutes = label.match(/\b(\d{1,3})\s*(?:min|mins|minutes?)\b/i);
        const targetMinutes = matchedMinutes ? clamp(Number(matchedMinutes[1]), 5, 180) : null;
        return { key: `objective-${index + 1}`, type: inferActivityTypeFromText(label), label, targetMinutes, icon: ACTIVITY_ICONS[inferActivityTypeFromText(label)], mode, day };
      });
    }

    const rb = profile.routineBaseline || {};
    const notes = `${String(profile.goalNotes || '')} ${String(profile.routineNotes || '')}`;
    const goalType = inferActivityTypeFromText(notes, 'custom');
    let primaryType = PRODUCTIVE_TYPES.has(rb.primaryType) && rb.primaryType ? rb.primaryType : '';
    if (!primaryType && rb.studyMinutesPerDay !== null && rb.studyMinutesPerDay !== undefined && rb.studyMinutesPerDay !== '') primaryType = 'studying';
    if (!primaryType && rb.readingMinutesPerDay !== null && rb.readingMinutesPerDay !== undefined && rb.readingMinutesPerDay !== '') primaryType = 'reading';
    if (!primaryType && notes.trim()) primaryType = goalType !== 'custom' ? goalType : '';
    const hasPrimary = Boolean(primaryType);
    // With no user-defined focus or goal, don't presume that schoolwork is the user's priority.
    const primary = hasPrimary
      ? (() => { const target = primaryType === 'hydration' ? null : adaptiveTargetMinutes(state, primaryType, now, 10).minutes; return { type: primaryType, targetMinutes: target, label: objectiveLabelForType(primaryType, target) }; })()
      : { type: 'custom', targetMinutes: 10, label: objectiveLabelForType('custom', 10) };

    const days = priorDaysBefore(now, 7);
    const rotation = Number(day.slice(-2)) % 7;
    const balancePool = ['exercise','reading','social','rest','hobby','creative','hydration','chores'];
    const observedCounts = {};
    for (const type of balancePool) {
      const daily = dailyMinutesForType(state, type, days);
      observedCounts[type] = { days: Object.values(daily).filter(n => n > 0).length, minutes: Object.values(daily).reduce((a,b) => a+b, 0) };
    }
    const chooseBalanced = (excluded) => balancePool.filter(type => !excluded.has(type)).sort((a,b) => {
      const aa = observedCounts[a], bb = observedCounts[b];
      return aa.days - bb.days || aa.minutes - bb.minutes || ((balancePool.indexOf(a) + rotation) % balancePool.length) - ((balancePool.indexOf(b) + rotation) % balancePool.length);
    })[0] || 'rest';
    const used = new Set([primary.type]);
    const secondType = chooseBalanced(used); used.add(secondType);
    const thirdType = chooseBalanced(used);
    const targetFor = (type, defaultMinutes = 10) => adaptiveTargetMinutes(state, type, now, defaultMinutes).minutes;
    const taskFor = (type, index) => {
      const oneShot = type === 'hydration';
      const minutes = oneShot ? null : targetFor(type, type === 'rest' ? 5 : 10);
      return { key: `objective-${index}`, type, targetMinutes: minutes, label: objectiveLabelForType(type, minutes), icon: ACTIVITY_ICONS[type] || '🌱', mode, day };
    };
    return [
      { key: 'objective-1', type: primary.type, targetMinutes: primary.targetMinutes, label: primary.label, icon: ACTIVITY_ICONS[primary.type] || '🌱', mode, day },
      taskFor(secondType, 2),
      taskFor(thirdType, 3)
    ];
  }

  function configuredRoutineBaseline(state, type) {
    const baseline = state?.profile?.routineBaseline;
    if (!baseline) return null;
    const field = type === 'studying' ? 'studyMinutesPerDay' : type === 'reading' ? 'readingMinutesPerDay' : null;
    const structuredValue = field ? baseline[field] : null;
    if (structuredValue !== null && structuredValue !== undefined && structuredValue !== '' && Number.isFinite(Number(structuredValue))) return clamp(structuredValue, 0, 480);
    // The optional custom priority keeps the model useful for hobbies, connection, rest,
    // hydration, creative work, chores and any one user-selected area. Unknown is never zero.
    if (baseline.primaryType !== type) return null;
    const value = baseline.minutesPerDay;
    if (value === null || value === undefined || value === '' || !Number.isFinite(Number(value))) return null;
    return clamp(value, 0, 480);
  }
  function localWeekKeysBeforeDay(value) {
    const match = String(value || dayKey()).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) return [];
    const year = Number(match[1]), month = Number(match[2]), day = Number(match[3]);
    const target = new Date(year, month - 1, day, 12, 0, 0, 0);
    if (!Number.isFinite(target.getTime())) return [];
    const daysSinceMonday = (target.getDay() + 6) % 7;
    const keys = [];
    for (let back = daysSinceMonday; back > 0; back--) keys.push(dayKey(new Date(year, month - 1, day - back, 12, 0, 0, 0)));
    return keys;
  }
  function hasCompletedTypeOnDay(state, type, day) {
    const timed = Math.max(0, Number(state?.lifeGrowth?.dailyTimedMinutesByType?.[`${day}:${type}`]) || 0);
    if (timed > 0) return true;
    if (Object.values(state?.lifeGrowth?.objectiveCompletions?.[day] || {}).some(item => item?.type === type)) return true;
    return (state?.lifeGrowth?.activityLog || []).some(item => item?.type === type && dayKey(item.endedAt || item.startedAt || 0) === day && Math.max(0, Number(item.actualMinutes) || 0) > 0);
  }
  function weeklyConsistencyBonus(state, type, day) {
    if (type !== 'exercise') return 0;
    const rawTarget = state?.profile?.routineBaseline?.exerciseDaysPerWeek;
    // Null means unknown; an explicit zero means that any exercise day exceeds the stated baseline.
    if (rawTarget === null || rawTarget === undefined || rawTarget === '' || !Number.isFinite(Number(rawTarget))) return 0;
    const target = clamp(rawTarget, 0, 7);
    const priorDays = localWeekKeysBeforeDay(day);
    const activeDays = priorDays.filter(key => hasCompletedTypeOnDay(state, type, key)).length;
    const alreadyAwarded = Boolean(state?.lifeGrowth?.weeklyProgressBonusDates?.[`${day}:${type}`]);
    const awardsThisWeek = priorDays.filter(key => Boolean(state?.lifeGrowth?.weeklyProgressBonusDates?.[`${key}:${type}`])).length;
    // Reward a distinct exercise day above the user's stated weekly baseline, at most twice per week.
    return !alreadyAwarded && activeDays >= target && awardsThisWeek < 2 ? 2 : 0;
  }
  function priorDailyTypeBaseline(state, type, now = new Date()) {
    const referenceTime = dateOf(now).getTime();
    const keys = recentDayKeys(referenceTime - 86400000, 7);
    const byType = state?.lifeGrowth?.dailyTimedMinutesByType || {};
    const vals = keys.map(d => Math.max(0, Number(byType[`${d}:${type}`]) || 0)).filter(x => x > 0);
    if (vals.length) return vals.reduce((a,b)=>a+b,0)/vals.length;
    const logs = (state?.lifeGrowth?.activityLog || []).filter(x => x?.type === type && Date.parse(x.endedAt || x.startedAt || 0) < referenceTime - 86400000 && Date.parse(x.endedAt || x.startedAt || 0) >= referenceTime - 14 * 86400000).map(x => Math.max(0, Number(x.actualMinutes) || 0)).filter(x => x > 0);
    if (logs.length) return logs.reduce((a,b)=>a+b,0)/logs.length;
    // Unknown stays null; explicitly reported zero is a real baseline, not missing data.
    return configuredRoutineBaseline(state, type);
  }
  function activityRewardBreakdown(state, { type = 'custom', label = '', priorTypeMinutes = 0, newTypeMinutes = 0, quantityValue = null, quantityUnit = '', metric = '', now = new Date(), day = dayKey(now) } = {}) {
    const prior = Math.max(0, Number(priorTypeMinutes) || 0), next = Math.max(prior, Number(newTypeMinutes) || 0);
    const basePoints = Math.max(0, progressiveActivityPoints(next) - progressiveActivityPoints(prior));
    const progressKey = `${day}:${type}`;
    const progressAwarded = Boolean(state?.lifeGrowth?.progressBonusDates?.[progressKey]);
    const baselineValue = priorDailyTypeBaseline(state, type, now);
    const baselineKnown = baselineValue !== null && Number.isFinite(Number(baselineValue));
    const baseline = baselineKnown ? Math.max(0, Number(baselineValue)) : 0;
    const threshold = baselineKnown ? baseline + Math.max(10, baseline * 0.25) : 30;
    const progressBonus = (!progressAwarded && next >= threshold && prior < threshold) ? (baselineKnown ? 2 : 1) : 0;
    const goalKey = `${day}:${type}`;
    const goalAwarded = Boolean(state?.lifeGrowth?.goalBonusDates?.[goalKey]);
    const goalBonus = (!goalAwarded && basePoints > 0 && goalMatchesType(state, type, label)) ? 1 : 0;
    const alreadyTypes = uniqueActivityTypesForDay(state, day);
    const varietyCount = Number(state?.lifeGrowth?.dailyVarietyBonusCount?.[day]) || 0;
    const varietyBonus = (!alreadyTypes.has(type) && varietyCount < 3 && basePoints > 0) ? 1 : 0;
    const weeklyBonus = basePoints > 0 ? weeklyConsistencyBonus(state, type, day) : 0;
    const measurableSession = next - prior >= 5;
    const validQuantity = Number.isFinite(Number(quantityValue)) && Number(quantityValue) > 0 && Number(quantityValue) <= 100000 && METRIC_UNITS.has(String(quantityUnit));
    const resolvedMetric = validQuantity ? (metric || metricKey(type, label, quantityUnit)) : '';
    let metricEffortPoints = 0;
    if (resolvedMetric) {
      const measuredScore = metricQuantityPoints(quantityValue, quantityUnit);
      // Within one day, the same metric only contributes its new best-score difference. A
      // repeated identical entry still earns any legitimate time-based points, but cannot farm
      // the quantity component by starting and finishing the timer repeatedly.
      const sameDayBest = (state?.lifeGrowth?.activityLog || []).reduce((best, item) => {
        const stamp = item?.endedAt || item?.startedAt;
        return item?.metricKey === resolvedMetric && stamp && dayKey(stamp) === day
          ? Math.max(best, Number(item?.quantityValue) || 0) : best;
      }, 0);
      metricEffortPoints = Math.max(0, measuredScore - metricQuantityPoints(sameDayBest, quantityUnit));
    }
    // Use the stronger of measured output or active duration, rather than adding both together
    // and double-counting the same session. Personal progress, goal, variety and consistency
    // bonuses remain separate and are all subject to the daily point budget.
    const awardedBasePoints = Math.max(basePoints, metricEffortPoints);
    const metricBonus = awardedBasePoints > 0 || measurableSession ? metricProgressBonus(state, { type, label, quantityValue: validQuantity ? quantityValue : null, quantityUnit, metric: resolvedMetric, now, day }) : 0;
    return { type, priorTypeMinutes: Number(prior.toFixed(1)), newTypeMinutes: Number(next.toFixed(1)), baselineMinutes: baselineKnown ? Number(baseline.toFixed(1)) : null, baselineKnown, progressThresholdMinutes: Number(threshold.toFixed(1)), timeBasePoints: basePoints, metricEffortPoints, basePoints: awardedBasePoints, progressBonus, goalBonus, varietyBonus, weeklyConsistencyBonus: weeklyBonus, metricProgressBonus: metricBonus, metricKey: resolvedMetric || null, quantityValue: validQuantity && resolvedMetric ? Number(quantityValue) : null, quantityUnit: validQuantity && resolvedMetric ? String(quantityUnit) : null, rawPoints: awardedBasePoints + progressBonus + goalBonus + varietyBonus + weeklyBonus + metricBonus };
  }
  function objectiveRewardBreakdown(state, { type = 'custom', label = '', day = dayKey() } = {}) {
    const alreadyTypes = uniqueActivityTypesForDay(state, day);
    // The three daily objectives are meaningful milestones, not tiny log-entry bonuses.
    // Each can award five base points; all additional bonuses still share the 35-point
    // off-screen daily budget, and the UI allows each objective only once per local day.
    const basePoints = 5;
    const varietyCount = Number(state?.lifeGrowth?.dailyVarietyBonusCount?.[day]) || 0;
    const varietyBonus = (!alreadyTypes.has(type) && varietyCount < 3) ? 1 : 0;
    const goalKey = `${day}:${type}`;
    const goalBonus = (!state?.lifeGrowth?.goalBonusDates?.[goalKey] && goalMatchesType(state, type, label)) ? 1 : 0;
    const weeklyBonus = weeklyConsistencyBonus(state, type, day);
    return { type, basePoints, progressBonus: 0, goalBonus, varietyBonus, weeklyConsistencyBonus: weeklyBonus, rawPoints: basePoints + goalBonus + varietyBonus + weeklyBonus };
  }
  function scoreBrowserInterval(state, { category, domain, minutes, confidence, pageKind, topicHints, correction = false, now = new Date() }) {
    state.browsing ||= {}; state.plant ||= { growthPoints: 0, health: 70, qualifiedDates: [], growthDays: 0 };
    const b = state.browsing, day = dayKey(now), duration = clamp(minutes, 0.25, 5);
    b.dailyMinutesByCategory ||= {}; b.dailyEffectiveProductiveMinutes ||= {}; b.dailyNetPoints ||= {}; b.pointEvents ||= []; b.dailyBrowserPoints ||= {}; b.dailyContextTypes ||= {}; b.dailyProgressBonusDates ||= {}; b.dailyGoalBonusDates ||= {};
    const rawKey = `${day}:${category}`;
    b.dailyMinutesByCategory[rawKey] = Math.max(0, Number(b.dailyMinutesByCategory[rawKey]) || 0) + duration;
    let effectiveMinutes = 0, points = 0, basePoints = 0, progressBonus = 0, goalBonus = 0, varietyBonus = 0, weight = 0;
    let contextType = contextTypeFromSignal(pageKind, topicHints);
    if (category === 'productive') {
      weight = confidenceWeight({ confidence, correction, pageKind, topicHints });
      effectiveMinutes = duration * weight;
      const before = Math.max(0, Number(b.dailyEffectiveProductiveMinutes[day]) || 0);
      const after = before + effectiveMinutes;
      b.dailyEffectiveProductiveMinutes[day] = after;
      const curveBefore = browserPointsAt(before), curveAfter = browserPointsAt(after);
      basePoints = Math.max(0, curveAfter - curveBefore);
      const budgetBefore = Math.max(0, MAX_BROWSER_POINTS_PER_DAY - (Number(b.dailyBrowserPoints[day]) || 0));
      let budget = budgetBefore;
      const addBase = Math.min(basePoints, budget); points += addBase; budget -= addBase;
      // Progress bonus: exceed the user's recent productive-time baseline in a meaningful way.
      const priorDays = recentDayKeys(dateOf(now).getTime() - 86400000, 7);
      const vals = priorDays.map(d => Math.max(0, Number(b.dailyEffectiveProductiveMinutes[d]) || 0)).filter(n => n > 0);
      const baseline = vals.length ? vals.reduce((a,c)=>a+c,0)/vals.length : 0;
      const threshold = baseline > 0 ? baseline + Math.max(10, baseline * 0.2) : 30;
      const progressAwarded = Boolean(b.dailyProgressBonusDates[day]);
      if (!progressAwarded && before < threshold && after >= threshold && budget > 0) { progressBonus = Math.min(2, budget); points += progressBonus; budget -= progressBonus; if (progressBonus) b.dailyProgressBonusDates[day] = true; }
      // Personal goal bonus only when the local goal text matches an allowed context type.
      const goalKey = `${day}:${contextType}`;
      if (!b.dailyGoalBonusDates[goalKey] && goalMatchesType(state, contextType) && budget > 0 && basePoints > 0) { goalBonus = 1; points += goalBonus; budget -= 1; b.dailyGoalBonusDates[goalKey] = true; }
      // Variety bonus: a new recognized kind of useful work is worth one extra point (max 3/day).
      const types = Array.isArray(b.dailyContextTypes[day]) ? b.dailyContextTypes[day] : [];
      const varietyAwardCount = Number(b.dailyVarietyBonusCount?.[day]) || 0;
      if (contextType !== 'general' && !types.includes(contextType) && varietyAwardCount < 3 && budget > 0 && basePoints > 0) { varietyBonus = 1; points += 1; budget -= 1; b.dailyContextTypes[day] = [...new Set([...types, contextType])].slice(0,12); b.dailyVarietyBonusCount ||= {}; b.dailyVarietyBonusCount[day] = varietyAwardCount + 1; }
      b.dailyBrowserPoints[day] = Math.max(0, Number(b.dailyBrowserPoints[day]) || 0) + points;
      b.dailyNetPoints[day] = (Number(b.dailyNetPoints[day]) || 0) + points;
      state.plant.growthPoints = clamp((Number(state.plant.growthPoints) || 0) + points, 0, 100000);
    }
    const event = { id: root.crypto?.randomUUID ? root.crypto.randomUUID() : `${Date.now()}-${Math.random()}`, source: 'browser', category, points, minutes: Number(duration.toFixed(2)), effectiveMinutes: Number(effectiveMinutes.toFixed(2)), confidence: Number(clamp(confidence,0,1).toFixed(2)), qualityWeight: Number(weight.toFixed(2)), contextType, pageKind: String(pageKind || 'unknown').slice(0,32), createdAt: dateOf(now).toISOString(), label: category === 'productive' ? 'Useful active browsing' : category === 'distracting' ? 'Possible distraction (no growth penalty)' : 'Neutral browsing', domain: String(domain || '').slice(0,253), breakdown: { basePoints, progressBonus, goalBonus, varietyBonus, confidenceWeight: Number(weight.toFixed(2)), dailyCap: MAX_BROWSER_POINTS_PER_DAY } };
    b.pointEvents.push(event); b.pointEvents = b.pointEvents.slice(-1200);
    return { points, effectiveMinutes, event, rawMinutes: b.dailyMinutesByCategory[rawKey], contextType, breakdown: event.breakdown };
  }
  function calculatePlantHealth(state, now = new Date()) {
    const days = recentDayKeys(now, 7), b = state?.browsing || {}, life = state?.lifeGrowth || {}, protection = state?.digitalProtection || {}, awareness = state?.digitalAwareness || {};
    const sumBySuffix = suffix => days.reduce((total, day) => total + Math.max(0, Number(b.dailyMinutesByCategory?.[`${day}:${suffix}`]) || 0), 0);
    const browserProductive = sumBySuffix('productive'), browserDistracting = sumBySuffix('distracting');
    const timedMinutes = days.reduce((total, day) => total + Math.max(0, Number(life.dailyTimedMinutes?.[day]) || 0), 0);
    const activeDays = days.filter(day => {
      const productive = Math.max(0, Number(b.dailyMinutesByCategory?.[`${day}:productive`]) || 0), timed = Math.max(0, Number(life.dailyTimedMinutes?.[day]) || 0);
      const objectiveTypes = new Set(Object.values(life.objectiveCompletions?.[day] || {}).map(x => x?.type).filter(Boolean));
      return productive + timed >= 20 || objectiveTypes.size >= 2;
    }).length;
    const typeSet = new Set(); let objectiveCount = 0;
    for (const day of days) {
      const objectiveValues = Object.values(life.objectiveCompletions?.[day] || {});
      objectiveCount += objectiveValues.length;
      for (const x of objectiveValues) if (x?.type && PRODUCTIVE_TYPES.has(x.type)) typeSet.add(x.type);
      for (const [key, value] of Object.entries(life.dailyTimedMinutesByType || {})) {
        const [date, type] = key.split(':');
        if (date === day && Number(value) >= 5 && PRODUCTIVE_TYPES.has(type)) typeSet.add(type);
      }
      for (const type of b.dailyContextTypes?.[day] || []) typeSet.add(type);
    }

    // No evidence is not evidence of failure. An unused or newly installed extension stays
    // near a neutral baseline rather than quietly draining the plant just because it has no data.
    const lifeEvidence = browserProductive + timedMinutes + objectiveCount * 5;
    let lifeScore = 70;
    if (lifeEvidence > 0) {
      const effort = Math.min(20, (browserProductive + timedMinutes) / 6);
      const consistency = Math.min(10, activeDays * 1.5);
      const diversity = Math.min(12, typeSet.size * 2.5);
      const checkIns = Math.min(8, objectiveCount * 1.5);
      const recovery = [...typeSet].some(type => RECOVERY_TYPES.has(type)) ? 3 : 0;
      // The life-growth pillar never falls below neutral merely because little activity was
      // recorded. Positive activity can raise the score; a lack of logs is not a health penalty.
      lifeScore = clamp(70 + effort + consistency + diversity + checkIns + recovery, 70, 100);
    }

    const digitalTotal = browserProductive + browserDistracting;
    const focusSessions = (awareness.focusSessions || []).filter(x => {
      const stamp = Date.parse(x.endedAt || x.startedAt || '');
      return Number.isFinite(stamp) && stamp >= dateOf(now).getTime() - 7*86400000 && stamp <= dateOf(now).getTime();
    });
    const completedFocus = focusSessions.filter(x => x.autoEnded || Number(x.actualMinutes || 0) >= Math.max(1, Number(x.plannedMinutes || x.targetMinutes || 0) * 0.7)).length;
    const focusBonus = focusSessions.length ? completedFocus / focusSessions.length * 10 : 0;
    const routineConflicts = Object.entries(b.routineConflictWindows || {}).filter(([key]) => days.some(day => String(key).startsWith(day))).length;
    // Do not let a brief session or a single possibly-misclassified page hurt plant health.
    // Only a sustained multi-session distraction pattern can lower the awareness pillar; useful
    // browsing and completed Focus sessions can support it. The background worker smooths changes
    // further and daily limits bound movement, while accumulated growth points remain untouched.
    const distractionDays = days.filter(day => Math.max(0, Number(b.dailyMinutesByCategory?.[`${day}:distracting`]) || 0) >= 15).length;
    const meaningfulDistractionPattern = browserDistracting >= 90 || distractionDays >= 3;
    const distractionPenalty = meaningfulDistractionPattern
      ? Math.min(20, Math.max(0, (browserDistracting - 60) / 15) + Math.max(0, distractionDays - 0) * 2)
      : 0;
    const productiveCredit = digitalTotal >= 30 ? Math.min(15, browserProductive / 60 * 5) : 0;
    const repeatRoutinePenalty = routineConflicts >= 3 ? Math.min(10, (routineConflicts - 2) * 2) : 0;
    const awarenessScore = clamp(70 + productiveCredit + focusBonus - distractionPenalty - repeatRoutinePenalty, 45, 95);

    // Protection is judged by the local safeguards the user has chosen. The default configuration
    // is neutral, not a free health bonus. Turning safeguards off lowers the target; adding deliberate
    // custom protection can raise it. The setting itself never awards lifetime growth points.
    let protectionScore = 70;
    if (protection.adBlockEnabled === false) protectionScore -= 8;
    if (protection.adultSiteBlockingEnabled === false) protectionScore -= 8;
    if (protection.distractionGuardEnabled === false) protectionScore -= 5;
    if (protection.gardenGuardEnabled === true) protectionScore += 4;
    const customCount = Array.isArray(protection.customBlockedDomains) ? protection.customBlockedDomains.length : 0;
    protectionScore += Math.min(4, customCount);
    if (protection.aiToolBlockingEnabled === true) protectionScore += 2;
    protectionScore = clamp(protectionScore, 45, 90);

    // All three pillars matter. Rest, connection and hydration are recognised as recovery,
    // distractions never subtract accumulated growth points, and health changes remain smoothed.
    return Math.round(clamp(lifeScore * 0.45 + awarenessScore * 0.30 + protectionScore * 0.25, 5, 100));
  }
  const api = { MAX_BROWSER_POINTS_PER_DAY, MAX_OFFSCREEN_POINTS_PER_DAY, dayKey, recentDayKeys, browserPointsAt, progressiveActivityPoints, advanceScrollIntervention, confidenceWeight, sumTodayOffscreenPoints, contextTypeFromSignal, goalMatchesType, inferActivityTypeFromText, objectiveLabelForType, resolveDailyObjectiveMode, objectiveDisplayTask, buildDailyObjectives, adaptiveTargetMinutes, metricKey, metricQuantityPoints, metricProgressBonus, configuredRoutineBaseline, suggestNextRoutineStep, priorDailyTypeBaseline, weeklyConsistencyBonus, activityRewardBreakdown, objectiveRewardBreakdown, scoreBrowserInterval, calculatePlantHealth };
  root.DGGrowth = api;
  return api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
if (typeof module !== 'undefined' && module.exports) module.exports = globalThis.DGGrowth;
