# Digital Greenhouse 3.3.1 — AI configuration

## Public users

The public build is designed around **one primary hosted model for every AI feature**. The publisher sets `AI_PROVIDER=cloud`, selects one supported `CLOUD_AI_PROVIDER`, chooses a model and stores the provider key in the hosting platform's private environment. Users only see Greenhouse AI and do not choose or configure models.

The included template selects Ollama Cloud with `OLLAMA_CLOUD_MODEL=gemma4:31b`. This is a template default, not a proof the model/key is live, affordable, eligible or available in a particular account. Configure a provider you are authorized to operate and verify the model with a real request after deployment.

## Local development

The local `.env.example` uses `AI_PROVIDER=hybrid` and `LOCAL_OLLAMA_MODEL=qwen2.5:3b`. That profile is for personal development only. It may use Qwen locally for lower-complexity tasks; it is not a requirement for ordinary public users.

## Important limits

- A successful `/health` response proves only basic service/provider configuration; it does not prove a real inference works.
- Mocked provider tests verify response plumbing, not advice quality, latency, uptime, cost or quotas.
- Provider credentials stay on the server. Never copy a real key or owner token into `service-config.js`, extension source, screenshots, chat or the ZIP.
