# Digital Greenhouse 3.3.1 — patch summary

This is a targeted repair/cleanup of 3.3, not a rebuild.

- **Automatic data flow:** checking the single disclosed sharing consent immediately enrolls the installation and sends its complete supported local dataset. Periodic sync continues while consent remains current.
- **Unified hosted AI:** public mode derives permission from the server-recorded consent rather than a second AI-consent toggle. All AI tasks use the configured primary cloud model.
- **Opt-out:** unchecking consent disables local hosted AI/sync and requests server revocation. Failed requests are persisted and retried in background. Previous snapshots are retained until explicit deletion.
- **Owner access:** adds a private owner dashboard and authenticated export of collected consenting-user snapshots.
- **Security:** token authentication, active-consent checks, export auth, and wider filtering of token/API-key/password/secret/cookie fields.
- **UI:** removed duplicated AI connection testing/diagnostic controls and corrected optional Grow activity card surfaces across popup/dashboard/mini-app.
- **Verification:** run `node tests/smoke.cjs`. The test includes real in-process backend auth/enrollment/revoke/export logic but mocks provider replies; it does not establish deployed model quality, live Chrome acceptance or production data-store safety.
