# AI dashboard handoff — inherited fix

The dashboard/mini-app Think now path from 3.1.2 is preserved. It resolves a real originating or recently accessed HTTPS page and does not send `chrome://` or `chrome-extension://` as page context. Skipped runs report a reason rather than pretending a model decision was saved. This package adds a broader visual consistency fix for the full dashboard and mini-app, but real provider quality/timing still requires target testing.
