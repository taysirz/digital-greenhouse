// Digital Greenhouse 3.3.1 — consent-triggered sharing, automatic enrollment, safe exports.
(() => {
  'use strict';
  const CONSENT_VERSION = 5;
  const serviceConfig = globalThis.DGServiceConfig || {};
  const DEFAULT_ENDPOINT = String(serviceConfig.endpoint || (serviceConfig.mode === 'local' ? 'http://127.0.0.1:8787' : '')).trim();
  const LOCAL_ENDPOINTS = new Set(['http://127.0.0.1:8787','http://localhost:8787','http://[::1]:8787']);
  // Kept for backward compatibility only; users cannot choose individual categories.
  const DEFAULT_CATEGORIES = Object.freeze({ activities:true, routine:true, health:true, digital:true, technical:true, feedback:true });
  const CATEGORY_KEYS = Object.keys(DEFAULT_CATEGORIES);
  const randomId = () => crypto.randomUUID();
  const object = v => v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  const isSecretKey = key => { const k=String(key).toLowerCase().replace(/[^a-z0-9]/g,''); return k==='token' || k.endsWith('token') || k.endsWith('apikey') || k.endsWith('password') || k.endsWith('secret') || k.endsWith('privatekey') || k.endsWith('authorization') || k.endsWith('cookie'); };

  async function readState() { const { dgState } = await chrome.storage.local.get('dgState'); return object(dgState); }
  async function saveState(state) { await chrome.storage.local.set({ dgState: state }); }
  function normalizeCollection(state) {
    state.profile = object(state.profile); state.profile.dataCollection = object(state.profile.dataCollection);
    const dc = state.profile.dataCollection; dc.enabled = Boolean(dc.enabled); dc.categories = { ...DEFAULT_CATEGORIES };
    const storedEndpoint = typeof dc.endpoint === 'string' ? dc.endpoint.trim() : '';
    // Hosted builds replace the old local-development default with the publisher-configured URL.
    dc.endpoint = serviceConfig.mode === 'hosted' && (!storedEndpoint || LOCAL_ENDPOINTS.has(storedEndpoint))
      ? DEFAULT_ENDPOINT : (storedEndpoint || DEFAULT_ENDPOINT);
    // Never silently upgrade an old consent record: the user must review the updated notice.
    dc.consentVersion = Number.isInteger(Number(dc.consentVersion)) ? Number(dc.consentVersion) : 0;
    if (!/^[0-9a-f-]{36}$/i.test(String(dc.installId || ''))) dc.installId = randomId();
    if (typeof dc.installToken !== 'string' || dc.installToken.length < 36) dc.installToken = `${randomId()}${randomId()}`;
    return dc;
  }
  function cleanEndpoint(endpoint) {
    if (!String(endpoint || '').trim()) throw new Error('The Digital Greenhouse service has not been connected by its publisher yet.');
    let url; try { url = new URL(String(endpoint || '')); } catch { throw new Error('The Greenhouse service address is invalid.'); }
    if (!['https:','http:'].includes(url.protocol)) throw new Error('Use HTTPS for a hosted server. HTTP is allowed only for localhost development.');
    if (url.username || url.password || url.search || url.hash) throw new Error('The server URL must not contain credentials, a query, or a fragment.');
    if (url.protocol === 'http:' && !['localhost','127.0.0.1','[::1]'].includes(url.hostname)) throw new Error('For safety, a non-local server must use HTTPS.');
    return url.origin;
  }
  async function requestHostPermission(endpoint) {
    const origin = cleanEndpoint(endpoint), url = new URL(origin), pattern = `${url.protocol}//${url.hostname}/*`;
    if (!chrome.permissions?.contains || !chrome.permissions?.request) throw new Error('This Chrome version cannot grant the server permission needed for sharing.');
    if (await chrome.permissions.contains({ origins:[pattern] })) return origin;
    if (!await chrome.permissions.request({ origins:[pattern] })) throw new Error('Chrome host permission was not granted. No data was uploaded.');
    return origin;
  }
  function sanitizeStoredData(raw, { redactSecrets = true } = {}) {
    // Preserve the entire user dataset or fail: no per-field/category sampling and no silent truncation.
    // The only omissions in a server-bound dataset are installation authentication and secret-bearing fields.
    const walk = (value, depth = 0) => {
      if (depth > 50) throw new Error('Your local dataset has an unexpectedly deep object. Export it locally; no partial upload was made.');
      if (value === null || ['boolean','number','string'].includes(typeof value)) return value;
      if (Array.isArray(value)) return value.map(v => walk(v, depth + 1));
      if (typeof value !== 'object') throw new Error('Your local dataset contains an unsupported value. Export it locally; no partial upload was made.');
      const out = {};
      for (const [key, item] of Object.entries(value)) {
        if (redactSecrets && isSecretKey(key)) continue;
        out[key] = walk(item, depth + 1);
      }
      return out;
    };
    return walk(object(raw));
  }
  function buildPayload(state, _categories, allStorage = null) {
    const source = allStorage && typeof allStorage === 'object' ? allStorage : { dgState: state };
    const sanitized = sanitizeStoredData(source, { redactSecrets:true });
    const serialized = JSON.stringify(sanitized);
    if (serialized.length > 1_700_000) throw new Error('Your full local dataset is larger than the safe single-upload limit. Export it locally; no partial data was uploaded.');
    return { format:'digital-greenhouse-user-dataset-v3', exportedAt:new Date().toISOString(), includedStorageKeys:Object.keys(sanitized), excludedSecretTypes:['installation authentication token','API keys','passwords and authorization secrets'], storage:sanitized };
  }
  async function configure({ enabled, endpoint, consentAccepted } = {}) {
    const state = await readState(), dc = normalizeCollection(state), nextEnabled = Boolean(enabled);
    if (nextEnabled && consentAccepted !== true) throw new Error('Please give explicit consent in Setup before enabling all-or-none Greenhouse data sharing.');
    const endpointInput = String(endpoint ?? dc.endpoint ?? DEFAULT_ENDPOINT ?? '').trim();
    const nextEndpoint = endpointInput ? cleanEndpoint(endpointInput) : '';
    const wasEnabled = dc.enabled, changed = dc.endpoint !== nextEndpoint || dc.consentVersion !== CONSENT_VERSION;
    dc.enabled=nextEnabled; dc.endpoint=nextEndpoint; dc.categories={...DEFAULT_CATEGORIES};
    if (nextEnabled) {
      dc.everEnabled=true;
      if (!wasEnabled || !dc.consentAt || changed) dc.consentAt=new Date().toISOString();
      dc.consentVersion=CONSENT_VERSION; dc.disabledAt=null; dc.consentRevokedAt=null; dc.remoteRevocationConfirmedAt=null; dc.lastRevocationError=null;
    } else {
      dc.disabledAt=new Date().toISOString(); dc.consentRevokedAt=dc.disabledAt; dc.remoteRevocationConfirmedAt=null; dc.lastRevocationError=null; dc.consentAt=null;
    }
    // The one Setup consent is the all-or-nothing permission for data sharing and complete-context Coach use.
    state.aiCompanion = object(state.aiCompanion);
    const brain = state.aiCompanion;
    if (nextEnabled) {
      // The single all-or-nothing consent explicitly covers hosted AI processing as described in the notice.
      // Do not silently enable autonomous Focus: that remains a separate, deliberate user choice.
      brain.enabled=true; brain.allowCloudAI=serviceConfig.mode === 'hosted'; brain.autoStartFocusOnDistraction=false;
      brain.consentAt=dc.consentAt; brain.fullContextConsentAt=dc.consentAt; brain.fullContextConsentVersion=2; brain.includeRoutineContext=true;
      brain.localPageAnalysisEnabled=true;
    } else {
      brain.enabled=false; brain.consentAt=null; brain.fullContextConsentAt=null; brain.fullContextConsentVersion=0;
      brain.includeRoutineContext=false; brain.localPageAnalysisEnabled=false; brain.allowCloudAI=false; brain.autoStartFocusOnDistraction=false;
    }
    state.profile.dataCollection=dc; await saveState(state);
    let syncResult = null, revocationResult = null;
    if (nextEnabled) {
      try { syncResult = await sync(); }
      catch (error) { syncResult = { ok:false, error:String(error?.message || 'Initial sync failed').slice(0,400) }; }
    } else if (wasEnabled) {
      try { revocationResult = await retryRemoteRevocation(); }
      catch (error) {
        revocationResult = { ok:false, confirmed:false, error:String(error?.message || 'Remote revocation could not be confirmed').slice(0,300) };
        const latest=await readState(), latestDc=normalizeCollection(latest);
        latestDc.lastRevocationError=revocationResult.error; latest.profile.dataCollection=latestDc; await saveState(latest);
      }
    }
    return { enabled:dc.enabled, endpoint:dc.endpoint, scope:'all-or-none-complete-dataset', consentAt:dc.consentAt||null, consentVersion:dc.consentVersion, syncResult, revocationResult };
  }
  async function ensureServiceAccessToken({ force=false } = {}) {
    const state = await readState(), dc = normalizeCollection(state);
    if (!dc.enabled || !dc.consentAt || Number(dc.consentVersion) !== CONSENT_VERSION) throw new Error('Accept the current data-sharing notice before connecting to Greenhouse AI.');
    const endpoint = cleanEndpoint(dc.endpoint || DEFAULT_ENDPOINT);
    state.aiCompanion = object(state.aiCompanion);
    const currentToken = String(state.aiCompanion.serviceAccessToken || '').trim();
    const expiresAt = Date.parse(String(state.aiCompanion.serviceAccessTokenExpiresAt || ''));
    if (!force && currentToken && Number.isFinite(expiresAt) && expiresAt > Date.now() + 24 * 60 * 60 * 1000) return { token:currentToken, endpoint, requiresAccessToken:true };
    const response = await fetch(`${endpoint}/v1/enroll`, {
      method:'POST', headers:{'Content-Type':'application/json','X-DG-Install-Id':dc.installId,'X-DG-Install-Token':dc.installToken},
      body:JSON.stringify({ schemaVersion:1, consentVersion:CONSENT_VERSION, consentAt:dc.consentAt }),
      signal:AbortSignal.timeout(15000), cache:'no-store'
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok || body.ok !== true) throw new Error(body.error || `Greenhouse enrollment failed (HTTP ${response.status}).`);
    if (body.requiresAccessToken !== true) {
      state.aiCompanion.serviceAccessToken = '';
      state.aiCompanion.serviceAccessTokenExpiresAt = null;
      await saveState(state);
      return { token:'', endpoint, requiresAccessToken:false };
    }
    if (typeof body.accessToken !== 'string' || body.accessToken.length < 40 || !Number.isFinite(Date.parse(body.expiresAt || ''))) throw new Error('The Greenhouse service returned an invalid enrollment response.');
    const latest = await readState(); latest.aiCompanion = object(latest.aiCompanion);
    latest.aiCompanion.serviceAccessToken = body.accessToken;
    latest.aiCompanion.serviceAccessTokenExpiresAt = body.expiresAt;
    await saveState(latest);
    return { token:body.accessToken, endpoint, requiresAccessToken:true };
  }
  async function sync({ requestPermission=false } = {}) {
    const state=await readState(), dc=normalizeCollection(state);
    if (!dc.enabled || !dc.consentAt || Number(dc.consentVersion) !== CONSENT_VERSION) throw new Error('Current Setup consent is required before uploading Greenhouse data. Review the updated notice and save your consent first.');
    dc.lastSyncAttemptAt=new Date().toISOString(); dc.lastSyncError=null; state.profile.dataCollection=dc; await saveState(state);
    try {
      const endpoint=cleanEndpoint(dc.endpoint || DEFAULT_ENDPOINT);
      const access = await ensureServiceAccessToken();
      const refreshedState = await readState();
      const allStorage=await chrome.storage.local.get(null), userData=buildPayload(refreshedState,DEFAULT_CATEGORIES,allStorage);
      const headers={'Content-Type':'application/json','X-DG-Install-Id':dc.installId,'X-DG-Install-Token':dc.installToken}; if(access.token) headers.Authorization=`Bearer ${access.token}`;
      const response=await fetch(`${endpoint}/v1/ingest`,{method:'POST',headers,body:JSON.stringify({schemaVersion:2,consentVersion:CONSENT_VERSION,consentAt:dc.consentAt,userData}),signal:AbortSignal.timeout(20000)});
      const body=await response.json().catch(()=>({})); if (!response.ok) throw new Error(body.error||`Server returned ${response.status}.`);
      const newest=await readState(), newestDc=normalizeCollection(newest); if (!newestDc.enabled || newestDc.installId!==dc.installId) return {ok:true,skipped:true};
      newestDc.lastSyncedAt=new Date().toISOString(); newestDc.lastSyncError=null; newest.profile.dataCollection=newestDc; await saveState(newest);
      return {ok:true,receivedAt:body.receivedAt||null,keys:userData.includedStorageKeys.length,automatic:true};
    } catch(error) { const newest=await readState(), latest=normalizeCollection(newest); latest.lastSyncError=String(error?.message||'Sync failed').slice(0,400); newest.profile.dataCollection=latest; await saveState(newest); throw error; }
  }
  async function revokeRemoteConsent() {
    const state=await readState(), dc=normalizeCollection(state), endpoint=cleanEndpoint(dc.endpoint || DEFAULT_ENDPOINT);
    const response=await fetch(`${endpoint}/v1/revoke`,{method:'POST',headers:{'Content-Type':'application/json','X-DG-Install-Id':dc.installId,'X-DG-Install-Token':dc.installToken},body:JSON.stringify({consentVersion:CONSENT_VERSION,revokedAt:dc.consentRevokedAt||dc.disabledAt||new Date().toISOString()}),signal:AbortSignal.timeout(10000),cache:'no-store'});
    const body=await response.json().catch(()=>({}));
    if (!response.ok && response.status!==404) throw new Error(body.error||`Server revocation returned ${response.status}.`);
    return {ok:true,confirmed:response.ok||body.confirmed===true,deleted:false};
  }
  async function retryRemoteRevocation() {
    const state=await readState(), dc=normalizeCollection(state);
    if (dc.enabled || !dc.everEnabled || !dc.consentRevokedAt || dc.remoteRevocationConfirmedAt) return {ok:true,skipped:true,confirmed:Boolean(dc.remoteRevocationConfirmedAt)};
    try {
      const result=await revokeRemoteConsent();
      if (!result.confirmed) throw new Error('The server did not confirm consent revocation.');
      const latest=await readState(), latestDc=normalizeCollection(latest);
      latestDc.remoteRevocationConfirmedAt=new Date().toISOString(); latestDc.lastRevocationError=null;
      latest.profile.dataCollection=latestDc; await saveState(latest);
      return {...result,skipped:false};
    } catch (error) {
      const latest=await readState(), latestDc=normalizeCollection(latest);
      latestDc.lastRevocationError=String(error?.message||'Remote revocation could not be confirmed').slice(0,300);
      latest.profile.dataCollection=latestDc; await saveState(latest); throw error;
    }
  }
  async function exportRemoteData() {
    const state=await readState(), dc=normalizeCollection(state), endpoint=cleanEndpoint(dc.endpoint || DEFAULT_ENDPOINT);
    const response=await fetch(`${endpoint}/v1/data/${encodeURIComponent(dc.installId)}`,{headers:{'X-DG-Install-Token':dc.installToken},signal:AbortSignal.timeout(15000)});
    const body=await response.json().catch(()=>({})); if (!response.ok) throw new Error(body.error||`Server returned ${response.status}.`);
    return body;
  }
  async function deleteRemote() {
    const state=await readState(), dc=normalizeCollection(state), endpoint=cleanEndpoint(dc.endpoint || DEFAULT_ENDPOINT);
    const response=await fetch(`${endpoint}/v1/data/${encodeURIComponent(dc.installId)}`,{method:'DELETE',headers:{'X-DG-Install-Token':dc.installToken},signal:AbortSignal.timeout(15000)});
    const body=await response.json().catch(()=>({})); if (!response.ok && response.status!==404) throw new Error(body.error||`Server returned ${response.status}.`);
    const latest=normalizeCollection(state); latest.enabled=false; latest.lastSyncedAt=null; latest.lastSyncError=null; latest.disabledAt=new Date().toISOString(); latest.consentRevokedAt=latest.disabledAt; latest.remoteRevocationConfirmedAt=new Date().toISOString(); latest.lastRevocationError=null; latest.consentAt=null; state.profile.dataCollection=latest;
    state.aiCompanion=object(state.aiCompanion); state.aiCompanion.enabled=false; state.aiCompanion.allowCloudAI=false; state.aiCompanion.consentAt=null; state.aiCompanion.fullContextConsentAt=null; state.aiCompanion.fullContextConsentVersion=0; state.aiCompanion.serviceAccessToken=''; state.aiCompanion.serviceAccessTokenExpiresAt=null; state.aiCompanion.localPageAnalysisEnabled=false;
    await saveState(state);
    return {ok:true,deleted:Boolean(body.deleted),nothingFound:response.status===404};
  }
  globalThis.DGData={CONSENT_VERSION,DEFAULT_ENDPOINT,DEFAULT_CATEGORIES,CATEGORY_KEYS,readState,saveState,normalizeCollection,cleanEndpoint,sanitizeStoredData,buildPayload,configure,ensureServiceAccessToken,sync,revokeRemoteConsent,retryRemoteRevocation,exportRemoteData,deleteRemote};
})();
