// Digital Greenhouse: conservative local-only detector for explicit AI-generated disclosure.
// It never sends text to a model and deliberately does not infer authorship from writing style.
(() => {
  const EXACT_LABEL = /^(?:ai[\s-]?generated(?:\s+(?:image|video|audio|artwork|photo|media|content))?|generated\s+(?:with|by)\s+ai|made\s+with\s+ai|created\s+(?:with|by)\s+ai|synthetic\s+(?:media|image|video|audio))$/i;
  const EXCLUDED_ANCESTORS = 'nav,header,footer,[role="navigation"],[role="log"],[role="textbox"],form,[contenteditable="true"],[class*="chat" i],[id*="chat" i],[class*="message" i],[id*="message" i]';
  const STRUCTURED_SELECTOR = '[data-ai-generated], [data-ai-content], [data-generated-by], [data-content-origin], [class*="ai-generated" i], [id*="ai-generated" i], [data-testid*="ai-generated" i]';
  const LABEL_SELECTOR = 'span,small,strong,em,figcaption,[role="img"],[aria-label],[title],[class*="badge" i],[class*="label" i]';
  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim().slice(0, 120);
  function visible(node, doc) {
    if (!node || node.hidden || node.getAttribute?.('aria-hidden') === 'true') return false;
    if (node.closest?.(EXCLUDED_ANCESTORS)) return false;
    const style = doc.defaultView?.getComputedStyle?.(node);
    if (style && (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0')) return false;
    if (typeof node.getClientRects === 'function' && node.getClientRects().length === 0) return false;
    return true;
  }
  function nodeSignalsDisclosure(node) {
    const dataAiGenerated = normalize(node.getAttribute?.('data-ai-generated')).toLowerCase();
    const dataAiContent = normalize(node.getAttribute?.('data-ai-content')).toLowerCase();
    const generatedBy = normalize(node.getAttribute?.('data-generated-by')).toLowerCase();
    const contentOrigin = normalize(node.getAttribute?.('data-content-origin')).toLowerCase();
    if (node.hasAttribute?.('data-ai-generated') && !['false', '0', 'no', 'none'].includes(dataAiGenerated)) return true;
    if (['true', '1', 'yes'].includes(dataAiContent)) return true;
    if (['ai', 'artificial intelligence'].includes(generatedBy) || ['ai', 'artificial intelligence'].includes(contentOrigin)) return true;
    const structuralMarker = `${node.className?.baseVal || node.className || ''} ${node.id || ''} ${node.getAttribute?.('data-testid') || ''}`;
    if (/\bai[-_ ]generated(?:[-_ ](?:label|badge|content|image|media))?\b/i.test(String(structuralMarker))) return true;
    const labels = [node.getAttribute?.('aria-label'), node.getAttribute?.('title'), node.innerText, node.textContent];
    return labels.some(rawLabel => { const label = normalize(rawLabel); return Boolean(label && EXACT_LABEL.test(label)); });
  }
  function findExplicitAiDisclosures(doc = globalThis.document, maxResults = 20) {
    if (!doc?.querySelectorAll) return [];
    const matches = [], seen = new Set();
    for (const selector of [STRUCTURED_SELECTOR, LABEL_SELECTOR]) {
      let nodes;
      try { nodes = Array.from(doc.querySelectorAll(selector)).slice(0, 350); }
      catch { continue; }
      for (const node of nodes) {
        if (seen.has(node)) continue;
        seen.add(node);
        if (visible(node, doc) && nodeSignalsDisclosure(node)) matches.push(node);
        if (matches.length >= Math.max(1, Math.min(50, Number(maxResults) || 20))) return matches;
      }
    }
    return matches;
  }
  function detectExplicitAiDisclosure(doc = globalThis.document) {
    return findExplicitAiDisclosures(doc, 1).length > 0;
  }
  globalThis.DGLocalAiDisclosureDetector = Object.freeze({ detectExplicitAiDisclosure, findExplicitAiDisclosures });
})();
