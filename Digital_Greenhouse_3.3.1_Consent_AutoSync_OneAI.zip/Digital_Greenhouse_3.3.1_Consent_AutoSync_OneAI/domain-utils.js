/* Shared, defensive domain parsing for settings UI and the service worker. */
(function (root) {
  'use strict';
  function isDnsName(host) {
    if (typeof host !== 'string' || !host || host.length > 253 || host.startsWith('.') || host.endsWith('.')) return false;
    const labels = host.split('.');
    if (labels.length < 2) return false;
    if (!labels.every(label => label.length >= 1 && label.length <= 63 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label))) return false;
    const tld = labels[labels.length - 1];
    return /^[a-z]{2,}$/i.test(tld) || /^xn--[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(tld);
  }
  function normalizeDomains(value) {
    const parsed = String(Array.isArray(value) ? value.join('\n') : value || '').split(/[\n,;\s]+/)
      .map(raw => {
        let host = raw.trim().toLowerCase();
        host = host.replace(/^https?:\/\//, '').replace(/^\*\./, '');
        // Accept a pasted URL, but retain only its hostname, never path/query/fragment.
        return host.split(/[/?#]/, 1)[0].replace(/:\d+$/, '').replace(/\.$/, '');
      })
      .filter(isDnsName);
    return [...new Set(parsed)].slice(0, 250);
  }
  root.DGDomainUtils = Object.freeze({ normalizeDomains, isDnsName });
  if (typeof module !== 'undefined' && module.exports) module.exports = root.DGDomainUtils;
})(typeof globalThis !== 'undefined' ? globalThis : this);
