'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const ROOT = path.resolve(__dirname, '..');
const now = Date.now();
const today = `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2,'0')}-${String(new Date().getDate()).padStart(2,'0')}`;
const tab = { id: 12, url: 'https://distract.example/feed', active: true, windowId: 1 };
let store = { dgState: {
  schemaVersion: 9, createdAt: new Date(now - 86400000).toISOString(),
  aiCompanion: { enabled:false, consentAt:null, runs:[], history:[], feedback:[] },
  profile: { onboardingComplete:true, dailyObjectives:['Study','Move','Rest'], routineNotes:'', goalNotes:'', tone:'gentle' },
  plant: { growthPoints: 75, health: 80, growthDays: 5, qualifiedDates:[], milestones:[], plantedAt:new Date(now-86400000).toISOString() },
  lifeGrowth: { activityLog:[], goals:[], rewardLedger:[], activeActivity:null, manualPointsByDay:{}, activityAwardedByDay:{}, objectiveCompletions:{} },
  digitalAwareness: { remindersEnabled:true, reminderMinutes:20, nudgeAfterMinutes:5, focusSessions:[], activeFocusSession:null },
  wellbeing: { remindersEnabled:true, activeUseDate:today, activeUseSecondsToday:19*60+10, lastActiveUseTickAt:now-61000, lastCheckinBucket:0, lastHourlyBucket:0, pendingBreak:null, breakLog:[], checkInLog:[], integrityLockCount:0 },
  digitalProtection: { adBlockEnabled:true, adultSiteBlockingEnabled:false, aiToolBlockingEnabled:false, aiToolDomains:[], customBlockedDomains:[], allowlist:[], gardenGuardEnabled:false, distractionGuardEnabled:true, distractionEnforcement:'block', distractionThresholdMinutes:5, distractionCooldownMinutes:15, temporaryOverrides:{}, temporaryAutoBlocks:{}, blockedEvents:[] },
  wellbeing: {selfRating:3,note:''},
  browsing: {trackingEnabled:true, pointIntervalMinutes:2, pageSignals:{'distract.example':{domain:'distract.example',category:'distracting',confidence:.95,observedAt:new Date(now).toISOString(),visitId:'visit1'}}, tabSignals:{'12':{domain:'distract.example',category:'distracting',confidence:.95,observedAt:new Date(now).toISOString(),visitId:'visit1'}}, siteLearning:{}, trackingProgress:{domain:'distract.example',category:'distracting',seconds:90,lastTickAt:now-61000}, activeBrowsingSeconds:300,lastActiveBrowsingTickAt:now-61000,dailyActiveMinutes:{[today]:8}, pointEvents:[],dailyNetPoints:{},dailyMinutesByCategory:{},distractionSession:{domain:'distract.example',activeMinutes:4,activeSeconds:240,warned:true,redirected:false,lastTickAt:now-61000},lastTrackingDomain:'distract.example',lastTrackingCategory:'distracting' }
} };
let messageListener, navigationListener, lastUpdatedUrl=null, dynamicRules=[];
let failNextTabMessage = false;
let failNextDynamicRules = false;
let failNextAdRules = false;
let enabledRuleSets = ['starter_ad_filter'];
const sentTabMessages = [];
const injectedScriptCalls = [];
const chrome = {
  storage:{local:{get:async()=>structuredClone(store),set:async v=>{store={...store,...structuredClone(v)}}},onChanged:{addListener:()=>{}}},
  runtime:{id:'test-extension-id',getURL:f=>`chrome-extension://test-extension-id/${f}`,onInstalled:{addListener:()=>{}},onStartup:{addListener:()=>{}},onMessage:{addListener:fn=>{messageListener=fn;}}},
  alarms:{create:()=>{},clear:async()=>true,onAlarm:{addListener:()=>{}}},
  windows:{getLastFocused:async()=>({focused:true,id:1})}, idle:{queryState:async()=> 'active'},
  tabs:{query:async()=>[tab],sendMessage:async(_id,message)=>{if(failNextTabMessage){failNextTabMessage=false;throw new Error('Could not establish connection. Receiving end does not exist.');}sentTabMessages.push(structuredClone(message));return {ok:true};},update:async(_id,info)=>{lastUpdatedUrl=info.url;return {...tab,url:info.url}},create:async()=>({id:20}),get:async()=>tab},
  declarativeNetRequest:{getDynamicRules:async()=>structuredClone(dynamicRules),updateDynamicRules:async ({removeRuleIds,addRules})=>{if(failNextDynamicRules){failNextDynamicRules=false;throw new Error('Simulated Chrome DNR quota/validation failure');}const ids=new Set(removeRuleIds||[]);dynamicRules=dynamicRules.filter(r=>!ids.has(r.id)).concat(structuredClone(addRules||[]));},getEnabledRulesets:async()=>structuredClone(enabledRuleSets),updateEnabledRulesets:async ({enableRulesetIds=[],disableRulesetIds=[]})=>{if(failNextAdRules){failNextAdRules=false;throw new Error('Simulated static ruleset failure');}enabledRuleSets=[...new Set([...enabledRuleSets.filter(id=>!disableRulesetIds.includes(id)),...enableRulesetIds])];}},
  webNavigation:{onBeforeNavigate:{addListener:fn=>{navigationListener=fn;}}},
  scripting:{executeScript:async details=>{injectedScriptCalls.push(structuredClone(details));return [{}];}}
};
const sandbox={chrome,TextEncoder,TextDecoder,console:{log(){},debug(){},warn(){},error:console.error},crypto,URL,AbortSignal,setTimeout,clearTimeout,importScripts:(...files)=>{sandbox.DGData={readState:async()=>store.dgState,normalizeCollection:()=>({enabled:false})};if(files.includes('growth-engine.js'))sandbox.DGGrowth=require(path.join(ROOT,'growth-engine.js'));if(files.includes('domain-utils.js'))sandbox.DGDomainUtils=require(path.join(ROOT,'domain-utils.js'));if(files.includes('filter-list-updater.js'))sandbox.DGFilterListUpdater=require(path.join(ROOT,'filter-list-updater.js'))}};
vm.createContext(sandbox); vm.runInContext(fs.readFileSync(path.join(ROOT,'background.js'),'utf8'),sandbox,{filename:'background.js',timeout:5000});
function send(message,sender={url:'chrome-extension://test-extension-id/popup.html'}) { return new Promise((resolve,reject)=>{let done=false;messageListener(message,sender,v=>{if(!done){done=true;resolve(v)}});setTimeout(()=>{if(!done)reject(new Error('Message timed out'))},1000).unref();}); }
(async()=>{
  // Domain parsing is a protection boundary: malformed entries must be ignored before
  // rules are handed to Chrome's atomic DNR updater.
  const parsedDomains = sandbox.normalizeDomains('https://www.example.com/path?q=1\n*.sub.example.org\nexample.com\n..evil.com\n-start.example\nend-.example\nempty..example\nnot-a-domain\nhttps://good.example:8443/#top\nUPPER.Example');
  assert.deepEqual(Array.from(parsedDomains), ['www.example.com','sub.example.org','example.com','good.example','upper.example']);
  assert.equal(sandbox.normalizeDomains('a'.repeat(64)+'.example').length, 0, 'DNS labels over 63 characters must be rejected');
  assert.equal(sandbox.normalizeDomains('x'.repeat(254)+'.com').length, 0, 'Hosts over 253 characters must be rejected');
  assert.equal(sandbox.normalizeDomains('legit.example\n..bad..example\nanother.example').length, 2, 'One malformed item must not invalidate other valid domains');
  console.log('PASS  Domain validation strips pasted URL details and rejects malformed DNS labels before protection rules are built');
  // A failed browser rule update must be visible and must not silently save settings that are not enforced.
  const priorSnapshot = await send({type:'DG_GET_STATE'});
  const priorProtection = structuredClone(priorSnapshot.state.digitalProtection);
  assert.equal(priorSnapshot.state.schemaVersion, 25, 'Legacy state should be migrated to the version-25 schema');
  assert.deepEqual(Array.from(priorProtection.allowlist || []), [], 'Fresh or migrated defaults must not prefill a misleading useful-site allowlist');
  const emptyGuard = await send({type:'DG_SAVE_PROTECTION', protection:{...priorProtection, gardenGuardEnabled:true, allowlist:[]}});
  assert.equal(emptyGuard.ok, false, 'Garden Guard must reject an empty allowlist that would block every website');
  assert.match(emptyGuard.error, /at least one permitted domain/i);
  assert.equal(store.dgState.digitalProtection.gardenGuardEnabled, false, 'Rejected empty Garden Guard configuration must not persist');
  const emptyFocus = await send({type:'DG_START_FOCUS', durationMinutes:25});
  assert.equal(emptyFocus.ok, false, 'Strict Focus must not start with an empty access allowlist');
  assert.match(emptyFocus.error, /AI usefulness and growth points are decided separately/i);
  console.log('PASS  Focus and Garden Guard require an explicit non-empty access allowlist and no longer inherit useful-site defaults');
  failNextDynamicRules = true;
  const failedProtection = await send({type:'DG_SAVE_PROTECTION', protection:{...priorProtection, customBlockedDomains:['new-block.example']}});
  assert.equal(failedProtection.ok, false, 'Protection save must report Chrome rule installation failures');
  assert.match(failedProtection.error, /did not apply.*previous settings were restored/i);
  assert.deepEqual(store.dgState.digitalProtection, priorProtection, 'Failed protection transaction must restore prior preferences');
  console.log('PASS  Protection settings rollback and report a truthful error when Chrome rejects a rule transaction');
  failNextAdRules = true;
  const priorBeforeAdFailure = await send({type:'DG_GET_STATE'});
  const priorAdProtection = structuredClone(priorBeforeAdFailure.state.digitalProtection);
  const desiredAdFilter = priorAdProtection.adBlockEnabled === false;
  const failedAdTransaction = await send({type:'DG_SAVE_PROTECTION', protection:{...priorAdProtection, adBlockEnabled:desiredAdFilter, customBlockedDomains:['another.example']}});
  assert.equal(failedAdTransaction.ok, false, 'Ad-filter failures must prevent a false-success response');
  assert.deepEqual(store.dgState.digitalProtection, priorAdProtection, 'A failed static ad-filter change must restore all prior protection preferences');
  assert.equal(enabledRuleSets.includes('starter_ad_filter'), priorAdProtection.adBlockEnabled !== false, 'Ad-filter ruleset state must return to the previous preference');
  console.log('PASS  Ad-filter and dynamic protection changes roll back together when either ruleset update fails');
  // A confidently classified distraction at 4 active minutes should be redirected on the next minute.
  const beforePoints=store.dgState.plant.growthPoints;
  const tick=await send({type:'DG_TICK_NOW'});
  assert.equal(tick.ok,true);
  assert.match(lastUpdatedUrl,/blocked\.html\?reason=distraction&until=/,'Firm guard must navigate to the stop page, not only a notification');
  const state=store.dgState.dgState || store.dgState;
  assert.ok(state.digitalProtection.temporaryAutoBlocks['distract.example'],'Timed automatic domain block was not stored');
  assert.ok(state.digitalProtection.blockedEvents.some(e=>e.domain==='distract.example'&&e.reason==='distraction'),'Distraction stop event was not recorded');
  assert.ok(dynamicRules.some(r=>r.condition?.urlFilter==='||distract.example^' && r.action?.type==='redirect' && String(r.action.redirect?.extensionPath).includes('reason=distraction')),'DNR did not receive a timed domain blocking rule');
  assert.equal(state.plant.growthPoints,beforePoints,'Blocking a distracting page must not penalise plant points');
  assert.equal(state.plant.health,80,'Blocking a distracting page must not lower plant health');
  assert.ok(state.browsing.pointEvents.some(e=>e.category==='distracting'&&e.points===0),'Possible distraction should be logged without negative points');
  assert.equal(typeof navigationListener,'function','Blocked-attempt navigation listener was not registered');
  navigationListener({url:'https://distract.example/feed',frameId:0,tabId:12});
  await new Promise(resolve=>setTimeout(resolve,25));
  const afterRepeat=store.dgState.dgState || store.dgState;
  assert.ok(afterRepeat.digitalProtection.blockedEvents.some(e=>e.domain==='distract.example'&&e.reason==='distraction'),'Reload attempts during the cooldown were not logged');
  console.log('PASS  Firm distraction guard redirects the current tab, applies a timed domain rule, records attempts, and leaves plant points/health unchanged');

  // Clear active cooldown for the reminder-only test and prove the no-block mode never redirects.
  lastUpdatedUrl=null; dynamicRules=[];
  store.dgState.digitalProtection.distractionEnforcement='remind'; store.dgState.digitalProtection.temporaryAutoBlocks={}; store.dgState.digitalProtection.blockedEvents=[];
  store.dgState.browsing.distractionSession={domain:'distract.example',activeMinutes:4,activeSeconds:240,warned:true,redirected:false,lastTickAt:Date.now()-61000};
  store.dgState.browsing.tabSignals['12'].observedAt=new Date().toISOString();
  store.dgState.browsing.lastActiveBrowsingTickAt=Date.now()-61000;
  await send({type:'DG_TICK_NOW'});
  assert.equal(lastUpdatedUrl,null,'Reminder-only mode must not block or redirect a page');
  assert.equal(Object.keys(store.dgState.digitalProtection.temporaryAutoBlocks).length,0);
  console.log('PASS  Reminder-only mode does not create timed blocks');

  // A deliberate override cannot defeat an explicit custom block list.
  store.dgState.digitalProtection.distractionEnforcement='block';
  store.dgState.digitalProtection.customBlockedDomains=['blocked.example'];
  const override=await send({type:'DG_BLOCKED_OVERRIDE',url:'https://blocked.example/page'},{url:'chrome-extension://test-extension-id/blocked.html',tab:{id:12}});
  assert.equal(override.ok,false,'Explicit custom block must not be overridable');
  assert.match(override.error,/explicit protection list/i);
  console.log('PASS  Explicit protection block cannot be bypassed by the timed distraction override');

  // Adult-site protection must install the curated starter domains as real main-frame redirects,
  // and disabling the toggle must remove those rules again.
  store.dgState.digitalProtection = { ...store.dgState.digitalProtection, adultSiteBlockingEnabled:true, aiToolBlockingEnabled:false, aiToolDomains:[], customBlockedDomains:[], allowlist:[], temporaryOverrides:{}, temporaryAutoBlocks:{}, distractionGuardEnabled:false, distractionEnforcement:'block' };
  await send({type:'DG_SAVE_PROTECTION', protection:store.dgState.digitalProtection});
  const adultRules = dynamicRules.filter(r => r.priority === 200 && r.action?.type === 'redirect' && r.condition?.resourceTypes?.includes('main_frame'));
  assert(adultRules.length >= 80, `Expected broad starter adult protection rules, got ${adultRules.length}`);
  for (const domain of ['pornhub.com','adultfriendfinder.com','fansly.com','motherless.com']) {
    assert(adultRules.some(r => r.condition?.urlFilter === `||${domain}^`), `Adult protection rule missing for ${domain}`);
  }
  console.log(`PASS  Adult-site protection installs ${adultRules.length} curated domain redirects`);
  store.dgState.digitalProtection.adultSiteBlockingEnabled = false;
  await send({type:'DG_SAVE_PROTECTION', protection:store.dgState.digitalProtection});
  assert(!dynamicRules.some(r => r.priority === 200 && r.condition?.urlFilter === '||pornhub.com^'), 'Turning adult protection off must remove its redirect rule');
  console.log('PASS  Adult-site protection toggle removes starter redirect rules when disabled');

  // The integrated release can update maintained community lists from the exact approved
  // HTTPS endpoints, install only bounded domain rules, and retain last-known-good data if
  // a source redirects or becomes invalid.
  store.dgState.digitalProtection = { ...store.dgState.digitalProtection, adBlockEnabled:true, adultSiteBlockingEnabled:true, communityFilterListsEnabled:true };
  const communityText = (prefix) => Array.from({length:150},(_,i)=>`${prefix}${i}.example`).join('\n');
  sandbox.fetch = async url => ({
    ok:true, status:200, url:String(url), headers:{get:name=>name.toLowerCase()==='content-length'?'4096':null},
    text:async()=>String(url).includes('nsfw-small')?communityText('adult-community-'):communityText('ad-community-')
  });
  const refreshed = await send({type:'DG_UPDATE_COMMUNITY_FILTERS'});
  assert.equal(refreshed.ok,true,`Approved community-list refresh should pass with valid test lists: ${refreshed.error||''}`);
  assert.equal(store.dgCommunityFilterLists.adDomains.length,150);
  assert.equal(store.dgCommunityFilterLists.adultDomains.length,150);
  assert.equal(refreshed.status.adDomains,150);
  assert(dynamicRules.some(r=>r.id===sandbox.DGFilterListUpdater.AD_ID_START&&r.condition?.urlFilter==='||ad-community-0.example^'));
  assert(dynamicRules.some(r=>r.id===sandbox.DGFilterListUpdater.ADULT_ID_START&&r.condition?.urlFilter==='||adult-community-0.example^'));
  const previousAdDomains = structuredClone(store.dgCommunityFilterLists.adDomains);
  sandbox.fetch = async () => ({
    ok:true, status:200, url:'https://unexpected-redirect.example/list', headers:{get:()=> '4096'}, text:async()=>communityText('replacement-')
  });
  const failedRefresh = await send({type:'DG_UPDATE_COMMUNITY_FILTERS'});
  assert.equal(failedRefresh.ok,false,'A source redirecting away from the approved host must be rejected');
  assert.deepEqual(store.dgCommunityFilterLists.adDomains,previousAdDomains,'Failed source refresh must keep last-known-good domains');
  assert(dynamicRules.some(r=>r.condition?.urlFilter==='||ad-community-0.example^'),'Failed update must retain already-applied last-known-good rules');
  console.log('PASS  Community list runtime: approved-source update, bounded rules, hostile redirect rejection, and last-known-good protection');

  // Automatic browsing points have a daily cap, while time can still qualify toward plant growth.
  const scoreState = structuredClone(store.dgState.dgState || store.dgState);
  scoreState.plant.growthPoints = 120;
  scoreState.browsing.pointEvents = Array.from({ length: 12 }, (_, i) => ({ id: `auto-${i}`, source: 'browser', category: 'productive', points: 1, createdAt: new Date().toISOString() }));
  const scoreBefore = scoreState.plant.growthPoints;
  sandbox.applyBrowserPoint(scoreState, 'productive', 'study.example', 2);
  assert.equal(scoreState.plant.growthPoints, scoreBefore, 'Automatic points should stop increasing after the daily ceiling');
  assert.equal(scoreState.browsing.pointEvents.at(-1).points, 0, 'Capped automatic activity should still be recorded transparently with zero additional points');
  assert.equal(scoreState.browsing.dailyMinutesByCategory[`${today}:productive`], 2, 'Productive minutes must still be counted for growth-day qualification after the points cap');
  console.log('PASS  Automatic browsing points use a transparent daily ceiling while productive minutes still count');

  // A stale tab without the reminder bridge should recover by injecting the in-page renderer once.
  failNextTabMessage = true;
  const priorInjections = injectedScriptCalls.length;
  const preview = await send({ type: 'DG_TEST_REMINDER' });
  assert.equal(preview.ok, true, 'Reminder preview should recover if an old tab has no message listener');
  assert.equal(preview.delivered, true);
  assert.equal(injectedScriptCalls.length, priorInjections + 1, 'Reminder path should inject the isolated renderer exactly once on first-delivery failure');
  assert.deepEqual(injectedScriptCalls.at(-1).files, ['notification-content.js']);
  assert.equal(sentTabMessages.at(-1).type, 'DG_IN_APP_NOTIFICATION', 'Reminder retry should deliver the in-page notification message');
  assert.equal(sentTabMessages.at(-1).title, 'A little Greenhouse hello 🌱');
  console.log('PASS  Reminder preview recovers from a stale tab by injecting the isolated in-page card and retrying delivery');

  // Crossing the configured active-time threshold should deliver a card and consume one threshold window.
  tab.url = 'https://learn.example/article';
  const activeState = store.dgState.dgState || store.dgState;
  activeState.digitalAwareness.remindersEnabled = true;
  activeState.digitalAwareness.reminderMinutes = 20;
  activeState.wellbeing ||= {}; activeState.wellbeing.remindersEnabled = true; activeState.wellbeing.activeUseDate = today; activeState.wellbeing.activeUseSecondsToday = 19*60+10; activeState.wellbeing.lastActiveUseTickAt = Date.now()-61000; activeState.wellbeing.lastCheckinBucket = 0; activeState.wellbeing.lastHourlyBucket = 0;
  activeState.digitalAwareness.activeFocusSession = null;
  activeState.browsing.activeBrowsingSeconds = 2670;
  activeState.browsing.lastReminderAttemptAt = 0;
  activeState.browsing.lastActiveBrowsingTickAt = Date.now() - 61000;
  activeState.browsing.pageSignals['learn.example'] = {domain:'learn.example',category:'productive',confidence:.98,observedAt:new Date().toISOString(),visitId:'reminder-threshold'};
  activeState.browsing.tabSignals['12'] = {domain:'learn.example',category:'productive',confidence:.98,observedAt:new Date().toISOString(),visitId:'reminder-threshold'};
  activeState.browsing.trackingProgress = {domain:'learn.example',category:'productive',seconds:0,lastTickAt:Date.now()-61000};
  activeState.browsing.distractionSession = {domain:null,activeMinutes:0,activeSeconds:0,warned:false,redirected:false,lastTickAt:null};
  const remindersBeforeTick = sentTabMessages.filter(m => m.type === 'DG_IN_APP_NOTIFICATION' && m.title === '20-minute check-in ✦').length;
  await send({type:'DG_TICK_NOW'});
  const postReminderState = store.dgState.dgState || store.dgState;
  const reminderCountAfterTick = sentTabMessages.filter(m => m.type === 'DG_IN_APP_NOTIFICATION' && m.title === '20-minute check-in ✦').length;
  assert.equal(reminderCountAfterTick, remindersBeforeTick + 1, 'Reaching the active browsing threshold should send an in-page reminder');
  assert.equal(postReminderState.wellbeing.lastCheckinBucket, 1, 'A 20-minute check-in consumes exactly one threshold bucket');
  assert.ok(postReminderState.wellbeing.activeUseSecondsToday >= 20*60, 'Active use before the prompt is persisted');
  console.log('PASS  20-minute active-use check-in triggers once and advances the wellbeing bucket');

  // A user's "Mark useful" correction must survive the next contradictory page-analysis event.
  const correction = await send({type:'DG_SET_PAGE_CATEGORY', category:'productive', tabId:12});
  assert.equal(correction.ok, true, `Mark useful should save a local correction: ${correction.error || ''}`);
  let correctionState = store.dgState.dgState || store.dgState;
  assert.equal(correctionState.browsing.pageCorrections['learn.example'].category, 'productive');
  assert.equal(correctionState.browsing.pageSignals['learn.example'].source, 'user-correction');
  assert.equal(correctionState.browsing.pageSignals['learn.example'].confidence, 0.98, 'A correction must preserve classifier confidence rather than set it to 100%');
  const rescan = await send({
    type:'DG_PAGE_ANALYSIS', domain:'learn.example', category:'distracting', confidence:0.99,
    visitId:'contradictory-analysis-after-correction', pageKind:'social_feed',
    productiveScore:0, distractingScore:99,
    pageFeatures:{headings:1,codeBlocks:0,videos:4,feedSignals:8,editorSurface:false,questionAnswerEvidence:0},
    topicHints:['social']
  }, {url:'https://learn.example/article', tab:{id:12,url:'https://learn.example/article'}});
  assert.equal(rescan.ok, true, 'The next page-analysis event should be accepted');
  correctionState = store.dgState.dgState || store.dgState;
  assert.equal(correctionState.browsing.pageSignals['learn.example'].category, 'productive', 'Fresh heuristics must not overwrite the user-facing correction');
  assert.equal(correctionState.browsing.pageSignals['learn.example'].detectedCategory, 'distracting', 'Raw classifier evidence must be retained separately from the correction');
  assert.equal(correctionState.browsing.pageSignals['learn.example'].source, 'user-correction');
  assert.equal(correctionState.browsing.siteLearning['learn.example'].productive, 0, 'Corrected labels must not contaminate productive site history');
  assert.equal(correctionState.browsing.siteLearning['learn.example'].distracting, 1, 'Site history must learn from raw classifier evidence, not the correction');
  console.log('PASS  Mark useful correction persists as feedback while preserving independent classifier evidence and evidence-only site learning');
})().catch(error=>{console.error(error.stack||error);process.exitCode=1;});
