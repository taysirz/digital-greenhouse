'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const nodeCrypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');
const todayDate = new Date();
const today = `${todayDate.getFullYear()}-${String(todayDate.getMonth()+1).padStart(2,'0')}-${String(todayDate.getDate()).padStart(2,'0')}`;
const storedState = {
  schemaVersion: 8,
  createdAt: new Date().toISOString(),
  aiCompanion: { enabled: true, consentAt: new Date().toISOString(), fullContextConsentAt: new Date().toISOString(), fullContextConsentVersion: 2, includeRoutineContext: true, lastRunAt: null, lastStatus: 'ready', lastError: null, lastDecision: null, runs: [], history: [], feedback: [] },
  profile: { onboardingComplete: true, routineNotes: 'LOCAL_NOTE_MUST_NOT_BE_SENT', goalNotes: 'LOCAL_GOAL_MUST_NOT_BE_SENT', tone: 'gentle', dailyObjectives: ['Study','Move','Rest'], dataCollection: { enabled: true, consentAt: new Date().toISOString(), consentVersion: 5, endpoint: 'http://127.0.0.1:8787' } },
  plant: { growthPoints: 73, health: 81, milestones: [21,51], lastHealthCheckIn: null, plantedAt: new Date().toISOString(), growthDays: 4, qualifiedDates: [] },
  lifeGrowth: { activityLog: [], goals: [], rewardLedger: [], rewardPlan: null, activeActivity: null, manualPointsByDay: {}, activityAwardedByDay: {}, objectiveCompletions: {} },
  digitalAwareness: { selectedDomains: [], focusSessions: [], remindersEnabled: true, reminderMinutes: 45, nudgeAfterMinutes: 5, activeFocusSession: null, dailyObjectives: [] },
  digitalProtection: { adBlockEnabled: true, adultSiteBlockingEnabled: true, aiToolBlockingEnabled: false, aiToolDomains: [], customBlockedDomains: [], allowlist: ['school.example'], gardenGuardEnabled: false, distractionGuardEnabled: true, temporaryOverrides: {} },
  wellbeing: { selfRating: 3, note: 'DO_NOT_SEND' },
  browsing: { dailyActiveMinutes: { [today]: 45 }, dailyMinutesByCategory: { [`${today}:productive`]: 30, [`${today}:distracting`]: 5 }, hourlyCategorySeconds: { [`${today}:morning:productive`]: 2400, [`${today}:evening:distracting`]: 300 }, lastCategorySample: null, dailyNetPoints: { [today]: 12 }, pointEvents: [], dailyMinutes: {}, lastPromptAt: null, lastPromptPattern: null, pageSignals: {}, tabSignals: {}, siteLearning: {}, trackingEnabled: true, pointIntervalMinutes: 2, productiveDomains: [], distractingDomains: [], trackingProgress: { domain: null, category: null, seconds: 0, lastTickAt: null }, activeBrowsingSeconds: 0, lastActiveBrowsingTickAt: null, lastReminderAt: null, lastReminderAttemptAt: null, distractionSession: { domain: null, activeMinutes: 0, activeSeconds: 0, warned: false, redirected: false, lastTickAt: null }, lastTrackingDomain: 'school.example', lastTrackingCategory: 'productive' }
};
let store = structuredClone({ dgState: storedState });
let runtimeMessageListener = null;
let alarmListener = null;
let tabActivatedListener = null;
let tabUpdatedListener = null;
let modelCalls = 0;
let planCalls = 0;
let sentPlanBody = null;
let failNextModelCall = false;
let nextDecision = null;
let flipProtectionToReminderOnlyOnModelResponse = false;
let sentNotification = null;
let sentModelBody = null;
let createdTabs = [];
let updatedTabs = [];
let tabQueryOverride = null;
let popupShouldFail = true;
const tab = { id: 12, url: 'https://school.example/study', active: true, windowId: 1 };
const chrome = {
  storage: {
    local: {
      get: async () => structuredClone(store),
      set: async value => { store = { ...store, ...structuredClone(value) }; }
    },
    onChanged: { addListener: () => {} }
  },
  runtime: {
    id: 'test-extension-id',
    onInstalled: { addListener: () => {} },
    onStartup: { addListener: () => {} },
    onMessage: { addListener: fn => { runtimeMessageListener = fn; } },
    getURL: file => `chrome-extension://test-extension-id/${file}`
  },
  action: { openPopup: async () => { if (popupShouldFail) throw new Error('Simulated popup open rejection'); return true; } },
  alarms: { create: () => {}, clear: async () => true, onAlarm: { addListener: fn => { alarmListener = fn; } } },
  windows: { getLastFocused: async () => ({ focused: true, id: 1 }) },
  idle: { queryState: async () => 'active' },
  tabs: {
    onActivated: { addListener: fn => { tabActivatedListener = fn; } },
    onUpdated: { addListener: fn => { tabUpdatedListener = fn; } },
    query: async queryInfo => {
      if (tabQueryOverride) {
        let rows = structuredClone(tabQueryOverride);
        if (queryInfo?.active === true) rows = rows.filter(row => row.active === true);
        if (Number.isInteger(queryInfo?.windowId)) rows = rows.filter(row => row.windowId == null || row.windowId === queryInfo.windowId);
        return rows;
      }
      return [tab, ...createdTabs];
    },
    sendMessage: async (_id, payload) => { sentNotification = payload; return {}; },
    update: async (id, changes) => { updatedTabs.push({ id, changes }); const found = createdTabs.find(t => t.id === id); if (found) Object.assign(found, changes); return found || {}; },
    create: async options => { const created = { id: 90 + createdTabs.length, ...options, url: options.url }; createdTabs.push(created); return created; },
    get: async id => createdTabs.find(t => t.id === id) || tab
  }
};
const sandbox = {
  chrome,
  console: { log() {}, debug() {}, warn() {}, error() {} },
  crypto: nodeCrypto,
  fetch: async (url, init) => {
    if (url === 'http://127.0.0.1:8787/v1/agent/plan') {
      planCalls++; sentPlanBody = JSON.parse(init.body);
      return { ok: true, status: 200, json: async () => ({ ok: true, plan: { summary:'A balanced day', objectives:[{label:'Study one topic',type:'studying',targetMinutes:25},{label:'Move a little',type:'exercise',targetMinutes:15},{label:'Rest or read',type:'rest',targetMinutes:20}], strategy:'Start small and adjust.', focusMinutes:25 } }) };
    }
    assert.equal(url, 'http://127.0.0.1:8787/v1/agent/decision');
    modelCalls++;
    sentModelBody = JSON.parse(init.body);
    if (failNextModelCall) {
      failNextModelCall = false;
      return { ok: false, status: 503, json: async () => ({ ok: false, error: 'AI is not configured yet.' }) };
    }
    const decision = nextDecision || { action: 'suggest_focus', title: 'A tiny study sprint', message: 'A short Focus session could help with one next step.', focusMinutes: 25, confidence: 0.70, reason: 'A short planned session fits recent activity.' };
    nextDecision = null;
    if (flipProtectionToReminderOnlyOnModelResponse) { flipProtectionToReminderOnlyOnModelResponse = false; store.dgState.digitalProtection.distractionEnforcement = 'remind'; }
    return { ok: true, status: 200, json: async () => ({ ok: true, decision }) };
  },
  AbortSignal,
  URL,
  setTimeout,
  clearTimeout,
  importScripts: (...files) => { sandbox.DGData = { readState: async () => store.dgState, normalizeCollection: () => ({ enabled: false }) }; if (files.includes('ai-client.js')) sandbox.DGAI = { cleanEndpoint: value => new URL(value || 'http://127.0.0.1:8787').origin, request: (route, options, current) => sandbox.fetch(`${current?.profile?.dataCollection?.endpoint || 'http://127.0.0.1:8787'}${route}`, options) }; if (files.includes('growth-engine.js')) sandbox.DGGrowth = require(path.join(ROOT, 'growth-engine.js')); if (files.includes('domain-utils.js')) sandbox.DGDomainUtils = require(path.join(ROOT, 'domain-utils.js')); if (files.includes('filter-list-updater.js')) sandbox.DGFilterListUpdater = require(path.join(ROOT, 'filter-list-updater.js')); }
};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), sandbox, { filename: 'background.js', timeout: 5000 });

function sendMessage(message, senderOverride = null) {
  return new Promise((resolve, reject) => {
    if (!runtimeMessageListener) return reject(new Error('Background message listener was not installed'));
    let done = false;
    const reply = value => { if (!done) { done = true; resolve(value); } };
    try { runtimeMessageListener(message, senderOverride || { url: 'chrome-extension://test-extension-id/popup.html' }, reply); }
    catch (error) { reject(error); }
    setTimeout(() => { if (!done) reject(new Error('Background message timed out')); }, 5000).unref();
  });
}

(async () => {
  assert.equal(typeof alarmListener, 'function', 'Agent alarm listener was not registered');
  // Active-use reminders should count one-minute worker ticks accurately and distinguish the hourly reset.
  const wellbeingDate = sandbox.localDateKey(new Date());
  const checkinStamp = Date.now();
  const checkinState = { wellbeing:{ activeUseDate:wellbeingDate, activeUseSecondsToday:18*60, lastActiveUseTickAt:checkinStamp-120000, lastCheckinBucket:0, lastHourlyBucket:0 } };
  assert.equal(sandbox.accountWellbeingUse(checkinState, checkinStamp), 'wellbeing-checkin', 'A 20-minute active-use crossing must trigger a check-in');
  assert.equal(checkinState.wellbeing.activeUseSecondsToday, 20*60, 'A delayed one-minute worker tick must not undercount active use');
  const hourStamp = Date.now();
  const hourlyState = { wellbeing:{ activeUseDate:wellbeingDate, activeUseSecondsToday:58*60, lastActiveUseTickAt:hourStamp-120000, lastCheckinBucket:2, lastHourlyBucket:0 } };
  assert.equal(sandbox.accountWellbeingUse(hourlyState, hourStamp), 'wellbeing-break', 'The 60-minute outdoor/hydration reset must take priority at one hour');
  assert.equal(hourlyState.wellbeing.activeUseSecondsToday, 60*60, 'Hourly threshold must use correctly accumulated foreground time');
  console.log('PASS  Wellbeing scheduler: 20-minute active-use check-ins, accurate tick accounting, hourly hydration/outdoor priority');
  // Routine schedules honour selected weekdays and attribute overnight windows to their start day.
  assert.equal(sandbox.routineWindowActive({ routineWindow:{ enabled:true, start:'17:00', end:'19:00', days:[1,2,3,4,5] } }, new Date(2026,9,19,18,0)), true, 'Selected Monday routine should be active in its time window');
  assert.equal(sandbox.routineWindowActive({ routineWindow:{ enabled:true, start:'17:00', end:'19:00', days:[1,2,3,4,5] } }, new Date(2026,9,18,18,0)), false, 'Unselected Sunday routine should remain inactive');
  assert.equal(sandbox.routineWindowActive({ routineWindow:{ enabled:true, start:'22:00', end:'06:00', days:[1] } }, new Date(2026,9,20,1,0)), true, 'Monday overnight routine remains active after midnight on Tuesday');
  assert.equal(sandbox.routineWindowActive({ routineWindow:{ enabled:true, start:'22:00', end:'06:00', days:[1] } }, new Date(2026,9,20,23,0)), false, 'Tuesday night should not inherit Monday schedule');
  assert.equal(sandbox.routineWindowActive({ routineWindow:{ enabled:true, start:'17:00', end:'19:00' } }, new Date(2026,9,18,18,0)), true, 'Legacy schedules without a weekday list retain every-day behaviour');
  assert.equal(sandbox.routineWindowActive({ routineWindow:{ enabled:true, start:'17:00', end:'19:00', days:[] } }, new Date(2026,9,19,18,0)), false, 'An explicitly empty weekday list cannot trigger a routine reminder');
  assert.equal(sandbox.routineWindowActive({ routineWindow:{ enabled:true, start:'99:99', end:'19:00', days:[1,2,3,4,5,6,0] } }, new Date(2026,9,19,18,0)), false, 'Corrupt time values must not activate a routine');
  assert.equal(sandbox.routineWindowAnchorDay({ routineWindow:{ start:'22:00', end:'06:00' } }, new Date(2026,9,20,1,0)), '2026-10-19', 'An overnight schedule keeps one anchor day across midnight');
  // Sleep-window awareness stays opt-in, understands overnight/daytime ranges, and anchors one reminder to the start night.
  const sleepProfile = { routineBaseline:{ sleepSchedule:{ bedtime:'22:00', wakeTime:'07:00' }, sleepNudgesEnabled:true } };
  assert.equal(sandbox.sleepWindowActive(sleepProfile, new Date(2026,9,20,23,15)), true, 'Sleep window should be active after bedtime');
  assert.equal(sandbox.sleepWindowActive(sleepProfile, new Date(2026,9,21,5,15)), true, 'Sleep window should remain active after midnight');
  assert.equal(sandbox.sleepWindowActive(sleepProfile, new Date(2026,9,20,12,0)), false, 'Sleep window should be inactive in the afternoon');
  assert.equal(sandbox.sleepWindowAnchorDay(sleepProfile, new Date(2026,9,21,1,0)), '2026-10-20', 'After-midnight sleep time should use the previous evening as its anchor');
  const daySleepProfile = { routineBaseline:{ sleepSchedule:{ bedtime:'01:00', wakeTime:'09:00' } } };
  assert.equal(sandbox.sleepWindowActive(daySleepProfile, new Date(2026,9,20,4,0)), true, 'Daytime range parser should support a sleep interval beginning after midnight');
  assert.equal(sandbox.sleepWindowActive({ routineBaseline:{ sleepSchedule:{ bedtime:'22:00', wakeTime:null } } }, new Date(2026,9,20,23,0)), false, 'An incomplete sleep schedule cannot trigger a nudge');
  assert.equal(sandbox.sleepWindowActive({ routineBaseline:{ sleepSchedule:{ bedtime:'22:00', wakeTime:'22:00' } } }, new Date(2026,9,20,23,0)), false, 'An ambiguous zero-length sleep schedule cannot trigger a nudge');
  const originalStoreBeforeSleepNudgeTest = structuredClone(store);
  const nudgeState = { profile:sleepProfile, digitalAwareness:{ remindersEnabled:true }, browsing:{} };
  assert.equal(await sandbox.maybeSleepWindowNudge(nudgeState, new Date(2026,9,21,1,0).getTime()), true, 'Opted-in sleep window should deliver an in-page reminder while browsing');
  assert.equal(sentNotification?.kind, 'sleep', 'Sleep nudge should use the in-page card channel');
  assert.equal(await sandbox.maybeSleepWindowNudge(nudgeState, new Date(2026,9,21,1,5).getTime()), false, 'Sleep nudge should be delivered at most once per sleep window');
  assert.equal(await sandbox.maybeSleepWindowNudge({ profile:{...sleepProfile, routineBaseline:{...sleepProfile.routineBaseline,sleepNudgesEnabled:false}}, digitalAwareness:{ remindersEnabled:true }, browsing:{} }, new Date(2026,9,21,1,0).getTime()), false, 'Sleep nudges must remain off unless the user opts in');
  assert.equal(await sandbox.maybeSleepWindowNudge({ profile:sleepProfile, digitalAwareness:{ remindersEnabled:false }, browsing:{} }, new Date(2026,9,21,1,0).getTime()), false, 'Master reminder switch must also disable sleep nudges');
  assert.equal(await sandbox.maybeSleepWindowNudge({ profile:sleepProfile, digitalAwareness:{ remindersEnabled:true }, browsing:{lastReminderAt:new Date(2026,9,21,0,59).toISOString()} }, new Date(2026,9,21,1,0).getTime()), false, 'Sleep nudge should not stack directly on another reminder card');
  store = originalStoreBeforeSleepNudgeTest; // Helper delivery tests must not replace the shared runtime fixture state.
  console.log('PASS  Sleep routine: overnight anchors, daytime windows, opt-in, once-per-window delivery, master reminder switch and non-stacking cooldown');
  // Foreground productive time must survive a switch to another productive domain instead of
  // repeatedly resetting the timer and undercounting cross-tab study.
  const crossTabNow = Date.now();
  const crossTabState = {
    plant:{growthPoints:0,health:70,qualifiedDates:[],growthDays:0}, lifeGrowth:{},
    browsing:{ trackingEnabled:true, pointIntervalMinutes:1,
      trackingProgress:{domain:'school.example',category:'productive',seconds:50,lastTickAt:crossTabNow-20000},
      pageSignals:{'school.example':{domain:'school.example',category:'productive',confidence:.95,observedAt:new Date(crossTabNow).toISOString(),pageKind:'lesson',topicHints:['learning']}},
      tabSignals:{},siteLearning:{},pageCorrections:{},dailyMinutesByCategory:{},dailyEffectiveProductiveMinutes:{},dailyNetPoints:{},dailyBrowserPoints:{},dailyContextTypes:{},dailyProgressBonusDates:{},dailyGoalBonusDates:{},dailyVarietyBonusCount:{},pointEvents:[]
    }, digitalProtection:{}, digitalAwareness:{focusSessions:[]}, profile:{goalNotes:'',dailyObjectives:[]}
  };
  sandbox.advanceBrowserTracking(crossTabState,'docs.example','productive',22,crossTabNow);
  assert.equal(crossTabState.browsing.pointEvents.length,1,'A one-minute measured interval should be finalised on tab switch');
  assert.equal(crossTabState.browsing.pointEvents[0].domain,'school.example','Elapsed time must be attributed to the last observed foreground page');
  assert.equal(crossTabState.browsing.pointEvents[0].minutes,1);
  assert.equal(crossTabState.browsing.trackingProgress.domain,'docs.example');
  assert.equal(crossTabState.browsing.trackingProgress.seconds,10,'Partial productive time should carry across productive domains');
  sandbox.advanceBrowserTracking(crossTabState,'social.example','distracting',23,crossTabNow+60000);
  assert.equal(crossTabState.browsing.pointEvents.at(-1).domain,'docs.example','The minute before a category change should be attributed to the previously active productive page');
  assert.equal(crossTabState.browsing.trackingProgress.seconds,0,'Unfinished partial time must not leak across productive-to-distracting transitions');
  // Repeated-visit learning must remain usable when a current page signal is fresh but uncertain.
  store.dgState.browsing.pageSignals['learned.example'] = { domain:'learned.example', category:'neutral', confidence:0.2, observedAt:new Date().toISOString(), visitId:'uncertain' };
  store.dgState.browsing.siteLearning['learned.example'] = { visits:6, productive:5, distracting:1, neutral:0, lastObservedAt:new Date().toISOString() };
  assert.equal(sandbox.inferredCategory(store.dgState, 'learned.example', 999), 'productive', 'Uncertain current signal must not mask consistent repeated-visit learning');
  store.dgState.browsing.pageCorrections ||= {};
  store.dgState.browsing.pageCorrections['learned.example'] = { category:'distracting', updatedAt:new Date().toISOString(), corrections:1 };
  assert.equal(sandbox.inferredCategory(store.dgState, 'learned.example', 999), 'distracting', 'Explicit user correction must outrank repeated-visit learning');
  delete store.dgState.browsing.pageCorrections['learned.example'];
  store.dgState.browsing.pageSignals['school.example'] = { domain:'school.example', category:'productive', confidence:0.82, observedAt:new Date().toISOString(), visitId:'school-1', pageKind:'lesson', topicHints:['learning','unknown-private-topic'], pageFeatures:{productiveScore:8,distractingScore:0,headings:5,codeBlocks:0,videos:0,feedSignals:0,editorSurface:false,questionAnswerEvidence:1} };
  store.dgState.browsing.tabSignals[String(tab.id)] = structuredClone(store.dgState.browsing.pageSignals['school.example']);
  const response = await sendMessage({ type: 'DG_AGENT_RUN_NOW' });
  assert.equal(response.ok, true, `Agent run failed: ${JSON.stringify(response)}`);
  assert.equal(response.result.decision.action, 'suggest_focus');
  assert.equal(modelCalls, 1);
  assert.equal(sentNotification?.kind, 'agent', 'AI action was not sent to the page widget');
  assert.equal(sentNotification?.agentAction, 'suggest_focus');
  assert.equal(sentNotification?.focusMinutes, 25);
  assert.equal(sentModelBody.snapshot.activity.productiveMinutesToday, 30);
  assert.equal(sentModelBody.snapshot.rhythm.productivePeakPart, 'morning', 'Coarse local day-part summary should be passed to the AI');
  assert.equal(sentModelBody.snapshot.rhythm.distractionPeakPart, 'not_enough_data', 'Short sample should not overstate a distraction rhythm');
  assert.equal(sentModelBody.snapshot.memory.focusOutcomes.started, 0);
  assert.equal(sentModelBody.snapshot.activity.currentPageKind, 'lesson', 'AI should receive the bounded local page-kind label');
  assert.equal(sentModelBody.snapshot.activity.pageFeatures.headings, 5, 'AI should receive numeric local page-structure features');
  assert.deepEqual(Array.from(sentModelBody.snapshot.activity.topicHints), ['learning'], 'AI receives only bounded, allowlisted topic labels');
  assert(sentModelBody.snapshot.learning.classifierEvidence && Number.isInteger(sentModelBody.snapshot.learning.classifierEvidence.repeatedSites), 'AI should receive domain-free aggregate classifier evidence');
  assert(!JSON.stringify(sentModelBody.snapshot).includes('school.example'), 'AI snapshot must not include raw domains');
  assert.equal(sentModelBody.allowCloudFallback, false, 'Proactive AI must stay local unless a separate cloud permission has been saved');
  const cloudPermissionOff = await sendMessage({ type: 'DG_AGENT_SAVE_SETTINGS', settings: { enabled: true, consent: true, allowCloudAI: false, includeRoutineContext: false, autoStartFocusOnDistraction: false } });
  assert.equal(cloudPermissionOff.ok, true);
  assert.equal(store.dgState.aiCompanion.allowCloudAI, false, 'Local AI consent must not imply cloud consent');
  const cloudPermissionOn = await sendMessage({ type: 'DG_AGENT_SAVE_SETTINGS', settings: { enabled: true, consent: true, allowCloudAI: true, includeRoutineContext: false, autoStartFocusOnDistraction: false } });
  assert.equal(cloudPermissionOn.ok, true);
  assert.equal(store.dgState.aiCompanion.allowCloudAI, true, 'Separate cloud opt-in should be persisted explicitly');
  await sendMessage({ type: 'DG_AGENT_SAVE_SETTINGS', settings: { enabled: true, consent: true, allowCloudAI: false, includeRoutineContext: false, autoStartFocusOnDistraction: false } });
  assert.equal(store.dgState.aiCompanion.allowCloudAI, false, 'Cloud permission should be revocable without disabling local AI');
  const modelInput = JSON.stringify(sentModelBody);
  for (const consentedValue of ['school.example','LOCAL_NOTE_MUST_NOT_BE_SENT','LOCAL_GOAL_MUST_NOT_BE_SENT','DO_NOT_SEND']) assert(modelInput.includes(consentedValue), `The explicitly consented full personal context was omitted from AI request: ${consentedValue}`);
  assert.equal(store.dgState.aiCompanion.history.at(-1).action, 'suggest_focus');

  const feedback = await sendMessage({ type: 'DG_AGENT_FEEDBACK', decisionId: store.dgState.aiCompanion.history.at(-1).id, rating: 'helpful' });
  assert.equal(feedback.ok, true);
  assert.equal(store.dgState.aiCompanion.feedback.at(-1).rating, 'helpful');
  assert.equal(store.dgState.aiCompanion.memory.totalFeedback, 1, 'Cumulative local memory should record feedback');
  assert.equal(store.dgState.aiCompanion.memory.actionStats.suggest_focus.helpful, 1, 'Memory must retain per-action feedback counters');
  assert(Object.keys(store.dgState.aiCompanion.memory.contextStats || {}).length > 0, 'Feedback must update bounded context-specific learning memory');
  assert(Object.values(store.dgState.aiCompanion.memory.contextStats).some(row => row.helpful === 1), "Context memory should retain the user positive rating");
  const socialDeclinedKey = sandbox.contextKeyFor({ trigger:'focus-scroll', part:'evening', category:'distracting', pageKind:'social_feed', action:'suggest_focus' });
  store.dgState.aiCompanion.memory.contextStats[socialDeclinedKey] = { helpful:1, not_now:5, updatedAt:new Date().toISOString() };
  store.dgState.aiCompanion.history = [];
  const differentContext = sandbox.applyDecisionPolicy(store.dgState, { action:'suggest_focus', title:'Focus', message:'Test page-kind separation', confidence:0.95 }, { trigger:'focus-scroll', category:'distracting', part:'evening', pageKind:'lesson' });
  assert.equal(differentContext.action, 'suggest_focus', 'Declines on a social feed should not suppress a different page-kind context');
  const lessonDeclinedKey = sandbox.contextKeyFor({ trigger:'focus-scroll', part:'evening', category:'distracting', pageKind:'lesson', action:'suggest_focus' });
  store.dgState.aiCompanion.memory.contextStats[lessonDeclinedKey] = { helpful:1, not_now:5, updatedAt:new Date().toISOString() };
  const contextGuard = sandbox.applyDecisionPolicy(store.dgState, { action:'suggest_focus', title:'Focus', message:'Test context policy', confidence:0.95 }, { trigger:'focus-scroll', category:'distracting', part:'evening', pageKind:'lesson' });
  assert.equal(contextGuard.action, 'none', 'Context-specific declines should suppress the same repeated intervention');
  store.dgState.aiCompanion.memory.contextStats['manual|morning|productive|suggest_focus'] = { helpful:2, not_now:0, updatedAt:new Date().toISOString() };
  const migratedState = await sandbox.state();
  assert.equal(migratedState.aiCompanion.memory.contextStats['manual|morning|productive|unknown|suggest_focus'].helpful, 2, 'Legacy context memory should migrate into page-kind-aware keys');

  // Settings writes must patch the current background state instead of replacing it with a
  // popup snapshot that may have gone stale while background tracking was recording activity.
  const activeMinutesBeforeSettings = Number(store.dgState.browsing.dailyActiveMinutes[today]) || 0;
  const safeProfileSave = await sendMessage({ type:'DG_SAVE_PROFILE', profile:{ routineNotes:'Updated locally', goalNotes:'Read more', tone:'gentle', dailyObjectives:['Study','Move','Rest'], dailyObjectiveMode:'custom', routineBaseline:{primaryType:'reading',minutesPerDay:10}, routineWindow:{enabled:false,label:'Reading',start:'17:00',end:'19:00',days:[1,2,3,4,5]} } });
  assert.equal(safeProfileSave.ok,true,`Profile patch failed: ${JSON.stringify(safeProfileSave)}`);
  assert.equal(store.dgState.browsing.dailyActiveMinutes[today],activeMinutesBeforeSettings,'Saving the profile must retain the newest tracking counters');
  assert.equal(store.dgState.profile.dailyObjectiveMode,'custom');
  assert.equal(store.dgState.profile.goalNotes,'Read more');
  const invalidWindow = await sendMessage({ type:'DG_SAVE_PROFILE', profile:{ routineWindow:{enabled:true,label:'Broken',start:'17:00',end:'17:00',days:[1]} } });
  assert.equal(invalidWindow.ok,false,'An invalid routine window must be rejected, not persisted');
  const pointEventsBeforeSettings = store.dgState.browsing.pointEvents.length;
  const safeTrackingSave = await sendMessage({ type:'DG_SAVE_TRACKING_SETTINGS',enabled:true,pointIntervalMinutes:3 });
  assert.equal(safeTrackingSave.ok,true);
  assert.equal(store.dgState.browsing.pointIntervalMinutes,3);
  assert.equal(store.dgState.browsing.pointEvents.length,pointEventsBeforeSettings,'Changing the sampling interval must not overwrite point history');
  console.log('PASS  Settings state safety: profile and tracking changes patch the latest state, preserve counters, validate routine windows and keep custom tasks');

  const plan = await sendMessage({ type: 'DG_AGENT_CREATE_PLAN' });
  assert.equal(plan.ok, true, `Daily plan failed: ${JSON.stringify(plan)}`);
  assert.equal(planCalls, 1); assert.equal(store.dgState.aiCompanion.dailyPlan.objectives.length, 3);
  assert(JSON.stringify(sentPlanBody).includes('Updated locally') && JSON.stringify(sentPlanBody).includes('Read more'), 'The AI brain uses the current profile through all-or-none full-context consent, not a separate routine/goal category toggle');
  const applied = await sendMessage({ type: 'DG_AGENT_APPLY_PLAN' });
  assert.equal(applied.ok, true); assert.deepEqual(Array.from(store.dgState.profile.dailyObjectives), ['Study one topic','Move a little','Rest or read']); assert.equal(store.dgState.profile.dailyObjectiveMode,'custom','Applying a chosen plan must switch the objective editor to its three saved tasks');
  assert.equal(store.dgState.aiCompanion.memory.plansApplied, 1, 'Applied plan should be remembered');

  await alarmListener({ name: 'dg-ai-agent-check' });
  assert.equal(modelCalls, 1, 'Scheduled AI check ignored the cooldown');

  const feedbackCountBeforePreview = store.dgState.aiCompanion.feedback.length;
  const preview = await sendMessage({ type: 'DG_AGENT_PREVIEW_ACTION' });
  assert.equal(preview.ok, true);
  assert.equal(modelCalls, 1, 'Preview must not call the AI API');
  assert.equal(store.dgState.aiCompanion.history.at(-1).preview, true);
  assert.match(sentNotification.title, /^Preview:/);
  await sendMessage({ type: 'DG_AGENT_FEEDBACK', decisionId: store.dgState.aiCompanion.history.at(-1).id, rating: 'helpful' });
  assert.equal(store.dgState.aiCompanion.feedback.length, feedbackCountBeforePreview, 'Preview feedback must not influence future AI decisions');

  // A failed backend/model response must not consume the successful-decision allowance.
  store.dgState.aiCompanion.lastRunAt = null;
  store.dgState.aiCompanion.lastAttemptAt = null;
  const successesBeforeFailure = store.dgState.aiCompanion.runs.length;
  failNextModelCall = true;
  const failed = await sendMessage({ type: 'DG_AGENT_RUN_NOW' });
  assert.equal(failed.ok, false, 'An unconfigured AI should return a visible error');
  assert.equal(store.dgState.aiCompanion.runs.length, successesBeforeFailure, 'Failed requests must not consume the daily AI decision allowance');
  assert.equal(store.dgState.aiCompanion.lastStatus, 'error');
  const retry = await sendMessage({ type: 'DG_AGENT_RUN_NOW' });
  assert.equal(retry.ok, true, 'The AI should be retryable after setup is corrected');
  assert.equal(store.dgState.aiCompanion.runs.length, successesBeforeFailure + 1, 'Only a valid AI decision should count toward the daily allowance');

  const focusDecision = store.dgState.aiCompanion.history.at(-1);
  assert.equal(focusDecision.action, 'suggest_focus');
  const startedFocus = await sendMessage({ type: 'DG_START_FOCUS', durationMinutes: 25, originDecisionId: focusDecision.id });
  assert.equal(startedFocus.ok, true, 'Focus suggested by AI must be startable');
  assert.equal(store.dgState.aiCompanion.memory.focusOutcomes.started, 1, 'Starting an AI-suggested Focus should be remembered');
  store.dgState.digitalAwareness.activeFocusSession.startedAt = new Date(Date.now() - 2 * 60000).toISOString();
  const earlyEnd = await sendMessage({ type: 'DG_END_FOCUS' });
  assert.equal(earlyEnd.ok, false, 'Strict Focus must refuse an early end command even when the session was started by AI');
  assert.equal(earlyEnd.locked, true);
  const allowlistDuringLock = await sendMessage({ type:'DG_ADD_CURRENT_TO_FOCUS_ALLOWLIST', tabId:tab.id });
  assert.equal(allowlistDuringLock.ok, false, 'Strict Focus must freeze allowlist changes until expiry');
  assert.equal(allowlistDuringLock.locked, true, 'Blocked allowlist edits must explicitly report the lock');
  store.dgState.digitalAwareness.activeFocusSession.endsAt = new Date(Date.now() - 1000).toISOString();
  const endFocus = await sendMessage({ type: 'DG_END_FOCUS' });
  assert.equal(endFocus.ok, true, 'Focus may finish after the recorded timer expires');
  assert.equal(store.dgState.aiCompanion.memory.focusOutcomes.interrupted, 1, 'An interrupted AI-suggested Focus should be learned');
  const beforeResetGrowth = store.dgState.plant.growthPoints;
  const resetMemory = await sendMessage({ type: 'DG_AGENT_RESET_LEARNING' });
  assert.equal(resetMemory.ok, true);
  assert.equal(store.dgState.aiCompanion.memory.totalFeedback, 0, 'Memory reset should clear learned feedback counters');
  assert.equal(store.dgState.plant.growthPoints, beforeResetGrowth, 'Clearing AI memory must not erase plant growth');

  // The extension must enforce a single active Focus session even if the mocked model proposes another.
  store.dgState.aiCompanion.enabled = true;
  store.dgState.aiCompanion.lastRunAt = null;
  store.dgState.aiCompanion.lastAttemptAt = null;
  store.dgState.digitalAwareness.activeFocusSession = { id: 'already-active', startedAt: new Date().toISOString(), endsAt: new Date(Date.now()+25*60000).toISOString(), targetMinutes: 25 };
  const activeFocusDecision = await sendMessage({ type: 'DG_AGENT_RUN_NOW' });
  assert.equal(activeFocusDecision.ok, true);
  assert.equal(store.dgState.aiCompanion.lastDecision.action, 'nudge', 'An AI response may not start a second Focus session');
  assert.match(store.dgState.aiCompanion.lastDecision.title, /current Focus/i);

  // Automatic Focus is only possible after separate opt-in, for a confidently distracting current page,
  // an event-triggered model decision with high confidence, and no active Focus session.
  store.dgState.digitalAwareness.activeFocusSession = null;
  store.dgState.aiCompanion.enabled = true;
  store.dgState.aiCompanion.consentAt = new Date().toISOString(); store.dgState.aiCompanion.fullContextConsentAt = new Date().toISOString(); store.dgState.aiCompanion.fullContextConsentVersion = 2;
  store.dgState.aiCompanion.autoStartFocusOnDistraction = true;
  store.dgState.aiCompanion.lastRunAt = null; store.dgState.aiCompanion.lastAttemptAt = null;
  store.dgState.aiCompanion.runs = [];
  tab.url = 'https://distraction.example/feed';
  const observedAt = new Date().toISOString();
  store.dgState.browsing.pageSignals['distraction.example'] = { domain:'distraction.example', category:'distracting', confidence:0.98, observedAt, visitId:'test-visit' };
  store.dgState.browsing.tabSignals[String(tab.id)] = { ...store.dgState.browsing.pageSignals['distraction.example'] };
  nextDecision = { action:'start_focus', title:'Starting a Focus session', message:'Let’s switch to a calmer 15-minute session.', focusMinutes:25, confidence:0.96, reason:'A high-confidence distraction warning matched your opt-in.' };
  const automaticFocus = await sandbox.maybeRunAiAgent({ force:true, trigger:'distraction-warning' });
  assert.equal(automaticFocus.ok, true, `Eligible auto Focus should run: ${JSON.stringify(automaticFocus)}`);
  assert.equal(automaticFocus.automaticFocusStarted, true, 'AI did not start Focus after every opt-in and safety check passed');
  assert.equal(store.dgState.digitalAwareness.activeFocusSession.automatic, true);
  assert.equal(store.dgState.digitalAwareness.activeFocusSession.targetMinutes, 15, 'Automatic Focus duration must be fixed at 15 minutes');
  assert.equal(store.dgState.aiCompanion.history.at(-1).action, 'start_focus');
  assert.equal(sentModelBody.allowAutoFocus, true, 'Eligible distraction event should expose only the constrained action gate to the backend');
  store.dgState.digitalAwareness.activeFocusSession.endsAt = new Date(Date.now() - 1000).toISOString();
  const endAutomaticFocus = await sendMessage({ type:'DG_END_FOCUS' });
  assert.equal(endAutomaticFocus.ok, true, 'An automatic strict Focus session can finish after its preset duration');
  store.dgState.aiCompanion.autoStartFocusOnDistraction = false;
  store.dgState.aiCompanion.lastRunAt = null; store.dgState.aiCompanion.lastAttemptAt = null; store.dgState.aiCompanion.runs = [];
  store.dgState.browsing.pageSignals['distraction.example'].observedAt = new Date().toISOString();
  store.dgState.browsing.tabSignals[String(tab.id)].observedAt = new Date().toISOString();
  nextDecision = { action:'start_focus', title:'Focus', message:'Test that the model cannot override opt-in.', focusMinutes:15, confidence:0.99, reason:'Adversarial test.' };
  const autoFocusWithoutOptIn = await sandbox.maybeRunAiAgent({ force:true, trigger:'distraction-warning' });
  assert.equal(autoFocusWithoutOptIn.ok, true);
  assert.equal(autoFocusWithoutOptIn.automaticFocusStarted, undefined, 'Focus started without user opt-in');
  // Auto Focus cannot be started without opt-in. The previous session must have expired before this independent scenario.
  if (store.dgState.digitalAwareness.activeFocusSession) { store.dgState.digitalAwareness.activeFocusSession.endsAt = new Date(Date.now() - 1000).toISOString(); await sendMessage({ type: 'DG_END_FOCUS' }); }
  store.dgState.digitalAwareness.activeFocusSession = null;
  assert.equal(store.dgState.aiCompanion.lastDecision.action, 'suggest_focus', 'Unpermitted model action must be downgraded to a user choice');

  // Reminder-only mode must not be escalated into an autonomous Focus session even if the user opted in.
  store.dgState.aiCompanion.autoStartFocusOnDistraction = true;
  store.dgState.aiCompanion.lastRunAt = null; store.dgState.aiCompanion.lastAttemptAt = null; store.dgState.aiCompanion.runs = [];
  store.dgState.digitalProtection.distractionGuardEnabled = true;
  store.dgState.digitalProtection.distractionEnforcement = 'remind';
  store.dgState.browsing.pageSignals['distraction.example'].observedAt = new Date().toISOString();
  store.dgState.browsing.tabSignals[String(tab.id)].observedAt = new Date().toISOString();
  nextDecision = { action:'start_focus', title:'Focus', message:'Reminder-only must stay reminder-only.', focusMinutes:15, confidence:0.99, reason:'Adversarial test.' };
  const reminderOnly = await sandbox.maybeRunAiAgent({ force:true, trigger:'distraction-warning' });
  assert.equal(reminderOnly.ok, true);
  assert.equal(reminderOnly.automaticFocusStarted, undefined, 'Reminder-only mode must never auto-start Focus');
  assert.equal(sentModelBody.allowAutoFocus, false, 'The backend must not receive permission for auto Focus in reminder-only mode');
  assert.equal(store.dgState.aiCompanion.lastDecision.action, 'suggest_focus', 'Reminder-only mode should downgrade automatic Focus to a user offer');
  store.dgState.digitalProtection.distractionEnforcement = 'block';

  // Recheck at action time: settings can change while a model request is in flight.
  store.dgState.aiCompanion.autoStartFocusOnDistraction = true;
  store.dgState.aiCompanion.lastRunAt = null; store.dgState.aiCompanion.lastAttemptAt = null; store.dgState.aiCompanion.runs = [];
  store.dgState.browsing.pageSignals['distraction.example'].observedAt = new Date().toISOString();
  store.dgState.browsing.tabSignals[String(tab.id)].observedAt = new Date().toISOString();
  nextDecision = { action:'start_focus', title:'Focus', message:'The policy must be checked again before action.', focusMinutes:15, confidence:0.99, reason:'Race-condition test.' };
  flipProtectionToReminderOnlyOnModelResponse = true;
  const protectionChangedDuringThinking = await sandbox.maybeRunAiAgent({ force:true, trigger:'distraction-warning' });
  assert.equal(protectionChangedDuringThinking.ok, true);
  assert.equal(sentModelBody.allowAutoFocus, true, 'The request should have qualified before the setting changed');
  assert.equal(protectionChangedDuringThinking.automaticFocusStarted, false, 'Extension must re-check protection mode immediately before acting');
  assert.equal(store.dgState.aiCompanion.lastDecision.action, 'suggest_focus', 'Changing to reminder-only mid-request must downgrade the automatic action');
  assert.equal(store.dgState.digitalAwareness.activeFocusSession, null, 'A setting change during model reasoning must not start Focus');
  store.dgState.digitalProtection.distractionEnforcement = 'block';

  // User corrections are local-only and must not silently change strict Focus allowlisting.
  store.dgState.digitalProtection.allowlist = ['school.example'];
  tab.url = 'https://corrected-site.example/lesson';
  const corrected = await sendMessage({ type:'DG_SET_PAGE_CATEGORY', tabId:tab.id, category:'productive' });
  assert.equal(corrected.ok, true);
  assert.equal(store.dgState.browsing.pageCorrections['corrected-site.example'].category, 'productive');
  assert.equal(sandbox.isFocusAllowed(store.dgState, 'corrected-site.example', tab.id), false, 'Classifying a website as useful must not silently allow it during strict Focus');
  const deceptiveState = structuredClone(store.dgState);
  deceptiveState.browsing.pageSignals['corrected-site.example'] = {domain:'corrected-site.example', category:'productive', detectedCategory:'distracting', confidence:0.99, source:'user-correction', observedAt:new Date().toISOString(), pageKind:'social_feed', pageFeatures:{feedSignals:8,productiveScore:0,distractingScore:99}};
  deceptiveState.browsing.tabSignals[String(tab.id)] = structuredClone(deceptiveState.browsing.pageSignals['corrected-site.example']);
  assert.equal(sandbox.inferredCategory(deceptiveState, 'corrected-site.example', tab.id), 'productive', "The visible classification should retain the user correction");
  assert.equal(sandbox.inferredCategory(deceptiveState, 'corrected-site.example', tab.id, true), 'distracting', 'Core monitoring must still use independent observed evidence');
  assert.equal(sandbox.isDoomscrollPage(deceptiveState, 'corrected-site.example', tab.id), true, 'Mark useful must not suppress supported doomscroll detection');
  const correctedFeedWithProductiveLabel = structuredClone(deceptiveState);
  correctedFeedWithProductiveLabel.browsing.pageSignals['corrected-site.example'].detectedCategory = 'productive';
  correctedFeedWithProductiveLabel.browsing.tabSignals[String(tab.id)].detectedCategory = 'productive';
  assert.equal(sandbox.isDoomscrollPage(correctedFeedWithProductiveLabel, 'corrected-site.example', tab.id), true, 'Strong scrolling/feed evidence must remain active even if both correction and coarse category say useful');
  const pointsBeforeMislabelledVisit = Number(deceptiveState.plant.growthPoints) || 0;
  sandbox.applyBrowserPoint(deceptiveState, 'productive', 'corrected-site.example', 2, deceptiveState.browsing.pageSignals['corrected-site.example']);
  assert.equal(Number(deceptiveState.plant.growthPoints) || 0, pointsBeforeMislabelledVisit, 'Mark useful must not award points when raw evidence says distracting');
  assert.equal(deceptiveState.browsing.pointEvents.at(-1).category, 'neutral', 'Correction-only productive evidence is scored as neutral');
  const addFocusAllow = await sendMessage({ type:'DG_ADD_CURRENT_TO_FOCUS_ALLOWLIST', tabId:tab.id });
  assert.equal(addFocusAllow.ok, true);
  assert.equal(sandbox.isFocusAllowed(store.dgState, 'corrected-site.example', tab.id), true, 'Explicit allowlist action should allow the corrected site during Focus');
  const resetCorrection = await sendMessage({ type:'DG_SET_PAGE_CATEGORY', tabId:tab.id, category:'automatic' });
  assert.equal(resetCorrection.ok, true);
  assert.equal(store.dgState.browsing.pageCorrections['corrected-site.example'], undefined, 'Automatic classification reset did not clear local correction');

  // Plant health must react to well-supported distraction evidence as well as productive work.
  // The normal health model rate-limits and smooths updates, so this only allows a small change.
  const healthNow = Date.now();
  store.dgState.plant.health = 80;
  store.dgState.plant.healthModelVersion = 2;
  store.dgState.plant.healthUpdatedAt = new Date(healthNow - 60 * 60 * 1000).toISOString();
  store.dgState.plant.healthDailyDate = today;
  store.dgState.plant.healthDailyDelta = 0;
  store.dgState.browsing.dailyMinutesByCategory = {};
  for (let back = 0; back < 7; back++) {
    const day = new Date(healthNow); day.setDate(day.getDate() - back);
    const key = `${day.getFullYear()}-${String(day.getMonth()+1).padStart(2,'0')}-${String(day.getDate()).padStart(2,'0')}`;
    store.dgState.browsing.dailyMinutesByCategory[`${key}:distracting`] = 500;
  }
  sandbox.applyBrowserPoint(store.dgState, 'distracting', 'confident-feed.example', 2, { confidence:0.95, pageKind:'social_feed', topicHints:['entertainment'] });
  assert.equal(store.dgState.plant.health, 80, 'A distraction observation itself must not directly lower plant health');
  const noEvidenceHealth = { plant:{health:85,healthUpdatedAt:new Date(Date.now()-60*60*1000).toISOString(),healthModelVersion:2}, browsing:{dailyMinutesByCategory:{},routineConflictWindows:{}}, lifeGrowth:{dailyTimedMinutes:{},objectiveCompletions:{}}, digitalAwareness:{focusSessions:[]}, digitalProtection:{adBlockEnabled:true,adultSiteBlockingEnabled:true,distractionGuardEnabled:true,gardenGuardEnabled:false,customBlockedDomains:[]} };
  sandbox.recalculatePlantHealth(noEvidenceHealth,new Date());
  assert.equal(noEvidenceHealth.plant.health,85,'No activity data must not quietly drain an existing healthy plant toward neutral');
  const briefHealth = { plant:{health:82,healthUpdatedAt:new Date(Date.now()-60*60*1000).toISOString(),healthModelVersion:2}, browsing:{dailyMinutesByCategory:{[`${today}:distracting`]:15},routineConflictWindows:{}}, lifeGrowth:{dailyTimedMinutes:{},objectiveCompletions:{}}, digitalAwareness:{focusSessions:[]}, digitalProtection:{adBlockEnabled:true,adultSiteBlockingEnabled:true,distractionGuardEnabled:true,gardenGuardEnabled:false,customBlockedDomains:[]} };
  sandbox.recalculatePlantHealth(briefHealth,new Date());
  assert.equal(briefHealth.plant.health,82,'One short distraction estimate must be neutral even when health is recalculated');
  const lowActivityHealth = { plant:{health:85,healthUpdatedAt:new Date(Date.now()-60*60*1000).toISOString(),healthModelVersion:2}, browsing:{dailyMinutesByCategory:{[`${today}:productive`]:20},routineConflictWindows:{}}, lifeGrowth:{dailyTimedMinutes:{},objectiveCompletions:{}}, digitalAwareness:{focusSessions:[]}, digitalProtection:{adBlockEnabled:true,adultSiteBlockingEnabled:true,distractionGuardEnabled:true,gardenGuardEnabled:false,customBlockedDomains:[]} };
  sandbox.recalculatePlantHealth(lowActivityHealth,new Date());
  assert.equal(lowActivityHealth.plant.health,85,'Sparse healthy activity must not make an already healthy plant decay; only a meaningful risk signal may reduce it');
  sandbox.recalculatePlantHealth(store.dgState, new Date());
  assert.ok(store.dgState.plant.health < 80, 'A later smoothed health calculation should reflect aggregate awareness patterns');
  assert.ok(store.dgState.plant.health >= 78, 'One health update may move by no more than two points');
  const legacyHealthState = { plant:{health:80,healthUpdatedAt:new Date(Date.now()-60*60*1000).toISOString(),healthModelVersion:0,healthDailyDate:today,healthDailyDelta:0}, browsing:store.dgState.browsing, lifeGrowth:store.dgState.lifeGrowth, digitalProtection:store.dgState.digitalProtection, digitalAwareness:store.dgState.digitalAwareness };
  sandbox.recalculatePlantHealth(legacyHealthState, new Date());
  assert.ok(legacyHealthState.plant.health >= 78, 'Migrating an older health model must not create a sudden multi-point drop');
  assert.equal(legacyHealthState.plant.healthModelVersion, 2, 'Legacy health model should migrate to version two');
  console.log('PASS  Plant-health runtime: block events remain non-punitive, aggregate patterns are smoothed, and legacy health migrates gradually');

  store.dgState.aiCompanion.enabled = false;
  const off = await sendMessage({ type: 'DG_AGENT_RUN_NOW' });
  assert.equal(off.ok, false, 'AI ran after being disabled');

  // The optional measurable-exercise flow must persist the exact activity metric and award its
  // bounded calibration bonus through the real background message handler, not only unit helpers.
  store.dgState.digitalAwareness.activeFocusSession = null;
  store.dgState.aiCompanion.enabled = false;
  store.dgState.lifeGrowth = { activityLog: [], goals: [], rewardLedger: [], rewardPlan: null, activeActivity: null, manualPointsByDay: {}, activityAwardedByDay: {}, objectiveCompletions: {}, dailyTimedMinutes: {}, dailyTimedMinutesByType: {}, progressBonusDates: {}, goalBonusDates: {}, dailyVarietyBonusCount: {}, weeklyProgressBonusDates: {}, metricBonusDates: {} };
  store.dgState.browsing.pointEvents = [];
  store.dgState.browsing.dailyNetPoints = {};
  store.dgState.plant.growthPoints = 0;
  assert.equal(typeof tabActivatedListener, 'function', 'Active-tab changes must trigger foreground-time sampling');
  assert.equal(typeof tabUpdatedListener, 'function', 'Active-page navigations must trigger foreground-time sampling');
  store.dgState.browsing.trackingEnabled = true;
  store.dgState.browsing.pointIntervalMinutes = 1;
  store.dgState.browsing.trackingProgress = { domain:'school.example', category:'productive', seconds:50, lastTickAt:Date.now()-20000 };
  store.dgState.browsing.pageSignals['school.example'] = { domain:'school.example', category:'productive', confidence:.95, observedAt:new Date().toISOString(), pageKind:'lesson', topicHints:['learning'] };
  store.dgState.browsing.pageSignals['docs.example'] = { domain:'docs.example', category:'productive', confidence:.95, observedAt:new Date().toISOString(), pageKind:'document', topicHints:['writing'] };
  store.dgState.browsing.tabSignals[String(tab.id)] = { ...store.dgState.browsing.pageSignals['docs.example'] };
  tab.url = 'https://docs.example/work';
  await tabActivatedListener({ tabId:tab.id, windowId:1 });
  const tabSwitchEvent = store.dgState.browsing.pointEvents.find(event => event.source==='browser' && event.domain==='school.example');
  assert(tabSwitchEvent, 'A real active-tab transition should close out the previous productive interval');
  assert.equal(store.dgState.browsing.trackingProgress.domain,'docs.example');
  console.log('PASS  Active-tab event integration: tab switches close the previous productive interval exactly once');
  tab.url = 'https://fresh-study.example/lesson';
  store.dgState.browsing.trackingProgress = { domain:'docs.example', category:'productive', seconds:10, lastTickAt:Date.now()-10000 };
  const freshPage = await sendMessage({ type:'DG_PAGE_ANALYSIS', domain:'fresh-study.example', category:'productive', confidence:.96, pageKind:'lesson', productiveScore:9, distractingScore:0, topicHints:['learning'], pageFeatures:{headings:4, questionAnswerEvidence:1}, visitId:'fresh-page-runtime-test' }, { tab:{ ...tab }, url:tab.url });
  assert.equal(freshPage.ok,true,`Local page-analysis update failed: ${JSON.stringify(freshPage)}`);
  assert.equal(store.dgState.browsing.pageSignals['fresh-study.example'].category,'productive');
  assert.equal(store.dgState.browsing.trackingProgress.domain,'fresh-study.example','Page classification should immediately establish the new active-page context');
  console.log('PASS  Page-classification tracking integration: saved local signal triggers an immediate foreground sample');

  const pointsBeforeObjective = Number(store.dgState.plant.growthPoints) || 0;
  const objectiveResult = await sendMessage({ type:'DG_COMPLETE_OBJECTIVE', key:'objective-1', activityType:'reading', label:'Read a chapter' });
  assert.equal(objectiveResult.ok, true, `Objective completion failed: ${JSON.stringify(objectiveResult)}`);
  assert.equal(objectiveResult.completion.basePoints, 5, 'Real objective completion must award the five-point base amount');
  assert.ok(objectiveResult.completion.points >= 5, 'The first objective should not be silently reduced when the daily budget is available');
  assert.equal(store.dgState.plant.growthPoints, pointsBeforeObjective + objectiveResult.completion.points, 'Objective award must update the lifetime point total exactly once');
  const duplicateObjective = await sendMessage({ type:'DG_COMPLETE_OBJECTIVE', key:'objective-1', activityType:'reading', label:'Read a chapter' });
  assert.equal(duplicateObjective.alreadyComplete, true, 'The same objective key cannot be claimed twice in one day');
  assert.equal(store.dgState.plant.growthPoints, pointsBeforeObjective + objectiveResult.completion.points, 'A duplicate objective cannot duplicate lifetime points');
  const codingObjective = await sendMessage({ type:'DG_COMPLETE_OBJECTIVE', key:'objective-2', activityType:'coding', label:'Practice programming for 10 minutes', objectiveMode:'adaptive', targetMinutes:10 });
  assert.equal(codingObjective.ok, true);
  assert.equal(codingObjective.completion.type, 'coding', 'Supported custom categories must survive the actual background message handler');
  assert.equal(codingObjective.completion.mode,'adaptive');
  assert.equal(codingObjective.completion.targetMinutes,10,'The planner target must be persisted for future target progression');
  console.log('PASS  Objective completion integration: five-point base award is persisted once, replay cannot farm it, and expanded task categories survive the handler');

  const metricStarted = await sendMessage({ type:'DG_ACTIVITY_START', activityType:'exercise', label:'Push-ups' });
  assert.equal(metricStarted.ok, true, `Measured exercise timer failed to start: ${JSON.stringify(metricStarted)}`);
  assert.equal(metricStarted.activity.labelWasCustom, true, 'Explicit exercise label should be remembered for metric comparison');
  store.dgState.lifeGrowth.activeActivity.lastResumedAt = new Date(Date.now() - 20 * 60000).toISOString();
  const metricFinished = await sendMessage({ type:'DG_ACTIVITY_FINISH', quantityValue:100, quantityUnit:'reps' });
  assert.equal(metricFinished.ok, true, `Measured exercise timer failed to finish: ${JSON.stringify(metricFinished)}`);
  assert.equal(metricFinished.activity.quantityValue, 100);
  assert.equal(metricFinished.activity.quantityUnit, 'reps');
  assert.equal(metricFinished.activity.metricKey, 'exercise:push-ups:reps');
  assert.equal(metricFinished.activity.pointBreakdown.basePoints, 10, 'the measured quantity should contribute to the activity base reward');
  assert.equal(metricFinished.points >= 10, true, '100 measured repetitions should produce a meaningful bounded reward');
  assert.equal(metricFinished.activity.pointBreakdown.metricProgressBonus, 1, 'first measured result should receive its one-time calibration bonus when budget permits');
  assert.equal(store.dgState.lifeGrowth.metricBonusDates[`${today}:exercise:push-ups:reps`], true, 'Metric bonus ledger should prevent same-day repeat farming');
  console.log('PASS  Measurable exercise timer: optional label/quantity persistence, one-time calibration bonus and same-day anti-farming ledger');

  // A timer left running beyond its four-hour realistic-duration limit must cap at four hours,
  // not silently turn into a zero-minute activity when its current segment exceeds the limit.
  const longTimerStarted = await sendMessage({ type:'DG_ACTIVITY_START', activityType:'reading', label:'Reading' });
  assert.equal(longTimerStarted.ok, true);
  store.dgState.lifeGrowth.activeActivity.startedAt = new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString();
  store.dgState.lifeGrowth.activeActivity.lastResumedAt = new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString();
  const longTimerFinished = await sendMessage({ type:'DG_ACTIVITY_FINISH' });
  assert.equal(longTimerFinished.ok, true, `Long-running timer should finish safely: ${JSON.stringify(longTimerFinished)}`);
  assert.equal(longTimerFinished.activity.actualMinutes, 240, 'Overlong active timer must be capped at four hours rather than discarded');
  assert.equal(longTimerFinished.activity.accumulatedSeconds, 4 * 60 * 60, 'Persisted duration must match the four-hour cap');
  console.log('PASS  Activity timer recovery: overlong running sessions are capped at four hours, never zeroed out');

  const lifecycleStarted = await sendMessage({ type:'DG_ACTIVITY_START', activityType:'reading', label:'Reading' });
  assert.equal(lifecycleStarted.ok, true);
  store.dgState.lifeGrowth.activeActivity.lastResumedAt = new Date(Date.now() - 15 * 60000).toISOString();
  const lifecyclePaused = await sendMessage({ type:'DG_ACTIVITY_PAUSE' });
  assert.equal(lifecyclePaused.activity.status, 'paused');
  assert.ok(lifecyclePaused.activity.accumulatedSeconds >= 14 * 60, 'Pause must preserve the completed active segment');
  const frozenSeconds = lifecyclePaused.activity.accumulatedSeconds;
  store.dgState.lifeGrowth.activeActivity.pausedAt = new Date(Date.now() - 30 * 60000).toISOString();
  const lifecycleResumed = await sendMessage({ type:'DG_ACTIVITY_RESUME' });
  assert.equal(lifecycleResumed.activity.status, 'running');
  assert.equal(lifecycleResumed.activity.accumulatedSeconds, frozenSeconds, 'Resuming must not count the paused interval');
  store.dgState.lifeGrowth.activeActivity.lastResumedAt = new Date(Date.now() - 10 * 60000).toISOString();
  const lifecycleFinished = await sendMessage({ type:'DG_ACTIVITY_FINISH' });
  assert.equal(lifecycleFinished.ok, true);
  assert.ok(lifecycleFinished.activity.actualMinutes >= 24 && lifecycleFinished.activity.actualMinutes <= 26, 'Finish must count only the active 15 + 10 minute segments');
  console.log('PASS  Activity timer lifecycle: pause/resume preserves active time and excludes paused time');

  const focusTimerStarted = await sendMessage({ type:'DG_ACTIVITY_START', activityType:'studying', label:'Math revision' });
  assert.equal(focusTimerStarted.ok, true);
  store.dgState.lifeGrowth.activeActivity.lastResumedAt = new Date(Date.now() - 12 * 60000).toISOString();
  const focusWhileTimerRunning = await sendMessage({ type:'DG_START_FOCUS', durationMinutes:25 });
  assert.equal(focusWhileTimerRunning.ok, true, `Focus did not start: ${JSON.stringify(focusWhileTimerRunning)}`);
  assert.equal(store.dgState.lifeGrowth.activeActivity.status, 'paused', 'Starting Focus should pause the offline timer');
  assert.equal(store.dgState.lifeGrowth.activeActivity.pauseReason, 'focus-started');
  const timerFinishDuringFocus = await sendMessage({ type:'DG_ACTIVITY_FINISH' });
  assert.equal(timerFinishDuringFocus.ok, false, 'An activity timer cannot claim growth while Focus is active');
  store.dgState.digitalAwareness.activeFocusSession = null;
  const finishAfterFocus = await sendMessage({ type:'DG_ACTIVITY_FINISH' });
  assert.equal(finishAfterFocus.ok, true, 'The preserved timer should remain recoverable after Focus');
  assert.ok(finishAfterFocus.activity.actualMinutes >= 11 && finishAfterFocus.activity.actualMinutes <= 13, 'Focus should freeze, not erase, the timer segment accumulated before it began');
  console.log('PASS  Focus/activity safeguard: starting Focus pauses the timer and prevents scoring during Focus');
  // A genuine short activity should not look like the point system ignored it.
  store.dgState.digitalAwareness.activeFocusSession = null;
  store.dgState.browsing.pointEvents = (store.dgState.browsing.pointEvents || []).filter(e => !(['objective','activity-timer','consistency-bonus'].includes(e.source) && sandbox.localDateKey(new Date(e.createdAt || 0)) === today));
  store.dgState.lifeGrowth.dailyTimedMinutesByType ||= {}; delete store.dgState.lifeGrowth.dailyTimedMinutesByType[`${today}:hobby`];
  const pointsBeforeShort = Number(store.dgState.plant.growthPoints) || 0;
  const shortStarted = await sendMessage({ type:'DG_ACTIVITY_START', activityType:'hobby', label:'Short creative practice' });
  assert.equal(shortStarted.ok,true);
  store.dgState.lifeGrowth.activeActivity.lastResumedAt = new Date(Date.now()-2*60000).toISOString();
  const shortFinished = await sendMessage({ type:'DG_ACTIVITY_FINISH' });
  assert.equal(shortFinished.ok,true);
  assert.ok(shortFinished.points>=1,'A completed two-minute activity should earn at least one visible point when budget remains');
  assert.equal(store.dgState.plant.growthPoints,pointsBeforeShort+shortFinished.points,'Activity points must update lifetime growth exactly once');
  assert.ok(store.dgState.browsing.pointEvents.some(e=>e.source==='activity-timer'&&e.label==='Short creative practice'&&e.points===shortFinished.points),'Every activity reward must have an inspectable ledger event');
  console.log('PASS  Short activity reward: two-minute effort earns a visible, one-time logged award');
  console.log('PASS  Routine schedule: selected weekdays, overnight boundaries, empty schedule and legacy compatibility');
  console.log('PASS  Cross-tab foreground tracking: previous-page attribution, productive-site carry and category-transition reset');

  // A completed hydration/outdoor break during strict Focus is logged, but must not move points or plant growth until the lock expires.
  store.dgState.digitalAwareness.activeFocusSession = { id:'focus-freeze-break-test', startedAt:new Date(Date.now()-1000).toISOString(), endsAt:new Date(Date.now()+25*60000).toISOString(), targetMinutes:50, strict:true, integrityLock:false, origin:'manual' };
  store.dgState.wellbeing ||= {}; store.dgState.wellbeing.pendingBreak = null; store.dgState.wellbeing.deferredGrowthRewards = [];
  const focusBreakStart = await sendMessage({type:'DG_BREAK_START', breakType:'hourly-water-outdoor'});
  assert.equal(focusBreakStart.ok,true);
  store.dgState.wellbeing.pendingBreak.startedAt = new Date(Date.now()-6*60000).toISOString();
  store.dgState.wellbeing.pendingBreak.idleSeconds = 180;
  store.dgState.wellbeing.pendingBreak.ready = true;
  const plantBeforeFocusedBreak = Number(store.dgState.plant.growthPoints)||0;
  const focusBreakConfirm = await sendMessage({type:'DG_BREAK_CONFIRM',breakId:focusBreakStart.pendingBreak.id});
  assert.equal(focusBreakConfirm.ok,true,`Qualified break should be recordable during Focus: ${JSON.stringify(focusBreakConfirm)}`);
  assert.equal(Number(store.dgState.plant.growthPoints)||0,plantBeforeFocusedBreak,'Strict Focus must freeze plant growth even if a break is completed');
  assert.equal(focusBreakConfirm.points,0,'Strict Focus must not award points while its timer is active');
  assert.equal(focusBreakConfirm.log.rewardPending,true,'The record should show points are deferred rather than lost');
  assert.equal(store.dgState.wellbeing.deferredGrowthRewards.length,1,'One deferred reward should be queued');
  assert.equal(store.dgState.lifeGrowth.objectiveCompletions?.[today]?.[`wellbeing-break-${focusBreakStart.pendingBreak.id}`],undefined,'No growth ledger entry may be created during Focus');
  store.dgState.digitalAwareness.activeFocusSession.endsAt = new Date(Date.now()-1000).toISOString();
  const focusEndedAfterBreak = await sendMessage({type:'DG_END_FOCUS'});
  assert.equal(focusEndedAfterBreak.ok,true);
  assert.equal(store.dgState.wellbeing.deferredGrowthRewards.length,0,'Deferred rewards should settle after Focus ends');
  const settledBreakLog = store.dgState.wellbeing.breakLog.find(item=>item.id===focusBreakStart.pendingBreak.id);
  assert.equal(settledBreakLog.rewardPending,false,'The break log should mark the reward as settled');
  assert.ok(Object.hasOwn(store.dgState.lifeGrowth.objectiveCompletions?.[today]||{},`wellbeing-break-${focusBreakStart.pendingBreak.id}`),'The deferred reward should be recorded in the normal activity ledger after Focus');
  assert.equal(Number(store.dgState.plant.growthPoints)||0,plantBeforeFocusedBreak+(Number(settledBreakLog.points)||0),'Growth must change only after Focus expires, by exactly the settled reward');
  console.log('PASS  Focus growth freeze: a completed wellbeing break is logged during Focus and rewarded only after lock expiry');

  // Admitting a false break confirmation must create a real sixty-minute strict session.
  store.dgState.digitalAwareness.activeFocusSession = null;
  const lieResult = await sendMessage({ type:'DG_BREAK_ADMIT_LIE' });
  assert.equal(lieResult.ok,true);
  assert.equal(lieResult.locked,true);
  assert.equal(lieResult.session.strict,true);
  assert.equal(lieResult.session.integrityLock,true);
  assert.ok(Date.parse(lieResult.session.endsAt)-Date.now()>=59*60000,'The integrity lock should last approximately one hour');
  const lieEarlyEnd = await sendMessage({ type:'DG_END_FOCUS' });
  assert.equal(lieEarlyEnd.ok,false,'The one-hour integrity lock must reject early exit');
  store.dgState.digitalAwareness.activeFocusSession.endsAt = new Date(Date.now()-1000).toISOString();
  assert.equal((await sendMessage({ type:'DG_END_FOCUS' })).ok,true,'The integrity lock must clear at expiry');
  console.log('PASS  Break integrity: admitted false confirmation starts a strict one-hour Focus lock that expires on schedule');

  // Navigation tests exercise the real background message handlers, not only source strings.
  const miniOpen = await sendMessage({ type: 'DG_OPEN_MINI_APP' });
  assert.equal(miniOpen.ok, true, `Widget mini-app navigation failed: ${JSON.stringify(miniOpen)}`);
  assert.equal(miniOpen.fallback, true, 'Simulated popup failure should use the dedicated mini-app tab fallback');
  assert(miniOpen.url.includes('/miniapp.html'), `Mini-app fallback opened the wrong page: ${miniOpen.url}`);
  assert(miniOpen.url.endsWith('#grow'), 'Mini-app fallback should open at Grow');
  const dashboardOpen = await sendMessage({ type: 'DG_OPEN_DASHBOARD', screen: 'coach' });
  assert.equal(dashboardOpen.ok, true, `Widget dashboard navigation failed: ${JSON.stringify(dashboardOpen)}`);
  assert(dashboardOpen.url.includes('/dashboard.html'), `Dashboard button opened the wrong page: ${dashboardOpen.url}`);
  assert(dashboardOpen.url.endsWith('#coach'), 'Dashboard should honour the requested screen');
  const dashboardReuse = await sendMessage({ type: 'DG_OPEN_DASHBOARD', screen: 'focus' });
  assert.equal(dashboardReuse.ok, true);
  assert.equal(dashboardReuse.reused, true, 'Second dashboard request should reuse the existing dashboard tab');
  assert(dashboardReuse.url.endsWith('#focus'), 'Reused dashboard tab should navigate to the requested screen');
  assert(updatedTabs.some(x => x.id === dashboardOpen.tabId), 'Existing dashboard tab should be activated and updated');
  console.log('PASS  Background AI lifecycle: guarded actions, persistent feedback memory, outcome-aware Focus, daily planning, retry safety, opt-in automatic Focus, strict allowlist and local category corrections');
  console.log('PASS  Widget navigation runtime: popup failure opens mini-app tab; dashboard route opens requested screen and reuses existing tab');

  // Regression: Think now invoked from a dashboard tab must use the originating webpage
  // carried in sourceTabId, instead of silently treating chrome-extension://dashboard.html
  // as unsupported context and claiming that the AI check completed.
  store.dgState.aiCompanion.enabled = true;
  store.dgState.aiCompanion.consentAt ||= new Date().toISOString();
  store.dgState.aiCompanion.fullContextConsentAt ||= new Date().toISOString();
  store.dgState.aiCompanion.fullContextConsentVersion = 2;
  store.dgState.aiCompanion.runs = [];
  store.dgState.aiCompanion.lastRunAt = null;
  store.dgState.aiCompanion.lastAttemptAt = null;
  store.dgState.aiCompanion.lastError = null;
  store.dgState.aiCompanion.lastStatus = 'ready';
  store.dgState.digitalAwareness.activeFocusSession = null;
  tabQueryOverride = [
    { id: 50, url: 'chrome-extension://test-extension-id/dashboard.html?sourceTabId=12#coach', active: true, windowId: 1, lastAccessed: Date.now() },
    { id: 12, url: 'https://school.example/study', active: false, windowId: 1, lastAccessed: Date.now() - 5000 }
  ];
  const dashboardLoop = await sendMessage(
    { type: 'DG_AGENT_RUN_NOW', sourceTabId: '12' },
    { url: 'chrome-extension://test-extension-id/dashboard.html?sourceTabId=12#coach', tab: { id: 50, url: 'chrome-extension://test-extension-id/dashboard.html?sourceTabId=12#coach', windowId: 1 } }
  );
  assert.equal(dashboardLoop.ok, true, `Think now from dashboard failed: ${JSON.stringify(dashboardLoop)}`);
  assert.ok(dashboardLoop.result?.decision, `Dashboard Think now must return a real decision, not a silent skip: ${JSON.stringify(dashboardLoop)}`);
  assert.equal(dashboardLoop.result.decision.trigger, 'manual');
  assert.equal(sentModelBody.snapshot.activity.currentPageKind, 'lesson', 'Dashboard AI request must use the originating normal webpage as context');
  tabQueryOverride = null;
  console.log('PASS  AI dashboard handoff: Think now called from extension dashboard resolves the originating HTTPS tab and saves a real decision');
})().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
