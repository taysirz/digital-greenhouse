const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const growth = require('../growth-engine.js');
function priorDaysBeforeTest(now) { const d=new Date(now); d.setHours(12,0,0,0); d.setDate(d.getDate()-1); const days=[]; for(let i=6;i>=0;i--){ const item=new Date(d); item.setDate(item.getDate()-i); days.push(growth.dayKey(item)); } return days; }

for (const page of ['popup.html','miniapp.html','dashboard.html']) {
  const source = fs.readFileSync(path.join(root,page),'utf8');
  const growthAt = source.indexOf('src="growth-engine.js"');
  const appAt = source.indexOf('src="popup.js"');
  assert.ok(growthAt >= 0 && appAt > growthAt, `${page} must load growth-engine.js before popup.js`);
  assert.match(source, /id="dailyObjectiveMode"/, `${page} must offer adaptive/custom objective modes`);
  assert.match(source, /id="customObjectiveEditor"/, `${page} must retain the ability to edit personal objectives`);
}

const now = new Date('2026-10-21T12:00:00');
const defaultState = {
  profile: { dailyObjectiveMode:'adaptive', goalNotes:'learn programming', dailyObjectives:[], routineBaseline:{ primaryType:'studying', minutesPerDay:20 } },
  lifeGrowth: { dailyTimedMinutesByType:{}, activityLog:[], objectiveCompletions:{} }
};
const tasks = growth.buildDailyObjectives(defaultState, now);
assert.equal(tasks.length, 3);
assert.equal(tasks[0].type, 'studying');
assert.equal(new Set(tasks.map(x=>x.type)).size, 3, 'adaptive objectives should cover distinct activity types');
assert.ok(tasks.every(x=>x.targetMinutes>=5 && x.targetMinutes<=60));
assert.deepEqual(growth.buildDailyObjectives({profile:{dailyObjectiveMode:'custom',dailyObjectives:['Read 15 pages','Walk outside for 10 minutes','Call my family']}},now).map(x=>x.type), ['reading','exercise','social']);
assert.equal(growth.inferActivityTypeFromText('Work on a Python programming exercise'),'coding');
assert.equal(growth.inferActivityTypeFromText('Make time for family'),'social');
assert.equal(growth.inferActivityTypeFromText('Do something important'),'custom');
assert.equal(growth.objectiveLabelForType('hydration',null),'Pause and have some water','one-shot habits should not be given fake time targets');
assert.equal(growth.objectiveLabelForType('exercise',15),'Move or get outside for 15 minutes');
const preservedDoneTask=growth.objectiveDisplayTask({key:'objective-1',type:'coding',label:'Practice coding for 10 minutes',targetMinutes:10,mode:'adaptive',icon:'💻'},{type:'reading',label:'Read 15 pages',targetMinutes:null,mode:'custom',points:5,completedAt:'2026-10-21T10:00:00.000Z'});
assert.equal(preservedDoneTask.label,'Read 15 pages','a completed slot keeps the label that the user actually completed even if settings change that day');
assert.equal(preservedDoneTask.type,'reading','a completed slot keeps its original category for accurate history');
const defaultObjectiveLabels=['Work toward your main goal for 20 minutes','Move your body or get outside','Make time for a hobby, reading, connection or rest'];
assert.equal(growth.resolveDailyObjectiveMode(undefined,defaultObjectiveLabels,defaultObjectiveLabels),'adaptive','legacy untouched defaults migrate to adaptive mode');
assert.equal(growth.resolveDailyObjectiveMode(undefined,['Read a chapter','Walk','Call family'],defaultObjectiveLabels),'custom','legacy user-authored objectives remain custom');
assert.equal(growth.resolveDailyObjectiveMode('custom',defaultObjectiveLabels,defaultObjectiveLabels),'custom','an explicit saved custom mode is preserved');
assert.equal(growth.resolveDailyObjectiveMode('adaptive',['Read','Walk','Call family'],defaultObjectiveLabels),'adaptive','an explicit saved adaptive mode is preserved');
assert.equal(growth.objectiveRewardBreakdown({}, {type:'studying',label:'Study',day:'2026-10-21'}).basePoints, 5);
const checkinProgressState={profile:{routineBaseline:{primaryType:'reading',minutesPerDay:10}},lifeGrowth:{dailyTimedMinutesByType:{},activityLog:[],objectiveCompletions:Object.fromEntries(priorDaysBeforeTest(now).slice(0,4).map(day=>[day,{'objective-1':{type:'reading',mode:'adaptive',targetMinutes:10}}]))}};
assert.equal(growth.adaptiveTargetMinutes(checkinProgressState,'reading',now,10).minutes,15,'four of seven adaptive objective check-ins count as personal success even without an offline timer');
const customNoDuration=growth.buildDailyObjectives({profile:{dailyObjectiveMode:'custom',dailyObjectives:['Read a chapter','Call a friend','Clean my desk']}},now);
assert.ok(customNoDuration.every(task=>task.targetMinutes===null),'free-form tasks without an explicit duration must not invent a time requirement');
const backgroundSource = fs.readFileSync(path.join(root,'background.js'),'utf8');
const popupSource = fs.readFileSync(path.join(root,'popup.js'),'utf8');
assert.match(backgroundSource, /DGGrowth\.resolveDailyObjectiveMode/, 'background state migration uses the tested common mode resolver');
assert.match(popupSource, /DGGrowth\.resolveDailyObjectiveMode/, 'popup fallback uses the tested common mode resolver');
assert.match(popupSource, /dirtySettingsGroups/, 'state refreshes must not clobber in-progress form edits');
for (const group of ['profile','protection','tracking','focus','collection','agent']) assert.ok(popupSource.includes(`dirtySettingsGroups.has('${group}')`), `rendering must preserve unsaved ${group} controls`);
assert.match(popupSource, /type:'DG_SAVE_PROFILE'/, 'profile edits must go through a background-side patch handler instead of a stale whole-state write');
assert.match(popupSource, /type:'DG_SAVE_TRACKING_SETTINGS'/, 'tracking settings must use a background-side patch handler');
assert.match(backgroundSource, /function shouldRefreshHealthFromDistractionPattern/, 'distraction-health updates must be pattern-based, not tied to one classification event');
assert.match(backgroundSource, /if \(shouldRefreshHealthFromDistractionPattern\(s, now\)\) recalculatePlantHealth/, 'the active-tab loop must refresh health after enough aggregated distraction evidence');
const prior = new Date(now); prior.setHours(12,0,0,0); prior.setDate(prior.getDate()-1); const priorDays=[]; for(let i=6;i>=0;i--){const d=new Date(prior);d.setDate(d.getDate()-i);priorDays.push(growth.dayKey(d));}
const adaptiveWithHistory={profile:{dailyObjectiveMode:'adaptive',dailyObjectives:[],routineBaseline:{primaryType:'exercise',minutesPerDay:10}},lifeGrowth:{dailyTimedMinutesByType:Object.fromEntries(priorDays.slice(0,4).map(day=>[`${day}:exercise`,10])),activityLog:[],objectiveCompletions:{}}};
assert.equal(growth.buildDailyObjectives(adaptiveWithHistory,now)[0].targetMinutes,15, 'successful history changes the actual generated objective by a gentle increment');

// A given day's plan must not shift as the user logs more activity today; it uses history through yesterday.
const stableBefore = growth.buildDailyObjectives(defaultState, new Date('2026-10-21T08:00:00'));
const changedToday = JSON.parse(JSON.stringify(defaultState));
changedToday.lifeGrowth.dailyTimedMinutesByType['2026-10-21:studying'] = 180;
const stableAfter = growth.buildDailyObjectives(changedToday, new Date('2026-10-21T18:00:00'));
assert.deepEqual(stableAfter.map(t=>[t.key,t.type,t.label,t.targetMinutes]), stableBefore.map(t=>[t.key,t.type,t.label,t.targetMinutes]));

console.log('PASS  Non-AI foundation: adaptive priorities, custom-category mapping, five-point objectives, stable daily plan, all three UI entry points load the same growth engine');
