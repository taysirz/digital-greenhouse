const assert = require('node:assert/strict');
const growth = require('../growth-engine.js');
function progressAt(seconds, stage=0, stopped=false, time=1000) { return { domain:'feed.example', seconds, warningStage:stage, stopped, lastSignalAt:time }; }
// Completed activity timers must show a point reward for a genuine two-minute effort, while 1-minute taps earn none.
assert.equal(growth.progressiveActivityPoints(1), 0);
assert.equal(growth.progressiveActivityPoints(2), 1);
assert.equal(growth.progressiveActivityPoints(4), 1);
assert.equal(growth.progressiveActivityPoints(5), 1);
let r = growth.advanceScrollIntervention(null, {domain:'feed.example', deltaSeconds:20, now:1000, active:true});
assert.equal(r.progress.seconds,20); assert.equal(r.stop,false);
r = growth.advanceScrollIntervention(progressAt(285,0,false,1000), {domain:'feed.example', deltaSeconds:20, now:2000, active:true});
assert.deepEqual(r.warnings.map(x=>x.minutes),[5]); assert.equal(r.stop,false);
r = growth.advanceScrollIntervention(progressAt(405,1,false,1000), {domain:'feed.example', deltaSeconds:20, now:2000, active:true});
assert.deepEqual(r.warnings.map(x=>x.minutes),[7]);
r = growth.advanceScrollIntervention(progressAt(525,2,false,1000), {domain:'feed.example', deltaSeconds:20, now:2000, active:true});
assert.deepEqual(r.warnings.map(x=>x.minutes),[9]);
r = growth.advanceScrollIntervention(progressAt(595,3,false,1000), {domain:'feed.example', deltaSeconds:20, now:2000, active:true});
assert.equal(r.stop,true); assert.equal(r.progress.stopped,true); assert.equal(r.progress.seconds,600);
r = growth.advanceScrollIntervention(r.progress, {domain:'feed.example', deltaSeconds:15, now:17000, active:true});
assert.equal(r.stop,false); // already stopped: do not re-trigger the stop action on subsequent signals.
r = growth.advanceScrollIntervention(progressAt(150,0,false,1000), {domain:'feed.example', deltaSeconds:15, now:70000, active:true});
assert.equal(r.progress.seconds,15); assert.deepEqual(r.warnings,[]); // a long pause means a new scrolling session
r = growth.advanceScrollIntervention(progressAt(150,0,false,1000), {domain:'feed.example', active:false, now:2000});
assert.equal(r.progress.seconds,0); assert.equal(r.progress.warningStage,0);
// Automatic point curve is responsive for short sessions, diminishing, capped at 20 points/day, and gives nothing to uncertain/neutral pages.
assert.equal(growth.browserPointsAt(30),5); assert.equal(growth.browserPointsAt(60),10); assert.equal(growth.browserPointsAt(120),16); assert.equal(growth.browserPointsAt(240),20); assert.equal(growth.browserPointsAt(360),20); assert.equal(growth.browserPointsAt(1000),20);
const baseState={plant:{growthPoints:0},browsing:{pointEvents:[],dailyMinutesByCategory:{},dailyEffectiveProductiveMinutes:{},dailyNetPoints:{},dailyBrowserPoints:{},dailyContextTypes:{},dailyProgressBonusDates:{},dailyGoalBonusDates:{},dailyVarietyBonusCount:{}}};
let scored=growth.scoreBrowserInterval(baseState,{category:'productive',domain:'study.example',minutes:5,confidence:0.3,pageKind:'lesson',topicHints:['learning'],now:new Date('2026-10-20T12:00:00')});
assert.equal(scored.points,0); assert.equal(scored.effectiveMinutes,0); assert.equal(baseState.plant.growthPoints,0);
scored=growth.scoreBrowserInterval(baseState,{category:'productive',domain:'study.example',minutes:5,confidence:0.9,pageKind:'lesson',topicHints:['learning'],correction:true,now:new Date('2026-10-20T12:05:00')});
assert.ok(scored.effectiveMinutes>0); assert.ok(scored.points>=0); assert.ok(scored.breakdown.dailyCap===growth.MAX_BROWSER_POINTS_PER_DAY);
const correctionOnlyState={plant:{growthPoints:0},browsing:{pointEvents:[],dailyMinutesByCategory:{},dailyEffectiveProductiveMinutes:{},dailyNetPoints:{},dailyBrowserPoints:{},dailyContextTypes:{},dailyProgressBonusDates:{},dailyGoalBonusDates:{},dailyVarietyBonusCount:{}}};
scored=growth.scoreBrowserInterval(correctionOnlyState,{category:'productive',domain:'mislabelled.example',minutes:5,confidence:0.3,pageKind:'social_feed',topicHints:['social'],correction:true,now:new Date('2026-10-20T12:10:00')});
assert.equal(scored.effectiveMinutes,0,'A manual correction must not boost low-confidence activity into productive points');
assert.equal(scored.points,0,'A manual correction alone must not award growth points');
// Date helpers must not mutate caller-owned Date objects; this matters to rolling 7-day
// scoring, baselines, plant health and local-day bookkeeping.
const immutableNow = new Date('2026-10-21T12:00:00');
assert.deepEqual(growth.recentDayKeys(immutableNow, 7), ['2026-10-15','2026-10-16','2026-10-17','2026-10-18','2026-10-19','2026-10-20','2026-10-21']);
assert.equal(immutableNow.toISOString(), '2026-10-21T12:00:00.000Z', 'date-window calculation must not mutate its input');

// Plant-health tests: no data should not cause silent decay; recovery activities count;
// persistent distraction can lower the awareness pillar without removing growth points.
const healthNow = new Date('2026-10-21T12:00:00');
assert.equal(growth.calculatePlantHealth({}, healthNow), 70, 'empty/new profile stays at a neutral health baseline');
const healthDay = growth.dayKey(healthNow);
const productiveState = {
  browsing: {
    dailyMinutesByCategory: { [`${healthDay}:productive`]: 120 },
    dailyContextTypes: { [healthDay]: ['learning', 'coding', 'reading'] },
  },
  lifeGrowth: {
    dailyTimedMinutes: { [healthDay]: 90 },
    dailyTimedMinutesByType: { [`${healthDay}:studying`]: 45, [`${healthDay}:exercise`]: 45 },
    objectiveCompletions: { [healthDay]: { a: { type: 'studying' }, b: { type: 'exercise' } } },
  },
  digitalProtection: { adBlockEnabled: true, adultSiteBlockingEnabled: true, distractionGuardEnabled: true },
};
assert.ok(growth.calculatePlantHealth(productiveState, healthNow) > 70, 'evidence of balanced productive activity should raise health target');
const recoveryState = {
  lifeGrowth: { dailyTimedMinutes: { [healthDay]: 45 }, dailyTimedMinutesByType: { [`${healthDay}:rest`]: 25, [`${healthDay}:social`]: 20 } },
  digitalProtection: { adBlockEnabled: true, adultSiteBlockingEnabled: true, distractionGuardEnabled: true },
};
assert.ok(growth.calculatePlantHealth(recoveryState, healthNow) >= 70, 'rest and social connection should not be treated as failure');
const distractionState = {
  browsing: { dailyMinutesByCategory: { [`${healthDay}:distracting`]: 120 } },
  digitalProtection: { adBlockEnabled: true, adultSiteBlockingEnabled: true, distractionGuardEnabled: true },
  plant: { growthPoints: 250 },
};
assert.ok(growth.calculatePlantHealth(distractionState, healthNow) < 70, 'sustained distracting use may lower the awareness pillar');
const briefDistractionState = { browsing:{dailyMinutesByCategory:{ [`${healthDay}:distracting`]:15}}, digitalProtection:{adBlockEnabled:true,adultSiteBlockingEnabled:true,distractionGuardEnabled:true} };
assert.equal(growth.calculatePlantHealth(briefDistractionState, healthNow),70, 'one short distraction session must remain neutral for plant health');
const repeatedDistractionState = { browsing:{dailyMinutesByCategory:Object.fromEntries([healthDay,...growth.recentDayKeys(new Date(healthNow.getTime()-86400000),2)].map(day=>[`${day}:distracting`,30]))}, digitalProtection:{adBlockEnabled:true,adultSiteBlockingEnabled:true,distractionGuardEnabled:true} };
assert.ok(growth.calculatePlantHealth(repeatedDistractionState, healthNow)<70, 'a repeated distraction pattern across multiple days can gradually affect the awareness pillar');
assert.equal(distractionState.plant.growthPoints, 250, 'plant-health evaluation must not erase lifetime growth points');
const scoreDay = growth.dayKey(healthNow);
const unknownBaselineState = { profile: { routineBaseline: { primaryType: 'exercise', minutesPerDay: null } }, lifeGrowth: { dailyTimedMinutesByType: {}, progressBonusDates: {}, goalBonusDates: {}, dailyVarietyBonusCount: {} } };
const zeroBaselineState = { profile: { routineBaseline: { primaryType: 'exercise', minutesPerDay: 0 } }, lifeGrowth: { dailyTimedMinutesByType: {}, progressBonusDates: {}, goalBonusDates: {}, dailyVarietyBonusCount: {} } };
assert.equal(growth.priorDailyTypeBaseline(unknownBaselineState, 'exercise', healthNow), null, 'an unknown baseline stays unknown');
assert.equal(growth.priorDailyTypeBaseline(zeroBaselineState, 'exercise', healthNow), 0, 'an explicit zero baseline remains a known zero');
const structuredBaselineState = { profile: { routineBaseline: { studyMinutesPerDay: 45, readingMinutesPerDay: 20, exerciseDaysPerWeek: 3, sleepSchedule: { bedtime: '22:30', wakeTime: '06:30' }, primaryType: '', minutesPerDay: null } }, lifeGrowth: { dailyTimedMinutesByType: {} } };
assert.equal(growth.configuredRoutineBaseline(structuredBaselineState, 'studying'), 45, 'study activity should use the explicit study baseline');
assert.equal(growth.configuredRoutineBaseline(structuredBaselineState, 'reading'), 20, 'reading activity should use the explicit reading baseline');
assert.equal(growth.configuredRoutineBaseline(structuredBaselineState, 'exercise'), null, 'weekly exercise frequency must not be misinterpreted as minutes');
const weeklyExerciseState = { profile: { routineBaseline: { exerciseDaysPerWeek: 1 } }, lifeGrowth: { dailyTimedMinutesByType: { '2026-10-19:exercise': 25 }, objectiveCompletions: {}, activityLog: [], weeklyProgressBonusDates: {} } };
assert.equal(growth.weeklyConsistencyBonus(weeklyExerciseState, 'exercise', '2026-10-21'), 2, 'a distinct exercise day above a known one-day weekly baseline receives a consistency bonus');
assert.equal(growth.weeklyConsistencyBonus(weeklyExerciseState, 'exercise', '2026-10-19'), 0, 'the reward must not be earned before the weekly baseline is exceeded');
const highTargetExerciseState = { profile: { routineBaseline: { exerciseDaysPerWeek: 3 } }, lifeGrowth: { dailyTimedMinutesByType: { '2026-10-19:exercise': 25 }, objectiveCompletions: {}, activityLog: [], weeklyProgressBonusDates: {} } };
assert.equal(growth.weeklyConsistencyBonus(highTargetExerciseState, 'exercise', '2026-10-21'), 0, 'an exercise day within the stated weekly baseline should not receive an above-baseline bonus');
assert.equal(growth.objectiveRewardBreakdown(weeklyExerciseState, { type:'exercise', label:'Move body', day:'2026-10-21' }).weeklyConsistencyBonus, 2, 'the three daily objectives participate in the same weekly routine model');
const cappedExerciseBonusState = { ...weeklyExerciseState, lifeGrowth: { ...weeklyExerciseState.lifeGrowth, weeklyProgressBonusDates: { '2026-10-19:exercise': true, '2026-10-20:exercise': true } } };
assert.equal(growth.weeklyConsistencyBonus(cappedExerciseBonusState, 'exercise', '2026-10-21'), 0, 'weekly consistency bonuses are limited to two in one Monday-to-Sunday week');
const unknownBreakdown = growth.activityRewardBreakdown(unknownBaselineState, { type: 'exercise', priorTypeMinutes: 0, newTypeMinutes: 20, now: healthNow, day: scoreDay });
const zeroBreakdown = growth.activityRewardBreakdown(zeroBaselineState, { type: 'exercise', priorTypeMinutes: 0, newTypeMinutes: 20, now: healthNow, day: scoreDay });
assert.equal(unknownBreakdown.progressThresholdMinutes, 30, 'unknown baseline uses a conservative default threshold');
assert.equal(unknownBreakdown.progressBonus, 0, 'unknown short activity is not misclassified as improvement over zero');
assert.equal(zeroBreakdown.progressThresholdMinutes, 10, 'known zero baseline recognises a ten-minute improvement');
assert.equal(zeroBreakdown.progressBonus, 2, 'real improvement above a known-zero baseline receives the stronger bonus');
const tinySession = growth.activityRewardBreakdown({
  profile: { goalNotes: 'Exercise every day', routineBaseline: { primaryType: 'exercise', minutesPerDay: 0 } },
  lifeGrowth: { dailyTimedMinutesByType: {}, progressBonusDates: {}, goalBonusDates: {}, dailyVarietyBonusCount: {} },
}, { type: 'exercise', label: 'Exercise', priorTypeMinutes: 0, newTypeMinutes: 1, now: healthNow, day: scoreDay });
assert.equal(tinySession.basePoints, 0, 'a one-minute timer earns no base effort point');
assert.equal(tinySession.goalBonus, 0, 'a one-minute timer cannot farm a goal bonus');
assert.equal(tinySession.varietyBonus, 0, 'a one-minute timer cannot farm a novelty bonus');
const zeroDurationExercise = growth.activityRewardBreakdown({ profile: { routineBaseline: { exerciseDaysPerWeek: 0 } }, lifeGrowth: { dailyTimedMinutesByType: {}, weeklyProgressBonusDates: {} } }, { type:'exercise', priorTypeMinutes:0, newTypeMinutes:0, now:healthNow, day:scoreDay });
assert.equal(zeroDurationExercise.weeklyConsistencyBonus, 0, 'zero-minute exercise timers cannot farm weekly consistency bonuses');
// Optional exercise measurements: labels keep unlike activities separate, first value establishes
// a benchmark, and only meaningful personal improvement can earn a one-time bonus.
const pushupKey = growth.metricKey('exercise', '  Push-ups!  ', 'reps');
assert.equal(pushupKey, 'exercise:push-ups:reps');
assert.equal(growth.metricKey('reading', 'Push-ups', 'reps'), '', 'measurement bonuses apply only to supported exercise metrics');
assert.equal(growth.metricKey('exercise', 'Push-ups', 'pages'), '', 'unsupported units must be rejected');
assert.equal(growth.metricKey('exercise', '', 'reps'), '', 'an activity needs a consistent label to form a metric');
const metricNow = new Date('2026-10-21T12:00:00Z');
const metricHistory = { lifeGrowth: { activityLog: [
  { type:'exercise', label:'Push-ups', metricKey:pushupKey, quantityValue:100, quantityUnit:'reps', endedAt:'2026-10-20T12:00:00Z' },
] } };
const metricArgs = { type:'exercise', label:'Push-ups', quantityUnit:'reps', metric:pushupKey, day:'2026-10-21', now:metricNow };
assert.equal(growth.metricProgressBonus(metricHistory, { ...metricArgs, quantityValue:100 }), 0, 'repeating a matching result earns no progress bonus');
assert.equal(growth.metricProgressBonus(metricHistory, { ...metricArgs, quantityValue:104 }), 0, 'tiny changes below five percent are not rewarded');
assert.equal(growth.metricProgressBonus(metricHistory, { ...metricArgs, quantityValue:115 }), 3, 'a 15% personal improvement earns a moderate bonus');
assert.equal(growth.metricProgressBonus(metricHistory, { ...metricArgs, quantityValue:120 }), 5, 'a 20% personal improvement earns the bounded top bonus');
assert.equal(growth.metricProgressBonus({}, { ...metricArgs, quantityValue:20 }), 1, 'the first measured exercise establishes the benchmark with a small calibration bonus');
const metricLedgerState = { ...metricHistory, lifeGrowth: { ...metricHistory.lifeGrowth, metricBonusDates: { '2026-10-21:exercise:push-ups:reps': true } } };
assert.equal(growth.metricProgressBonus(metricLedgerState, { ...metricArgs, quantityValue:120 }), 0, 'the same metric cannot earn multiple bonuses on the same day');
assert.equal(growth.metricQuantityPoints(100, 'reps'), 10, '100 measured repetitions should contribute meaningful effort points');
assert.equal(growth.metricQuantityPoints(100000, 'reps'), 12, 'measured effort points have a hard ceiling');
assert.equal(growth.metricQuantityPoints(100, 'pages'), 0, 'unsupported measurements must never generate effort points');
const firstMetricBreakdown = growth.activityRewardBreakdown({ lifeGrowth:{activityLog:[], dailyTimedMinutesByType:{}, progressBonusDates:{}, goalBonusDates:{}, dailyVarietyBonusCount:{}} }, { type:'exercise', label:'Push-ups', priorTypeMinutes:0, newTypeMinutes:20, quantityValue:100, quantityUnit:'reps', metric:pushupKey, now:metricNow, day:'2026-10-21' });
assert.equal(firstMetricBreakdown.metricEffortPoints, 10, 'measured output, not only time, should influence the base reward');
assert.equal(firstMetricBreakdown.basePoints, 10, 'use the stronger of duration or measured output to avoid double-counting');
assert.equal(firstMetricBreakdown.metricProgressBonus, 1);
const unlabeledMetricBreakdown = growth.activityRewardBreakdown({ lifeGrowth:{activityLog:[], dailyTimedMinutesByType:{}, progressBonusDates:{}, goalBonusDates:{}, dailyVarietyBonusCount:{}} }, { type:'exercise', label:'Exercise', priorTypeMinutes:0, newTypeMinutes:20, quantityValue:null, quantityUnit:'', now:metricNow, day:'2026-10-21' });
assert.equal(unlabeledMetricBreakdown.metricKey, null, 'Default exercise labels must not create a personal metric without a consistent user label');
assert.equal(unlabeledMetricBreakdown.metricProgressBonus, 0, 'An unlabeled exercise metric must not earn a measurement bonus');
assert.equal(firstMetricBreakdown.rawPoints, firstMetricBreakdown.basePoints + firstMetricBreakdown.progressBonus + firstMetricBreakdown.goalBonus + firstMetricBreakdown.varietyBonus + firstMetricBreakdown.weeklyConsistencyBonus + 1, 'the measurable progress bonus participates in the same bounded award breakdown');
const improvedMetricBreakdown = growth.activityRewardBreakdown(metricHistory, { type:'exercise', label:'Push-ups', priorTypeMinutes:0, newTypeMinutes:20, quantityValue:115, quantityUnit:'reps', metric:pushupKey, now:metricNow, day:'2026-10-21' });
assert.equal(improvedMetricBreakdown.metricProgressBonus, 3);
const sameDayMetricRepeat = growth.activityRewardBreakdown({ lifeGrowth:{activityLog:[{ metricKey:pushupKey, quantityValue:100, quantityUnit:'reps', endedAt:'2026-10-21T09:00:00Z' }], dailyTimedMinutesByType:{}, progressBonusDates:{}, goalBonusDates:{}, dailyVarietyBonusCount:{}, metricBonusDates:{'2026-10-21:exercise:push-ups:reps':true} } }, { type:'exercise', label:'Push-ups', priorTypeMinutes:20, newTypeMinutes:40, quantityValue:100, quantityUnit:'reps', metric:pushupKey, now:metricNow, day:'2026-10-21' });
assert.equal(sameDayMetricRepeat.metricEffortPoints, 0, 'repeating the same measurement on the same day cannot farm the metric base');
assert.equal(sameDayMetricRepeat.metricProgressBonus, 0, 'a same-day repeat cannot farm personal-progress bonuses');
assert.equal(sameDayMetricRepeat.basePoints, sameDayMetricRepeat.timeBasePoints, 'a legitimate repeated session may still earn incremental duration points');

// The deterministic routine step must distinguish an unknown baseline from a stated zero,
// and only suggest increasing a target after repeated evidence that the current target is met.
const noRoutine = growth.suggestNextRoutineStep({ profile: { routineBaseline: {} } }, new Date('2026-10-21T12:00:00'));
assert.equal(noRoutine.ready, false, 'no routine data should prompt setup rather than assume zero');
assert.equal(noRoutine.reason, 'choose-priority');
const unknownRoutine = growth.suggestNextRoutineStep({ profile: { routineBaseline: { primaryType: 'studying', minutesPerDay: null } } }, new Date('2026-10-21T12:00:00'));
assert.equal(unknownRoutine.reason, 'baseline-unknown', 'unknown is not silently treated as zero');
const routineNow = new Date('2026-10-21T12:00:00');
const routineDays = growth.recentDayKeys(routineNow, 7);
const steadyRoutineState = { profile: { routineBaseline: { primaryType: 'studying', minutesPerDay: 20 } }, lifeGrowth: { dailyTimedMinutesByType: Object.fromEntries(routineDays.slice(0,4).map(day => [`${day}:studying`, 20])), activityLog: [] } };
const steadySuggestion = growth.suggestNextRoutineStep(steadyRoutineState, routineNow);
assert.equal(steadySuggestion.ready, true);
assert.equal(steadySuggestion.suggestedMinutes, 25, 'four successful days allow only a small 5-minute increase');
assert.equal(steadySuggestion.readyToIncrease, true);
const strugglingRoutineState = { profile: { routineBaseline: { primaryType: 'studying', minutesPerDay: 20 } }, lifeGrowth: { dailyTimedMinutesByType: { [`${routineDays[0]}:studying`]: 10 }, activityLog: [] } };
const holdSuggestion = growth.suggestNextRoutineStep(strugglingRoutineState, routineNow);
assert.equal(holdSuggestion.suggestedMinutes, 20, 'a difficult week maintains the target instead of escalating pressure');
assert.equal(holdSuggestion.readyToIncrease, false);
const zeroRoutine = growth.suggestNextRoutineStep({ profile: { routineBaseline: { primaryType: 'reading', minutesPerDay: 0 } }, lifeGrowth: { dailyTimedMinutesByType: {}, activityLog: [] } }, routineNow);
assert.equal(zeroRoutine.suggestedMinutes, 5, 'an explicit zero gets a manageable first step, not an aggressive target');


// Objective engine: rule-based personalization, safe category mapping, gradual targets,
// and the intended five-point base award for each of the three daily objectives.
const defaultObjectiveState = { profile: { dailyObjectiveMode:'adaptive', goalNotes:'learn programming', dailyObjectives:[], routineBaseline:{ primaryType:'studying', minutesPerDay:20 } }, lifeGrowth:{ dailyTimedMinutesByType:{}, activityLog:[], objectiveCompletions:{} } };
const generatedObjectives = growth.buildDailyObjectives(defaultObjectiveState, routineNow);
assert.equal(generatedObjectives.length, 3, 'the local planner always produces exactly three objectives');
assert.equal(generatedObjectives[0].type, 'studying', 'the selected routine priority drives the main task');
assert.ok(generatedObjectives.every(task => task.targetMinutes >= 5 && task.targetMinutes <= 60), 'all adaptive targets stay inside a manageable range');
assert.equal(new Set(generatedObjectives.map(task => task.type)).size, 3, 'daily objectives cover three different activity types');
assert.equal(growth.inferActivityTypeFromText('Read 15 pages of a novel'), 'reading', 'custom objective text maps to its real category');
assert.equal(growth.inferActivityTypeFromText('Spend time with my family'), 'social', 'relationship goals are not mislabeled by their slot');
assert.equal(growth.inferActivityTypeFromText('Something personal'), 'custom', 'ambiguous custom tasks stay neutral');
const objectiveTargetState = { profile:{ routineBaseline:{ primaryType:'exercise', minutesPerDay:10 } }, lifeGrowth:{ dailyTimedMinutesByType:Object.fromEntries(priorDaysBeforeTest(routineNow).slice(0,4).map(day=>[`${day}:exercise`,10])), activityLog:[] } };
function priorDaysBeforeTest(now){ const d=new Date(now); d.setHours(12,0,0,0);d.setDate(d.getDate()-1);const a=[];for(let i=6;i>=0;i--){const x=new Date(d);x.setDate(x.getDate()-i);a.push(growth.dayKey(x));}return a; }
const raisedTarget = growth.adaptiveTargetMinutes(objectiveTargetState,'exercise',routineNow,10);
assert.equal(raisedTarget.minutes,15, 'targets rise by a small increment only after success on at least four of the prior seven days');
const customObjectiveState = { profile:{ dailyObjectiveMode:'custom', dailyObjectives:['Read a chapter','Walk outside for 10 minutes','Call a friend'] } };
const customTasks = growth.buildDailyObjectives(customObjectiveState,routineNow);
assert.deepEqual(customTasks.map(task=>task.type),['reading','exercise','social'], 'custom priorities use their written meaning rather than hard-coded slot categories');
assert.equal(growth.objectiveRewardBreakdown({}, { type:'studying',label:'Study',day:'2026-10-21' }).basePoints,5, 'each daily objective has a five-point base reward before the shared budget cap');

const safeguardsOff = growth.calculatePlantHealth({ digitalProtection: { adBlockEnabled: false, adultSiteBlockingEnabled: false, distractionGuardEnabled: false } }, healthNow);
assert.ok(safeguardsOff < 70, 'turning off chosen safeguards lowers the protection pillar');

console.log('PASS  Growth engine: active-scroll 5/7/9/10-minute ladder, reset rules, diminishing rewards, low-confidence exclusion, daily cap and non-punitive plant-health model');
