'use strict';
const assert = require('node:assert/strict');
const { normalizeDomains, isDnsName } = require('../domain-utils.js');

assert.deepEqual(normalizeDomains('https://www.example.com/path?q=1\n*.sub.example.org\nexample.com\n..evil.com\n-start.example\nend-.example\nempty..example\nnot-a-domain\nhttps://good.example:8443/#top\nUPPER.Example'), [
  'www.example.com', 'sub.example.org', 'example.com', 'good.example', 'upper.example'
]);
assert.equal(isDnsName('foo.bar.co.uk'), true);
assert.equal(isDnsName('xn--bcher-kva.example'), true);
assert.equal(isDnsName('bad..example'), false);
assert.equal(isDnsName('-bad.example'), false);
assert.equal(isDnsName('bad-.example'), false);
assert.equal(isDnsName(`${'a'.repeat(64)}.example`), false);
assert.equal(isDnsName(`${'x'.repeat(254)}.com`), false);
assert.equal(normalizeDomains('good.example\n..bad..example\nanother.example').length, 2);
assert.equal(normalizeDomains(Array.from({length:300},(_,i)=>`site${i}.example`)).length, 250);
console.log('PASS  Shared domain utility accepts pasted URLs, validates DNS labels, deduplicates and caps custom lists');
