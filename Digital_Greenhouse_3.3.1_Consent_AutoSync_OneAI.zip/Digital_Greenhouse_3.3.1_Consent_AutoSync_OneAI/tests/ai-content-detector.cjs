const assert = require('node:assert/strict');
require('../ai-content-detector.js');
const detector = globalThis.DGLocalAiDisclosureDetector;
assert.ok(detector && typeof detector.detectExplicitAiDisclosure === 'function' && typeof detector.findExplicitAiDisclosures === 'function');
function node({text='', attrs={}, className='', id='', hidden=false, insideExcluded=false}={}) {
  return {
    innerText: text, textContent: text, className, id, hidden,
    getAttribute(name) { return attrs[name] ?? null; },
    hasAttribute(name) { return Object.prototype.hasOwnProperty.call(attrs, name); },
    getClientRects() { return hidden ? [] : [{}]; },
    closest() { return insideExcluded ? {} : null; }
  };
}
function doc(nodes) {
  return { querySelectorAll(selector) { return nodes.filter(n => {
    if (selector.includes('data-ai-generated') || selector.includes('data-ai-content') || selector.includes('data-generated-by') || selector.includes('data-content-origin') || selector.includes('ai-generated')) return true;
    return /span|small|strong|em|figcaption|role="img"|badge|label/.test(selector);
  }); } };
}
const structuredDisclosure = node({attrs:{'data-ai-generated':'true'}});
assert.equal(detector.detectExplicitAiDisclosure(doc([structuredDisclosure])), true, 'Explicit structured disclosure should be detected');
assert.equal(detector.findExplicitAiDisclosures(doc([structuredDisclosure])).length, 1, 'Replacement path should return the exact disclosed node, not only a boolean');
assert.equal(detector.detectExplicitAiDisclosure(doc([node({attrs:{'data-ai-content':'true'}})])), true, 'Explicit AI content metadata should be detected');
assert.equal(detector.detectExplicitAiDisclosure(doc([node({attrs:{'data-ai-generated':'false'}})])), false, 'An explicit false marker must not trigger');
assert.equal(detector.detectExplicitAiDisclosure(doc([node({text:'AI-generated image'})])), true, 'Exact visible disclosure label should be detected');
assert.equal(detector.detectExplicitAiDisclosure(doc([node({text:'This article explains how AI-generated content is made.'})])), false, 'Generic discussion of AI must not trigger a replacement');
assert.equal(detector.findExplicitAiDisclosures(doc([node({text:'This article explains how AI-generated content is made.'})])).length, 0, 'No replacement targets should be returned for generic AI discussion');
assert.equal(detector.detectExplicitAiDisclosure(doc([node({text:'AI-generated', insideExcluded:true})])), false, 'Chat/message areas must be excluded');
assert.equal(detector.detectExplicitAiDisclosure(doc([node({text:'AI-generated', hidden:true})])), false, 'Hidden disclosure elements must be excluded');
assert.equal(detector.detectExplicitAiDisclosure(doc([])), false, 'Pages without an explicit disclosure must remain unchanged');
console.log('PASS  Conservative AI-content detector: explicit disclosures only, excludes generic discussion, hidden content and chat/message areas');
