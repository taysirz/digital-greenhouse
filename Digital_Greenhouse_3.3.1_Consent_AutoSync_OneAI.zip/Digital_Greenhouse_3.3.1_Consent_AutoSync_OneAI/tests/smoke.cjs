'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const vm = require('node:vm');
const { spawn, execFileSync } = require('node:child_process');
const net = require('node:net');

const ROOT = path.resolve(__dirname, '..');
const report = [];
function pass(name) { report.push(`PASS  ${name}`); console.log(`PASS  ${name}`); }
function fail(name, error) { console.error(`FAIL  ${name}\n      ${error?.stack || error}`); process.exitCode = 1; }
function listJs(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === '.git') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) listJs(full, out);
    else if (entry.isFile() && (entry.name.endsWith('.js') || entry.name.endsWith('.cjs'))) out.push(full);
  }
  return out;
}
function runStaticChecks() {
  const jsFiles = listJs(ROOT);
  for (const file of jsFiles) execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' });
  pass(`JavaScript syntax: ${jsFiles.length} files`);

  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
  function bgPlaceholderLocalEndpointFetch() {
    const backgroundSource = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
    return /fetch\(\s*['\"]http:\/\/127\.0\.0\.1:8787\/v1\//.test(backgroundSource) ||
      /fetch\(\s*['\"]http:\/\/localhost:8787\/v1\//.test(backgroundSource);
  }
  assert.equal(manifest.manifest_version, 3);
  for (const f of ['server/START-BACKEND-HIDDEN.vbs','server/INSTALL-AUTOSTART.cmd','server/Install-Autostart.ps1','server/REMOVE-AUTOSTART.cmd','server/Remove-Autostart.ps1','server/check-local-mode.cjs']) assert(fs.existsSync(path.join(ROOT, f)), `Missing optional AI autostart file: ${f}`);
  pass('Optional Windows sign-in backend launcher and uninstall scripts are present');
  assert(fs.readFileSync(path.join(ROOT,'server/START-BACKEND-HIDDEN.vbs'),'utf8').includes('node check-local-mode.cjs') && fs.readFileSync(path.join(ROOT,'server/START-BACKEND.cmd'),'utf8').includes('node check-local-mode.cjs'), 'Personal launchers must refuse public/non-loopback config');
  assert.equal(manifest.version, '3.3.1');
  const aiClient = fs.readFileSync(path.join(ROOT, 'ai-client.js'), 'utf8');
  assert(aiClient.includes('function cleanEndpoint') && aiClient.includes('Authorization') && aiClient.includes('serviceAccessToken'), 'Shared AI client must validate endpoints and attach the private user token as an authorization header');
  assert(!bgPlaceholderLocalEndpointFetch(), 'AI feature requests must not remain hard-coded to localhost');
  for (const name of ['popup.html','dashboard.html','miniapp.html']) {
    const ui = fs.readFileSync(path.join(ROOT, name), 'utf8');
    assert(ui.includes('id=\"sharingConsent\"') && ui.includes('id=\"testAI\"') && ui.includes('ai-client.js') && ui.includes('service-config.js'), `${name} must include the unified sharing consent, publisher-configured endpoint, and real AI test`);
    assert(ui.includes('starts syncing automatically') && !ui.includes('id=\"testServiceConnection\"') && !ui.includes('id=\"collectionEndpoint\"') && !ui.includes('id=\"serviceAccessToken\"') && !ui.includes('id=\"syncDataNow\"'), `${name} must not require ordinary users to configure a URL/token or manually start uploads`);
  }
  const publicEnv = fs.readFileSync(path.join(ROOT, 'server/.env.public.example'), 'utf8');
  assert(publicEnv.includes('DG_PUBLIC_MODE=true') && publicEnv.includes('DG_TOKEN_SECRET=REPLACE_') && publicEnv.includes('AI_PROVIDER=cloud'), 'Public environment template must require a signing secret and hosted model provider');
  assert(fs.existsSync(path.join(ROOT, 'server/issue-access-token.cjs')) && fs.readFileSync(path.join(ROOT, 'server/server.js'), 'utf8').includes('verifyPublicAccessToken') && fs.readFileSync(path.join(ROOT, 'server/server.js'), 'utf8').includes('consumePublicQuota'), 'Public mode must include signed-token validation and request limits');
  const envExample = fs.readFileSync(path.join(ROOT, 'server/.env.example'), 'utf8');
  assert.match(envExample, /^AI_PROVIDER=hybrid$/m, 'The integrated release must ship the hybrid router template');
  assert.match(envExample, /^AI_CLOUD_FALLBACK_ENABLED=false$/m, 'Cloud must remain disabled in the safe default config');
  assert(!fs.existsSync(path.join(ROOT, 'server/.env')), 'The release tree must never ship a private server/.env file');
  const filterUpdaterSource = fs.readFileSync(path.join(ROOT, 'filter-list-updater.js'), 'utf8');
  assert(filterUpdaterSource.includes('https://small.oisd.nl/domainswild2') && filterUpdaterSource.includes('https://nsfw-small.oisd.nl/domainswild2'), 'Maintained public ad/tracker and NSFW filter sources are missing');
  assert(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('applyCommunityFilterRules') && fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('COMMUNITY_FILTER_ALARM') && fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('filter-list-updater.js'), 'Daily community-filter refresh and non-destructive rule application are missing');
  for (const name of ['popup.html','dashboard.html','miniapp.html']) { const ui = fs.readFileSync(path.join(ROOT,name),'utf8'); assert(ui.includes('id="communityFiltersEnabled"') && ui.includes('id="updateCommunityFilters"') && ui.includes('id="communityFilterStatus"'), `${name} needs community-list controls and status`); }
  assert(!manifest.permissions.includes('notifications'));
  assert(fs.existsSync(path.join(ROOT, manifest.background.service_worker)));
  for (const script of manifest.content_scripts.flatMap(item => item.js)) assert(fs.existsSync(path.join(ROOT, script)), `Missing content script ${script}`);
  for (const icon of Object.values(manifest.action.default_icon)) assert(fs.existsSync(path.join(ROOT, icon)), `Missing action icon ${icon}`);
  assert(!fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('chrome.notifications'));
  assert(!fs.readFileSync(path.join(ROOT, 'notification-content.js'), 'utf8').includes('chrome.notifications'));
  assert(fs.existsSync(path.join(ROOT, 'dashboard.html')) && fs.existsSync(path.join(ROOT, 'dashboard.css')), 'Separate full dashboard page/styles must exist');
  assert(fs.existsSync(path.join(ROOT, 'miniapp.html')) && fs.existsSync(path.join(ROOT, 'miniapp-tab.css')), 'Dedicated mini-app tab fallback must exist');
  const miniappHtml = fs.readFileSync(path.join(ROOT, 'miniapp.html'), 'utf8');
  assert(miniappHtml.includes('class="miniapp-tab-mode"') && miniappHtml.includes('popup.js') && miniappHtml.includes('miniapp-tab.css'), 'Mini-app tab must use shared app logic and responsive tab styles');
  assert(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes("DG_OPEN_DASHBOARD"), 'Dedicated dashboard route missing');
  assert(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes("openOrFocusExtensionPage('miniapp.html'"), 'Widget mini-app fallback must open the mini-app tab, not the dashboard');
  assert(fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8').includes('miniapp-tab-mode'), 'Mini-app tab must retain source webpage context');
  assert(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes("dashboard.html"), 'Widget fallback must open the separate dashboard page');
  assert(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('DG_AGENT_CREATE_PLAN') && fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('DEFAULT_AI_MEMORY'), 'Persistent learning memory and daily plan handlers missing');
  assert(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('hourlyCategorySeconds') && fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('productiveTrendPct'), 'Local day-part rhythm and week-over-week trend summaries missing');
  assert(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('recordFocusOutcome') && fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8').includes('DG_AGENT_RESET_LEARNING'), 'Outcome-aware Focus learning or local memory reset missing');
  assert(fs.readFileSync(path.join(ROOT, 'notification-content.js'), 'utf8').includes('originDecisionId:decisionId'), 'AI-suggested Focus outcome attribution missing');
  assert(fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8').includes('id="resetLearningMemory"') && fs.readFileSync(path.join(ROOT, 'dashboard.html'), 'utf8').includes('id="resetLearningMemory"'), 'Visible local AI memory reset must exist in mini-app and dashboard');
  const aiServer = fs.readFileSync(path.join(ROOT, 'server/server.js'), 'utf8');
  assert(aiServer.includes('isComplexCoachRequest') && aiServer.includes('isComplexPlanningInput') && aiServer.includes('complex-task-cloud-route'), 'Hybrid task-complexity routing is missing');
  assert(aiServer.includes('AI_CLOUD_FALLBACK_ENABLED') && aiServer.includes('function cloudConsentForRequest(body)') && aiServer.includes('return PUBLIC_MODE ? true : body?.allowCloudFallback === true'), 'Public cloud routing must derive permission from the active server-recorded single consent; local/hybrid dev retains request-level gating');
  assert(aiServer.includes('/v1/agent/plan'), 'AI daily-plan endpoint missing');
  assert(aiServer.includes("url.pathname==='/v1/classify'") && aiServer.includes("callAIProvider('local'") && aiServer.includes('In local mode /v1/classify NEVER forwards page context to a cloud model') && aiServer.includes('PUBLIC_MODE'), 'Local classification must stay local by default; hosted page review must use the single server-verified Setup consent.');
  for (const name of ['popup.html','dashboard.html','miniapp.html']) {
    const ui = fs.readFileSync(path.join(ROOT,name),'utf8');
    assert(ui.includes('Data consent is managed in Setup') && ui.includes('How Coach uses data') && /single Setup choice enables hosted AI/i.test(ui), `${name} must link Coach consent to the single Setup choice and disclose hosted AI processing`);
    assert(ui.includes('class="coach-info-details"') && ui.includes('class="agent-history-details"') && ui.includes('class="coach-advanced-tools"'), `${name} must keep long explanations, recent history, and sample tools collapsed by default`);
    for (const removed of ['id="localPageAIEnabled"','id="coachLocalConsent"','id="agentIncludeContext"','id="coachIncludeContext"']) assert(!ui.includes(removed), `${name} must not offer category or per-feature personal-data scope toggles (${removed})`);
  }
  for (const name of ['popup.html','dashboard.html','miniapp.html']) {
    const ui = fs.readFileSync(path.join(ROOT,name),'utf8');
    for (const id of ['sharingConsent','coachConsentGate','coachControls']) assert(ui.includes(`id="${id}"`), `${name} must have the global Setup consent gate (${id})`);
    assert(!ui.includes('id="agentConsent"') && !ui.includes('id="dataSharingEnabled"') && !ui.includes('id="coachCloudConsent"'), `${name} must not expose duplicate consent or data-category toggles`);
    assert(ui.includes('operator can access and download') && ui.includes('Turning sharing off stops future uploads') && ui.includes('full dataset starts syncing automatically'), `${name} must disclose operator access, revocation behavior and automatic full-dataset sync`);
  }
  pass('Compact Coach UX: consent scope remains explicit, long explanations/history/sample cards collapse by default, and primary Think now action stays visible');
  assert(fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('function hasCurrentDataConsent(state)') && fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('allowCloudFallback:Boolean(s.aiCompanion?.allowCloudAI)'), 'Coach must use Setup consent and the hosted AI permission derived from it');
  assert(fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('function hasCurrentDataConsent(s)') && fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('dataConsentVersion: DGData.CONSENT_VERSION'), 'Background AI and page classification must be gated by Setup consent');
  assert(fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('dataConsentVersion:window.DGData.CONSENT_VERSION') && fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes("$('sharingConsent')"), 'Manual Coach requests must carry the current Setup consent metadata');
  assert(fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('allowCloudFallback: Boolean(brain.allowCloudAI)'), 'Proactive AI must use the hosted AI permission derived from the single consent in hosted mode');
  assert(aiServer.includes('function validDataConsent(body)') && aiServer.includes('DATA_CONSENT_VERSION = 5'), 'Backend AI and ingest routes must enforce current Setup consent version');
  assert(fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('DG_SET_LOCAL_PAGE_AI_ENABLED') && fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes("source: 'local-ai-review'") && fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('preserveLocalAIReview'), 'Local page AI setting, compact classification storage and heartbeat preservation are missing');
  assert(fs.readFileSync(path.join(ROOT,'content.js'),'utf8').includes('safeLocalAIPageContext') && fs.readFileSync(path.join(ROOT,'content.js'),'utf8').includes('reviewUncertainPageWithLocalAI'), 'Uncertain-page local AI opt-in pipeline is missing');
  pass('Local page AI: unified complete-context Brain consent, bounded local page analysis, local-only model route and deterministic safety authority');
  assert(aiServer.includes('/v1/enroll') && aiServer.includes('/v1/ai/test'), 'Automatic enrollment and real model-response diagnostics must be implemented');
  for (const file of ['popup.css','dashboard.css','miniapp-tab.css']) assert(fs.readFileSync(path.join(ROOT,file),'utf8').includes('3.3.1 Grow-page polish') && fs.readFileSync(path.join(ROOT,file),'utf8').includes('.optional-checkins[open]'), `${file} must keep expanded optional Grow activities in the dark theme`);
  pass('Unified AI and consent-triggered auto-sync: one hosted consent, enrollment, owner data export and real AI diagnostics');
  const miniappTabHtml = fs.readFileSync(path.join(ROOT, 'miniapp.html'), 'utf8');
  assert(miniappTabHtml.includes('class="miniapp-tab-mode"') && miniappTabHtml.includes('popup.js'), 'Mini-app tab fallback must use the shared app and responsive mode');
  const initialHtml = fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8');
  const dashboardHtml = fs.readFileSync(path.join(ROOT, 'dashboard.html'), 'utf8');
  assert(!initialHtml.includes('class="dashboard-mode"') && dashboardHtml.includes('class="dashboard-mode"'), 'Toolbar popup and full dashboard must have separate layouts');
  const cssText = fs.readFileSync(path.join(ROOT, 'dashboard.css'), 'utf8');
  assert(cssText.includes('width:100% !important') && cssText.includes('max-width:1180px'), 'Responsive dashboard CSS missing');
  assert(dashboardHtml.includes('dashboardActivityFeed') && dashboardHtml.includes('dashboardAgentFeed') && dashboardHtml.includes('dashboardWeekChart'), 'Full dashboard detail panels missing');
  assert(dashboardHtml.includes('id="dashboardInsights"') && dashboardHtml.indexOf('id="dashboardInsights"') > dashboardHtml.indexOf('id="siteHelp"') && dashboardHtml.indexOf('id="dashboardOverview"') > dashboardHtml.indexOf('id="plantEmoji"'), 'Full dashboard must lead with the plant and keep analytics in an optional expandable section');
  const content = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  for (const id of ['data-dg-view=\"grow\"','data-dg-view=\"focus\"','data-dg-view=\"coach\"','data-dg-view=\"more\"','DG_OPEN_DASHBOARD','DG_AGENT_RUN_NOW','attachShadow','widget.css']) assert(content.includes(id), `Floating widget quick view/action missing: ${id}`);
  assert.equal(manifest.content_scripts[0].js[0], 'ai-content-detector.js', 'Local disclosure detector must load before the content script that calls it');
  assert(content.includes('DGLocalAiDisclosureDetector') && content.includes('tickAiDisclosureReplacement') && content.includes("showAiPauseOverlay(shown.interruptions - 1, 'disclosure')"), 'Conservative disclosure detector must be connected to the in-page replacement overlay');
  assert(content.includes('function replaceAiItem') && content.includes('data-dg-ai-replacement') && content.includes('Show original'), 'Explicitly labelled media must support safe inline replacement and restore');
  assert(fs.readFileSync(path.join(ROOT, 'ai-content-detector.js'), 'utf8').includes('EXACT_LABEL'), 'Disclosure detection must use explicit labels rather than guessing from prose');
  for (const name of ['popup.html','miniapp.html','dashboard.html']) assert(fs.readFileSync(path.join(ROOT,name),'utf8').includes('AI-content pause & replacement'), `${name} needs the accurate AI-content replacement label`);
  const detectorOutput = execFileSync(process.execPath, [path.join(ROOT, 'tests/ai-content-detector.cjs')], { encoding: 'utf8', timeout: 10000 });
  assert.match(detectorOutput, /PASS\s+Conservative AI-content detector/);
  report.push('PASS  Local AI-content disclosure detector: explicit labels only, no raw content capture');
  console.log('PASS  Local AI-content disclosure detector: explicit labels only, no raw content capture');
  const domainUtilityOutput = execFileSync(process.execPath, [path.join(ROOT, 'tests/domain-utils.cjs')], { encoding: 'utf8', timeout: 10000 });
  assert.match(domainUtilityOutput, /PASS\s+Shared domain utility/);
  report.push('PASS  Shared domain parser validates custom protection and Focus allowlist entries');
  console.log('PASS  Shared domain parser validates custom protection and Focus allowlist entries');
  const accessible = manifest.web_accessible_resources.flatMap(item => item.resources || []);
  assert(accessible.includes('widget.css'), 'Shadow DOM widget stylesheet must be web-accessible to host webpages');
  const widgetCss = fs.readFileSync(path.join(ROOT, 'widget.css'), 'utf8');
  assert(widgetCss.startsWith('/* Digital Greenhouse floating widget styles, isolated in Shadow DOM. */') && widgetCss.includes(':host(.dg-min)'), 'Widget CSS must be isolated and support minimize state');
  pass('Manifest v3 and three distinct connected interfaces: toolbar mini-app, isolated floating quick views, full dashboard page');

  const rules = JSON.parse(fs.readFileSync(path.join(ROOT, 'rules/ad-filter-rules.json'), 'utf8'));
  const ids = rules.map(rule => rule.id);
  assert(ids.length > 0);
  assert.equal(new Set(ids).size, ids.length, 'Rule IDs must be unique');
  assert(ids.every(id => Number.isInteger(id) && id > 0));
  assert(rules.every(rule => rule.condition && rule.action));
  pass(`Declarative filter rules: ${rules.length}, unique IDs`);

  const html = fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8');
  const idsInHtml = [...html.matchAll(/\bid\s*=\s*['"]([^'"]+)['"]/g)].map(m => m[1]);
  assert.equal(new Set(idsInHtml).size, idsInHtml.length, 'Popup HTML contains duplicate IDs');
  const dashboardHtmlForIds = fs.readFileSync(path.join(ROOT, 'dashboard.html'), 'utf8');
  const miniappIds = [...miniappHtml.matchAll(/\bid\s*=\s*['"]([^'"]+)['"]/g)].map(m => m[1]);
  assert.equal(new Set(miniappIds).size, miniappIds.length, 'Mini-app fallback HTML contains duplicate IDs');
  const dashboardIds = [...dashboardHtmlForIds.matchAll(/\bid\s*=\s*['\"]([^'\"]+)['\"]/g)].map(m => m[1]);
  const idSet = new Set([...idsInHtml, ...dashboardIds, ...miniappIds]);
  const popupJs = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8');
  const literals = [...popupJs.matchAll(/\$\(\s*['"]([^'"]+)['"]\s*\)/g)].map(m => m[1]);
  const missing = [...new Set(literals.filter(id => !idSet.has(id)))];
  assert.deepEqual(missing, [], `popup.js IDs missing from popup.html: ${missing.join(', ')}`);
  assert(html.includes('<script src="data-collection.js"></script>'));
  assert(html.includes('<script src="domain-utils.js"></script>'));
  assert(html.includes('<script src="popup.js"></script>'));
  assert(html.indexOf('data-collection.js') < html.indexOf('domain-utils.js') && html.indexOf('domain-utils.js') < html.indexOf('popup.js'), 'Shared domain parser must load before protection settings code');
  assert(popupJs.includes('function validatedDomains'), 'Protection UI must surface malformed domain entries instead of silently discarding them');
  assert(html.includes('id="createDailyPlan"') && html.includes('id="applyDailyPlan"') && dashboardHtmlForIds.includes('id="createDailyPlan"') && dashboardHtmlForIds.includes('id="applyDailyPlan"'), 'AI daily plan controls must exist in both mini-app and dashboard');
  for (const [name, source] of [['popup', html], ['dashboard', dashboardHtmlForIds], ['mini-app', miniappHtml]]) {
    for (const id of ['routineStudyMinutes','routineExerciseDays','routineReadingMinutes','routineSleepBedtime','routineSleepWake','routineBaselineType','routineBaselineMinutes']) assert(source.includes(`id="${id}"`), `${name} is missing routine questionnaire control ${id}`);
  }
  for (const [name, source] of [['popup', html], ['dashboard', dashboardHtmlForIds], ['mini-app', miniappHtml]]) {
    for (const id of ['activityMetric','activityQuantity','activityQuantityUnit','activityMetricHint']) assert(source.includes(`id="${id}"`), `${name} is missing optional exercise-measurement control ${id}`);
  }
  assert(popupJs.includes('message.quantityValue = Number(amount)') && popupJs.includes('message.quantityUnit') && fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('metricBonusDates[`${day}:${metric}`]'), 'Exercise measurement must flow from the UI through the timer award and same-day anti-farming ledger');
  const growthEngineSource = fs.readFileSync(path.join(ROOT,'growth-engine.js'),'utf8');
  assert(growthEngineSource.includes('function metricProgressBonus') && growthEngineSource.includes('const best = Math.max(...history)') && growthEngineSource.includes('ratio >= 1.2'), 'Exercise measurement rewards must compare against recent personal bests with bounded thresholds');
  assert(popupJs.includes('routineBaseline') && popupJs.includes('routineStudyMinutes') && popupJs.includes('routineExerciseDays') && popupJs.includes('routineSleepBedtime') && fs.readFileSync(path.join(ROOT, 'growth-engine.js'), 'utf8').includes('configuredRoutineBaseline'), 'Structured routine baseline must be wired from setup into activity scoring');
  assert(popupJs.includes('sleepNudgesEnabled') && popupJs.includes('routineSleepNudges') && fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('maybeSleepWindowNudge') && fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('function sleepWindowActive'), 'Sleep schedule must support explicitly opted-in, once-per-window local reminders');
  for (const [name, source] of [['popup', html], ['dashboard', dashboardHtmlForIds], ['mini-app', miniappHtml]]) assert(source.includes('id="routineSleepNudges"') && source.includes('Never blocks a page or changes plant health'), `${name} must explain the optional non-punitive sleep nudge`);
  for (const [name, source] of [['popup', html], ['dashboard', dashboardHtmlForIds], ['mini-app', miniappHtml]]) assert(source.includes('routine-window-day') && source.includes('routine-day-pills'), `${name} needs weekday-aware routine scheduling`);
  assert(popupJs.includes('routineDays') && fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('function routineWindowActive') && fs.readFileSync(path.join(ROOT,'background.js'),'utf8').includes('Overnight sessions belong to the day on which they start'), 'Routine weekday choices must persist and be applied to local schedule enforcement');
  for (const file of ['popup.html','dashboard.html','miniapp.html']) {
    const copy = fs.readFileSync(path.join(ROOT, file), 'utf8');
    assert(copy.includes('cap at 20 points per local day') || copy.includes('cap at 20 points per local day.') || copy.includes('cap at 20 points per local day;') || copy.includes('cap at 20 points per local day.'), `${file} has inconsistent browser-point cap copy`);
  }
  pass(`Popup UI wiring: ${idsInHtml.length} unique IDs; all ${new Set(literals).size} literal ID references resolve`);

  const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
  const dashboardCss = fs.readFileSync(path.join(ROOT, 'dashboard.css'), 'utf8');
  const popupCss = fs.readFileSync(path.join(ROOT, 'popup.css'), 'utf8');
  const serverSource = fs.readFileSync(path.join(ROOT, 'server/server.js'), 'utf8');
  const notify = fs.readFileSync(path.join(ROOT, 'notification-content.js'), 'utf8');
  assert.equal(manifest.version, '3.3.1', 'Manifest version must match the public AI connection release');
  assert(bg.includes('autoStartFocusOnDistraction') && bg.includes("action === 'start_focus'") && bg.includes('confidence < 0.85') && bg.includes("distractionEnforcement !== 'remind'"), 'Guarded autonomous Focus must respect explicit opt-in and hard-stop mode');
  assert(serverSource.includes('const allowAutoFocus = body.allowAutoFocus === true') && serverSource.includes("safeSnapshot.settings.distractionEnforcement === 'block'") && serverSource.includes('safeSnapshot.focus.active !== true') && serverSource.includes("selectedAction==='start_focus' && (!allowAutoFocus || confidence < 0.85)"), 'Backend must independently enforce opt-in, hard-stop mode and confidence for automatic Focus');
  assert(bg.includes("DG_SET_PAGE_CATEGORY") && bg.includes('pageCorrections') && bg.includes("DG_ADD_CURRENT_TO_FOCUS_ALLOWLIST"), 'User-correctable local page understanding / explicit Focus allowlist controls missing');
  assert(bg.includes('correctionOnlyProductivity') && bg.includes('ignoreCorrection = false') && bg.includes('detectedCategory'), 'User feedback must not substitute for independent productive evidence or bypass detection');
  assert(bg.includes('Useful feedback saved. It does not award points by itself or disable distraction checks.'), 'Correction feedback must explain that it cannot grant points or disable distraction checks');
  assert(!bg.includes('function isFocusAllowed(s, domain, _tabId = null) {\n  const corrected'), 'User page corrections must not automatically bypass strict Focus allowlist');
  assert(bg.includes('allowlist: []') && bg.includes('wasExactlyLegacyDefaults') && bg.includes('schemaVersion: 25'), 'Version 25 must migrate away from hard-coded useful-site starter defaults');
  assert(!/const STARTER_ALLOW\s*=/.test(fs.readFileSync(path.join(ROOT,'popup.js'),'utf8')), 'UI must not silently prefill a hand-curated useful-domain list');
  const consentModule = fs.readFileSync(path.join(ROOT,'data-collection.js'),'utf8');
  assert(consentModule.includes('const CONSENT_VERSION = 5') && consentModule.includes('Never silently upgrade an old consent record') && consentModule.includes('syncResult'), 'Updated one-choice consent must require re-acceptance and launch sync immediately');
  assert(consentModule.includes('consentAccepted !== true') && consentModule.includes('all-or-none-complete-dataset'), 'Central sync must require explicit all-or-nothing data consent');
  assert(serverSource.includes('const DATA_CONSENT_VERSION = 5') && serverSource.includes('validDataConsent(body)') && serverSource.includes('dataConsentVersion') && serverSource.includes('/v1/enroll') && serverSource.includes('/v1/admin/export'), 'Backend must validate consent, auto-enroll installations, and provide owner data export');
  assert(!serverSource.includes('consentVersion:3, consentAt:'), 'Stored uploads must use the current consent-policy version');
  assert(serverSource.includes('req.dgPublicPrincipal?.subject !== installId') && serverSource.includes('DG_OWNER_ADMIN_TOKEN'), 'Public enrollment tokens must be installation-bound and owner export separately protected');
  for (const file of ['popup.html','dashboard.html','miniapp.html']) {
    const copy = fs.readFileSync(path.join(ROOT,file),'utf8');
    assert(copy.includes('id=\"sharingConsent\"') && copy.includes('id=\"coachConsentGate\"') && copy.includes('id=\"coachControls\"'), `${file} must gate Coach behind the single Setup data consent`);
    assert(!copy.includes('id=\"dataSharingEnabled\"') && !copy.includes('id=\"agentConsent\"') && !copy.includes('id=\"coachCloudConsent\"'), `${file} must not show duplicated or per-category data consent controls`);
    assert(copy.includes('The one Setup choice controls full-dataset sync and hosted AI') && copy.includes('download your copy or request deletion'), `${file} must explain the simplified one-consent hosted service and owner-user data tools`);
  }
  assert(bg.includes('nextGardenGuardEnabled && !nextAllowlist.length') && bg.includes('Before starting locked Focus, add at least one permitted website'), 'Strict locking must reject an empty allowlist instead of accidentally blocking every site');
  assert(dashboardCss.includes('background:#111427!important') && dashboardCss.includes('.dashboard-metric') && dashboardCss.includes('.dashboard-panel'), 'Full dashboard must override legacy light backgrounds across the page');
  assert(popupCss.includes('.domain-rules-details') && popupCss.includes('.domain-rules-explainer'), 'Advanced domain rules need styled explanatory disclosure');
  for (const file of ['popup.html','dashboard.html','miniapp.html']) {
    const copy = fs.readFileSync(path.join(ROOT, file), 'utf8');
    assert(copy.includes('Greenhouse judges page usefulness') && copy.includes('These lists do not mark pages useful'), `${file} must distinguish AI page classification from manual access-control rules`);
  }
  assert(fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('thought-details') && fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('d.reason') && fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('confidence estimate'), 'AI decision confidence and rationale should be available under the expandable explanation');
  assert(fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('Personal page corrections:'), 'Coach memory must report user-corrected page classifications');
  assert(bg.includes('currentContextLearning') && bg.includes('contextStats') && bg.includes('applyDecisionPolicy'), 'Context-conditioned learning and repeat-action policy must exist');
  assert(bg.includes('function advanceBrowserTracking') && bg.includes('chrome.tabs.onActivated.addListener') && bg.includes('chrome.tabs.onUpdated.addListener') && bg.includes('activeTabTickQueue'), 'Foreground activity tracking must sample real tab switches/navigation and serialize ticks to avoid double counting');
  assert(bg.includes('Post-classification tracking sample skipped'), 'Fresh page classification should establish the active category baseline immediately after saving the local signal');
  assert(bg.includes('classifierEvidence') && bg.includes('repeatedSites') && bg.includes('averageConfidenceTenths'), 'Domain-free aggregate classifier evidence must be supplied to the agent');
  assert(fs.readFileSync(path.join(ROOT,'content.js'),'utf8').includes('result.pageKind') && fs.readFileSync(path.join(ROOT,'content.js'),'utf8').includes('result.pageFeatures.headings'), 'Page structure changes must refresh local analysis');
  assert(fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('Context patterns remembered:'), 'Coach memory summary should expose context learning');
  pass('Advanced intelligence gates: explainable decisions, contextual memory, aggregate classifier evidence, confidence-scored actions, firm-stop guard and local classification learning');
  for (const id of ['distractionEnforcement','distractionThresholdMinutes','distractionCooldownMinutes','protectionStatus']) assert(html.includes(`id=\"${id}\"`) && dashboardHtmlForIds.includes(`id=\"${id}\"`), `Strong distraction-stop control missing from mini-app/dashboard: ${id}`);
  assert(html.includes('Stop the page and block it temporarily'), 'Default hard-stop option missing');
  assert(bg.includes('temporaryAutoBlocks') && bg.includes('activeAutoBlockExpiry') && bg.includes('DG_BLOCKED_OVERRIDE'), 'Timed automatic distraction blocks and intentional exception handling missing');
  assert(bg.includes('distractionThresholdMinutes') && bg.includes('distractionCooldownMinutes'), 'Configurable active-distraction threshold/cooldown missing');
  assert(bg.includes('recordBlockedNavigation') && bg.includes('blockedEvents'), 'Local blocked attempt logging missing');
  assert(fs.readFileSync(path.join(ROOT,'blocked.js'),'utf8').includes('Temporary distraction stop') && fs.readFileSync(path.join(ROOT,'blocked.html'),'utf8').includes('Start a 50-minute Focus'), 'Polished hard-stop page missing');
  pass('Configurable firm intervention controls, timed per-domain stop rules, blocked-attempt log and focus action are wired');
  assert(bg.includes("importScripts('service-config.js', 'ai-client.js', 'data-collection.js', 'growth-engine.js', 'domain-utils.js', 'filter-list-updater.js')"));
  assert(fs.existsSync(path.join(ROOT, 'domain-utils.js')), 'Shared domain validation utility is missing');
  for (const name of ['popup.html','miniapp.html','dashboard.html']) assert(fs.readFileSync(path.join(ROOT,name),'utf8').includes('domain-utils.js'), `${name} must share the validated domain parser`);
  assert(fs.existsSync(path.join(ROOT, 'growth-engine.js')), 'Growth engine module is missing');
  assert(bg.includes('accountForActiveBrowsing'));
  assert(bg.includes('CENTRAL_SYNC_ALARM'));
  assert(bg.includes('maybeRunAiAgent'));
  assert(bg.includes('MAX_AUTOMATIC_BROWSER_POINTS_PER_DAY') && bg.includes('memory.actionStats'), 'Daily automatic reward ceiling and cumulative feedback memory missing');
  assert(bg.includes("trigger: 'distraction-warning'") && fs.readFileSync(path.join(ROOT,'server/server.js'),'utf8').includes('const trigger=') , 'Meaningful distraction-warning event is not routed through the AI brain');
  assert(bg.includes('AI_AGENT_MAX_RUNS_PER_DAY'));
  assert(bg.includes('DG_AGENT_SAVE_SETTINGS'));
  assert(bg.includes('DG_AGENT_RUN_NOW'));
  assert(bg.includes('DG_AGENT_PREVIEW_ACTION'));
  assert(bg.includes('DG_AGENT_FEEDBACK'));
  assert(notify.includes('Start strict Focus')); 
  assert(notify.includes('DG_AGENT_FEEDBACK'));
  assert(fs.readFileSync(path.join(ROOT, 'server/server.js'), 'utf8').includes('/v1/agent/decision'));
  assert(html.includes('id="agentEnabled"') && html.includes('id="runAgentNow"') && html.includes('id="previewAgentAction"'));
  const objectiveHandler = bg.slice(bg.indexOf("if (m?.type === 'DG_COMPLETE_OBJECTIVE')"), bg.indexOf("if (m?.type === 'DG_PAGE_ANALYSIS')"));
  assert(objectiveHandler.includes('objectiveFocus && Date.now() < Date.parse(objectiveFocus.endsAt)'), 'Manual objective points must also pause during Focus');
  const activeBrowsingHandler = bg.slice(bg.indexOf('const accountForActiveBrowsing'), bg.indexOf('  const focusExpired = finishExpiredFocus(s);'));
  assert(bg.includes('b.dailyActiveMinutes[dayKey]') && activeBrowsingHandler.includes('const accountForActiveBrowsing = async'), 'Local activity totals must continue while reminders are off');
  assert(notify.includes("DG_IN_APP_NOTIFICATION"));
  assert(notify.includes('attachShadow'));
  assert(fs.readFileSync(path.join(ROOT, 'server/.env.example'), 'utf8').includes('AI_CLOUD_FALLBACK_ENABLED=false'), 'Local/development cloud fallback must stay disabled by default');
  pass('Reminder, full-data sync, proactive-agent and popup action wiring is present');
  assert(bg.includes('WELLBEING_CHECKIN_SECONDS = 20 * 60') && bg.includes('WELLBEING_HOURLY_SECONDS = 60 * 60'), '20-minute active-use check-ins and hourly wellbeing prompts must be implemented');
  assert(fs.readFileSync(path.join(ROOT,'blocked.js'),'utf8').includes('durationMinutes: 50') && !fs.readFileSync(path.join(ROOT,'blocked.js'),'utf8').includes('durationMinutes: 15'), 'Blocked-page Focus must use the agreed 50-minute default');
  assert(bg.includes('deferredGrowthRewards') && bg.includes('rewardPending: growthFrozen') && bg.includes('settleDeferredWellbeingRewards(s)'), 'Break rewards must remain deferred during strict Focus so points and growth stay frozen');
  assert(bg.includes('aiContentInterruptionEnabled: true') && bg.includes('previousSchemaVersion < 23') && fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('aiContentInterruptionEnabled: true'), 'AI-disclosed-content replacement should be enabled for fresh installs and on migration to 3.1.0');
  assert(fs.readFileSync(path.join(ROOT,'content.js'),'utf8').includes('background:radial-gradient(circle at 16% 10%,#353166'), 'Full-page AI tool pause should use the accessible jewel palette');
  assert(fs.readFileSync(path.join(ROOT,'blocked.html'),'utf8').includes('content="dark"') && fs.readFileSync(path.join(ROOT,'content.js'),'utf8').includes('linear-gradient(145deg,#171b35'), 'Block page and replacement card need high-contrast jewel-toned surfaces');
  assert(bg.includes('user-admitted-false-break-claim') && bg.includes('60 * 60000') && bg.includes('break-confirmed-without-away-time'), 'False break confirmations must activate a 60-minute strict lock and unverifiable confirmations must fail closed');
  assert(bg.includes('Strict Focus is locked until') && bg.includes('session.strict === true') && fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('Resetting the extension from inside the app is disabled'), 'Strict Focus must reject early exit and prevent in-app reset bypasses');
  assert(bg.includes('buildFullPersonalContext') && bg.includes('fullContextConsentAt') && serverSource.includes('sanitizeAIContext'), 'AI Brain must require and bound the complete consented local personal context');
  assert(fs.readFileSync(path.join(ROOT,'data-collection.js'),'utf8').includes('digital-greenhouse-user-dataset-v3') && serverSource.includes('Invalid all-or-none full-data submission'), 'Central backup must use all-or-none full-data schema rather than category-sliced aggregates');
  assert(fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('digital-greenhouse-local-data-export-v5') && fs.readFileSync(path.join(ROOT,'popup.js'),'utf8').includes('chrome.storage.local.get(null)') && fs.readFileSync(path.join(ROOT,'popup.html'),'utf8').includes('Download my local data'), 'User must be able to export every local extension storage field without truncation');
  assert(['popup.css','dashboard.css','miniapp-tab.css'].every(n => fs.readFileSync(path.join(ROOT,n),'utf8').includes('midnight glass + jewel gradients')) && fs.readFileSync(path.join(ROOT,'widget.css'),'utf8').includes('jewel-toned glass skin'), 'The UI refresh must apply to popup, dashboard, mini-app, and floating widget');
  pass('Vision-completion regression coverage: 20m/hourly wellbeing, integrity lock, full AI-context consent, all-data ownership, and visual refresh');

}

function clone(value) { return value == null ? value : structuredClone(value); }
async function testDataCollectorPrivacy() {
  const today = new Date();
  const day = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  const sample = {
    schemaVersion: 7,
    profile: { routineNotes: 'SECRET_ROUTINE_NOTE_917', goalNotes: 'SECRET_GOAL_NOTE_918', dailyObjectives: ['SECRET_OBJECTIVE_LABEL_919'], onboardingComplete: true, tone: 'gentle', dataCollection: { installToken: 'PRIVATE_INSTALL_TOKEN_SHOULD_NOT_UPLOAD' } },
    plant: { growthPoints: 67, milestones: [25], health: 73, growthDays: 14, lastHealthCheckIn: '2026-10-20T10:00:00.000Z' },
    lifeGrowth: { goals: [{ title: 'SECRET_GOAL_NAME_920' }], objectiveCompletions: { [day]: { 'objective-1': { label: 'SECRET_COMPLETION_LABEL_921', points: 4 } } } },
    browsing: {
      trackingEnabled: true,
      pointEvents: [{ id: 'evt', source: 'browser', category: 'productive', domain: 'SECRET_DOMAIN_922.example', label: 'SECRET_EVENT_LABEL_923', points: 3, createdAt: new Date().toISOString() }],
      dailyActiveMinutes: { [day]: 88 }, dailyMinutesByCategory: { [`${day}:productive`]: 41, [`${day}:distracting`]: 9 }
    },
    digitalAwareness: { remindersEnabled: true, focusSessions: [{ startedAt: new Date().toISOString(), endedAt: new Date().toISOString(), actualMinutes: 22 }] },
    digitalProtection: { adBlockEnabled: true, adultSiteBlockingEnabled: true, gardenGuardEnabled: false, customBlockedDomains: ['SECRET_BLOCKED_DOMAIN_924.example'], allowlist: ['SECRET_ALLOWED_DOMAIN_925.example'] },
    wellbeing: { selfRating: 1, note: 'SECRET_HEALTH_NOTE_926' },
    technicalEvents: [{ eventName: 'SECRET_TECH_EVENT_927', at: new Date().toISOString() }]
  };
  const store = { dgState: clone(sample) };
  const uploads = [];
  let deleteResponse = { ok: true, status: 200, json: async () => ({ ok: true, deleted: true }) };
  const revocations = [];
  const chrome = {
    storage: { local: {
      get: async key => ({ dgState: clone(store.dgState) }),
      set: async values => { if (values.dgState) store.dgState = clone(values.dgState); }
    } },
    permissions: { contains: async () => true, request: async () => true },
    runtime: { getManifest: () => ({ version: '1.7.0' }) }
  };
  const fakeFetch = async (url, options = {}) => {
    if (String(url).includes('/v1/enroll')) return { ok:true, status:200, json:async()=>({ok:true,requiresAccessToken:false,mode:'local'}) };
    if (String(url).includes('/v1/ingest')) {
      uploads.push(JSON.parse(options.body));
      return { ok: true, status: 202, json: async () => ({ ok: true, receivedAt: new Date().toISOString() }) };
    }
    if (String(url).includes('/v1/revoke')) { revocations.push(JSON.parse(options.body)); return {ok:true,status:200,json:async()=>({ok:true,confirmed:true,consentActive:false,storedDataRetained:true})}; }
    if (String(url).includes('/v1/data/')) return deleteResponse;
    throw new Error(`Unexpected URL from collector: ${url}`);
  };
  const sandbox = { chrome, crypto: crypto.webcrypto, fetch: fakeFetch, URL, AbortSignal, Date, Math, Object, Array, Number, String, Boolean, JSON, RegExp, Error, Promise, console, DGServiceConfig:{mode:'local',endpoint:'http://127.0.0.1:8787',defaultEndpoint:'http://127.0.0.1:8787'} };
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'data-collection.js'), 'utf8'), sandbox, { filename: 'data-collection.js' });
  const api = sandbox.DGData;
  assert(api, 'Shared data-collection module was not exposed');
  assert.equal(api.DEFAULT_ENDPOINT, 'http://127.0.0.1:8787');
  assert.deepEqual(JSON.parse(JSON.stringify(api.DEFAULT_CATEGORIES)), { activities: true, routine: true, health: true, digital: true, technical: true, feedback: true });

  let consentBlocked = false;
  try { await api.configure({ enabled: true, endpoint: 'http://127.0.0.1:8787', categories: api.DEFAULT_CATEGORIES, consentAccepted: false }); } catch (e) { consentBlocked = /consent/i.test(e.message); }
  assert(consentBlocked, 'Sharing enable must require explicit consent');

  let unsafeEndpointBlocked = false;
  try { api.cleanEndpoint('http://outside.example'); } catch (e) { unsafeEndpointBlocked = /HTTPS/i.test(e.message); }
  assert(unsafeEndpointBlocked, 'Plain HTTP non-local analytics endpoint must be rejected');

  const categories = { activities: true, routine: true, health: true, digital: true, technical: true, feedback: true };
  const payload = api.buildPayload(sample, categories);
  const payloadText = JSON.stringify(payload);
  assert.equal(payload.format, 'digital-greenhouse-user-dataset-v3');
  assert(payloadText.includes('SECRET_ROUTINE_NOTE_917') && payloadText.includes('SECRET_GOAL_NOTE_918'), 'The complete dataset must include personal context only after explicit all-or-none consent');
  assert(payloadText.includes('SECRET_DOMAIN_922.example') && payloadText.includes('SECRET_HEALTH_NOTE_926'), 'Full-data sharing must include browsing corrections/history and wellbeing records, rather than category aggregates');
  assert(!payloadText.includes('PRIVATE_INSTALL_TOKEN_SHOULD_NOT_UPLOAD'), 'Installation auth credentials must not be sent to the server');
  assert.deepEqual(JSON.parse(JSON.stringify(payload.includedStorageKeys)), ['dgState']);
  pass('All-or-none collector includes the complete personal dataset after consent, excludes installation secrets, and refuses partial uploads');

  const configured = await api.configure({ enabled: true, endpoint: 'http://127.0.0.1:8787', categories, consentAccepted: true });
  assert(configured.syncResult?.ok, 'Consent change must immediately enroll and sync without a separate button');
  assert.equal(uploads.length, 1);
  assert.equal(uploads[0].consentVersion, 5);
  assert(uploads[0].consentAt);
  assert.equal(uploads[0].userData.format, 'digital-greenhouse-user-dataset-v3');
  assert(JSON.stringify(uploads[0].userData.storage).includes('SECRET_ROUTINE_NOTE_917'));
  assert(!JSON.stringify(uploads[0].userData.storage).includes('PRIVATE_INSTALL_TOKEN_SHOULD_NOT_UPLOAD'));
  assert(store.dgState.profile.dataCollection.lastSyncedAt, 'Successful sync timestamp not stored');
  const disabled = await api.configure({ enabled:false });
  assert.equal(disabled.enabled,false); assert.equal(disabled.revocationResult?.confirmed,true); assert.equal(revocations.length,1,'Unchecking data consent must notify the central server to stop future uploads/AI without a second control');
  assert.equal(store.dgState.aiCompanion.allowCloudAI,false,'Withdrawal must disable hosted AI on the extension too');
  const removed = await api.deleteRemote();
  assert(removed.ok);
  assert.equal(store.dgState.profile.dataCollection.enabled, false);
  pass('Consent-triggered full-dataset sync, automatic remote revocation on opt-out, local sync status and remote-delete control');
}

function freePort() {
  return new Promise((resolve, reject) => {
    const probe = net.createServer();
    probe.once('error', reject);
    probe.listen(0, '127.0.0.1', () => { const { port } = probe.address(); probe.close(error => error ? reject(error) : resolve(port)); });
  });
}
async function waitForHealth(base, child, getLogs) {
  const deadline = Date.now() + 6000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`Backend exited early: ${getLogs()}`);
    try { const r = await fetch(`${base}/health`); if (r.ok) return await r.json(); } catch {}
    await new Promise(resolve => setTimeout(resolve, 80));
  }
  throw new Error(`Backend did not become healthy: ${getLogs()}`);
}
async function testBackend() {
  const port = await freePort();
  const dbPath = path.join(os.tmpdir(), `dg-smoke-${process.pid}-${crypto.randomUUID()}.json`);
  let output = '';
  const child = spawn(process.execPath, [path.join(ROOT, 'server/server.js')], {
    cwd: path.join(ROOT, 'server'),
    env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', DG_DB_PATH: dbPath, AI_PROVIDER: 'cloud', AI_CLOUD_FALLBACK_ENABLED: 'false', OLLAMA_API_KEY: '' },
    stdio: ['ignore','pipe','pipe']
  });
  child.stdout.on('data', chunk => { output += chunk.toString(); });
  child.stderr.on('data', chunk => { output += chunk.toString(); });
  const base = `http://127.0.0.1:${port}`;
  const installId = crypto.randomUUID();
  const token = `${crypto.randomUUID()}${crypto.randomUUID()}`;
  try {
    const health = await waitForHealth(base, child, () => output);
    assert.equal(health.ok, true);
    assert.equal(health.mode, 'development');
    assert.equal(health.aiConfigured, false);
    const noKeyAgent = await fetch(`${base}/v1/agent/decision`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({snapshot:{}}) });
    assert.equal(noKeyAgent.status, 503, 'Agent endpoint must clearly reject missing AI configuration');
    const noKeyBody = await noKeyAgent.json();
    assert.match(noKeyBody.error, /OLLAMA_API_KEY/);
    const noKeyPlan = await fetch(`${base}/v1/agent/plan`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({snapshot:{}}) });
    assert.equal(noKeyPlan.status, 503, 'Daily plan route must clearly reject missing AI configuration');
    assert.match((await noKeyPlan.json()).error, /OLLAMA_API_KEY/);

    const consentAt = new Date(Date.now() - 1000).toISOString();
    const malicious = {
      schemaVersion: 2, consentVersion: 5, consentAt,
      userData: {
        format: 'digital-greenhouse-user-dataset-v3', exportedAt: new Date().toISOString(), includedStorageKeys: ['dgState'],
        storage: { dgState: {
          profile: { routineNotes:'USER_NOTE_MUST_RETAIN', goalNotes:'USER_GOAL_MUST_RETAIN', dataCollection:{installToken:'SERVER_MUST_STRIP_TOKEN'} },
          plant: { growthPoints:53, health:80 },
          lifeGrowth: { activityLog:[{label:'USER_ACTIVITY_MUST_RETAIN'}], objectiveCompletions:{today:{'objective-1':{label:'USER_OBJECTIVE_MUST_RETAIN',points:5}}} },
          browsing: { pointEvents:[{domain:'user-domain.example',label:'USER_PAGE_EVENT_MUST_RETAIN',points:3}], pageCorrections:{'user-domain.example':{category:'productive'}} },
          digitalAwareness: { focusSessions:[{actualMinutes:75}] },
          wellbeing: { note:'USER_WELLBEING_MUST_RETAIN' },
          arbitrary: { apiKey:'SERVER_MUST_STRIP_APIKEY', usefulFlag:true }
        } }
      }
    };
    const ingested = await fetch(`${base}/v1/ingest`, {
      method: 'POST', headers: { 'Content-Type':'application/json', 'X-DG-Install-Id':installId, 'X-DG-Install-Token':token }, body: JSON.stringify(malicious)
    });
    assert.equal(ingested.status, 202, `Ingest failed: ${await ingested.text()}`);
    const onDisk = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
    const stored = onDisk.installations[installId].submissions[0];
    const storedText = JSON.stringify(stored.userData);
    for (const required of ['USER_NOTE_MUST_RETAIN','USER_GOAL_MUST_RETAIN','USER_ACTIVITY_MUST_RETAIN','USER_OBJECTIVE_MUST_RETAIN','user-domain.example','USER_PAGE_EVENT_MUST_RETAIN','USER_WELLBEING_MUST_RETAIN']) assert(storedText.includes(required), `Full-data server storage unexpectedly lost user data: ${required}`);
    for (const forbidden of ['SERVER_MUST_STRIP_TOKEN','SERVER_MUST_STRIP_APIKEY']) assert(!storedText.includes(forbidden), `Server persisted a credential: ${forbidden}`);
    const download = await fetch(`${base}/v1/data/${installId}`, { headers:{'X-DG-Install-Token':token} });
    const downloadBody = await download.json();
    assert.equal(download.status, 200, `Authorized user data download failed: ${JSON.stringify(downloadBody)}`);
    const downloaded = downloadBody; assert.equal(downloaded.snapshotCount,1); assert(JSON.stringify(downloaded.submissions).includes('USER_NOTE_MUST_RETAIN'));

    const unauthorized = await fetch(`${base}/v1/data/${installId}`, { method:'DELETE', headers:{'X-DG-Install-Token':`${crypto.randomUUID()}${crypto.randomUUID()}`} });
    assert.equal(unauthorized.status, 403, 'Wrong installation token must not delete data');
    const removed = await fetch(`${base}/v1/data/${installId}`, { method:'DELETE', headers:{'X-DG-Install-Token':token} });
    assert.equal(removed.status, 200, `Delete failed: ${await removed.text()}`);
    const after = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
    assert(!after.installations[installId], 'Server record survived deletion');
    pass('Backend health, all-or-none full-data ingest, user export, secret filtering, authorization and remote deletion');
  } finally {
    child.kill('SIGTERM');
    await new Promise(resolve => { if (child.exitCode !== null) return resolve(); child.once('exit', resolve); setTimeout(resolve, 700).unref(); });
    for (const file of [dbPath, `${dbPath}.tmp`]) { try { fs.unlinkSync(file); } catch {} }
  }
}


async function testAgentDecisionEndpoint() {
  const port = await freePort();
  const dbPath = path.join(os.tmpdir(), `dg-agent-smoke-${process.pid}-${crypto.randomUUID()}.json`);
  const mockLog = path.join(os.tmpdir(), `dg-agent-mock-${process.pid}-${crypto.randomUUID()}.json`);
  const mockFile = path.join(os.tmpdir(), `dg-agent-preload-${process.pid}-${crypto.randomUUID()}.cjs`);
  fs.writeFileSync(mockFile, `
    const fs = require('node:fs');
const assert = require('node:assert/strict');
    const originalFetch = globalThis.fetch;
    globalThis.fetch = async (input, init = {}) => {
      const url = typeof input === 'string' ? input : input && input.url;
      if (url === 'https://ollama.com/api/chat') {
        let request = {};
        try { request = JSON.parse(String(init.body || '{}')); } catch {}
        const user = request.messages && request.messages[request.messages.length - 1] ? request.messages[request.messages.length - 1].content : '';
        fs.writeFileSync(process.env.DG_MOCK_AI_LOG_PATH, JSON.stringify({ model: request.model, input: user, system: request.messages?.[0]?.content || '' }));
        const isPlan = String(request.messages?.[0]?.content || '').includes('adaptive daily planning brain');
        let parsedUser = {}; try { parsedUser = JSON.parse(user); } catch {}
        const isAutoFocusContext = parsedUser.snapshot?.activity?.currentCategory === 'distracting';
        const answer = isPlan ? { summary:'A balanced, realistic day', objectives:[{label:'Work on one important task',type:'studying',targetMinutes:25},{label:'Move or get outside',type:'exercise',targetMinutes:15},{label:'Make room for rest or a hobby',type:'rest',targetMinutes:20}],strategy:'Start small and adjust as needed.',focusMinutes:25 } : isAutoFocusContext ? { action:'start_focus', title:'Mock AI Focus', message:'This high-confidence test checks the autonomous Focus guard.', focusMinutes:15, confidence:0.96, reason:'Mocked, high-confidence test response.' } : { action: 'suggest_focus', title: 'Mock AI Focus', message: 'This decision came from the mocked AI model.', focusMinutes: 25, confidence: 0.70, reason: 'Mocked test response.' };
        return new Response(JSON.stringify({ model: 'mock-model', message: { content: JSON.stringify(answer) } }), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }
      return originalFetch(input, init);
    };
  `, 'utf8');
  let output = '';
  const nodeOptions = `${process.env.NODE_OPTIONS || ''} --require="${mockFile}"`.trim();
  const child = spawn(process.execPath, [path.join(ROOT, 'server/server.js')], {
    cwd: path.join(ROOT, 'server'),
    env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', DG_DB_PATH: dbPath, AI_PROVIDER: 'cloud', AI_CLOUD_FALLBACK_ENABLED: 'false', OLLAMA_API_KEY: 'mock-only-test-key', OLLAMA_CLOUD_MODEL: 'mock-model', OLLAMA_MODEL: 'mock-model', DG_MOCK_AI_LOG_PATH: mockLog, NODE_OPTIONS: nodeOptions },
    stdio: ['ignore','pipe','pipe']
  });
  child.stdout.on('data', chunk => { output += chunk.toString(); });
  child.stderr.on('data', chunk => { output += chunk.toString(); });
  const base = `http://127.0.0.1:${port}`;
  try {
    const health = await waitForHealth(base, child, () => output);
    assert.equal(health.aiConfigured, true);
    const missingDataConsent = await fetch(`${base}/v1/coach`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ tone:'gentle', snapshot:{} }) });
    assert.equal(missingDataConsent.status, 403, 'Coach API must reject requests without current Setup data consent');
    const dataConsent = { dataConsentVersion:5, dataConsentAt:new Date(Date.now()-1000).toISOString() };
    const response = await fetch(`${base}/v1/agent/decision`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...dataConsent,
        tone: 'gentle',
        allowCloudFallback: true,
        snapshot: {
          activity: { activeMinutesToday: 65, productiveMinutesToday: 25, distractingMinutesToday: 12, productiveMinutes7d: 180, productiveMinutesPrevious7d: 120, activeMinutes7d: 350, activeMinutesPrevious7d: 400, activeDays7d: 4, productiveTrendPct: 50, distractingTrendPct: -15, currentCategory: 'productive', currentPageKind:'lesson', topicHints:['learning','PRIVATE_TOPIC_DOMAIN.example'], pageFeatures:{productiveScore:8,headings:5,editorSurface:false}, domain: 'PRIVATE_DOMAIN_MUST_NOT_BE_FORWARDED', pageText: 'PRIVATE_PAGE_TEXT_MUST_NOT_BE_FORWARDED' },
          rhythm: { currentDayPart: 'morning', productivePeakPart: 'morning', distractionPeakPart: 'evening', parts: { morning: { productiveMinutes: 55, distractingMinutes: 2 }, evening: { productiveMinutes: 4, distractingMinutes: 25 } } },
          growth: { growthPointsBand: 73, growthDays: 4, healthBand: 80 },
          focus: { active: false, sessions7d: 2, averageMinutes7d: 25, completedSessions7d: 1 },
          memory: { focusOutcomes: { suggested: 5, started: 4, completed: 3, interrupted: 1 } },
          settings: { remindersEnabled: true, reminderMinutes: 45 }
        }
      })
    });
    const result = await response.json();
    assert.equal(response.status, 200, `Agent decision failed: ${JSON.stringify(result)}`);
    assert.equal(result.ok, true);
    assert.equal(result.decision.action, 'suggest_focus');
    assert.equal(result.decision.focusMinutes, 25);
    assert.deepEqual(Object.keys(result.decision).sort(), ['action','confidence','focusMinutes','message','reason','title']);
    assert.equal(result.decision.confidence, 0.70);
    assert.equal(typeof result.decision.reason, 'string');
    const outgoing = fs.readFileSync(mockLog, 'utf8');
    assert(!outgoing.includes('PRIVATE_DOMAIN_MUST_NOT_BE_FORWARDED'), 'Raw domain leaked to AI request');
    assert(!outgoing.includes('PRIVATE_PAGE_TEXT_MUST_NOT_BE_FORWARDED'), 'Page text leaked to AI request');
    assert(outgoing.includes('productiveMinutesToday'), 'Aggregate activity snapshot was not sent to AI');
    assert(outgoing.includes('productiveTrendPct') && outgoing.includes('activeDays7d'), 'Week-over-week activity trends were not forwarded');
    const sentAiPayload = JSON.parse(JSON.parse(outgoing).input);
    assert.deepEqual(sentAiPayload.snapshot.activity.topicHints, ['learning'], 'Backend must preserve only approved topic hints');
    assert.equal(sentAiPayload.snapshot.activity.currentPageKind, 'lesson');
    assert(!outgoing.includes('PRIVATE_TOPIC_DOMAIN.example'), 'Unapproved topic label leaked to the model');
    assert(outgoing.includes('classifierEvidence') && outgoing.includes('averageConfidenceTenths'), 'Aggregate classifier evidence should reach the AI');
    assert(outgoing.includes('productivePeakPart') && outgoing.includes('focusOutcomes'), 'Coarse day-part rhythm and Focus outcome learning were not forwarded');
    assert(!outgoing.includes('PRIVATE_DOMAIN_MUST_NOT_BE_FORWARDED') && !outgoing.includes('PRIVATE_PAGE_TEXT_MUST_NOT_BE_FORWARDED'), 'Raw browsing details leaked into the AI request');
    const permittedAutoFocus = await fetch(`${base}/v1/agent/decision`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...dataConsent,trigger:'distraction-warning',allowAutoFocus:true,allowCloudFallback:true,snapshot:{activity:{currentCategory:'distracting'},focus:{active:false},settings:{autoStartFocusOnDistraction:true}}}) });
    const permittedResult = await permittedAutoFocus.json();
    assert.equal(permittedAutoFocus.status,200); assert.equal(permittedResult.decision.action,'start_focus'); assert.equal(permittedResult.decision.focusMinutes,15); assert(permittedResult.decision.confidence >= 0.85);
    const blockedAutoFocus = await fetch(`${base}/v1/agent/decision`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...dataConsent,trigger:'distraction-warning',allowAutoFocus:true,allowCloudFallback:true,snapshot:{activity:{currentCategory:'distracting'},focus:{active:false},settings:{autoStartFocusOnDistraction:false}}}) });
    const blockedResult = await blockedAutoFocus.json();
    assert.equal(blockedResult.decision.action,'suggest_focus','Backend must downgrade autonomous Focus if user opt-in is absent');
    const planResponse = await fetch(`${base}/v1/agent/plan`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ...dataConsent, tone:'gentle', allowCloudFallback:true, snapshot:{activity:{productiveMinutesToday:20,distractingMinutesToday:10,currentPageKind:'lesson',topicHints:['learning','PRIVATE_PLAN_TOPIC_DOMAIN.example'],pageFeatures:{headings:4,codeBlocks:2,editorSurface:false}},learning:{classifierEvidence:{repeatedSites:6,averageConfidenceTenths:7,privateDomain:'PRIVATE_PLAN_EVIDENCE_DOMAIN.example'}},memory:{totalFeedback:7,preferredActions:['suggest_focus'],actionsOftenDeclined:['nudge']}}, snapshotOnly:true }) });
    const planResult = await planResponse.json();
    assert.equal(planResponse.status,200,`Daily plan endpoint failed: ${JSON.stringify(planResult)}`);
    assert.equal(planResult.ok,true); assert.equal(planResult.plan.objectives.length,3); assert.equal(planResult.plan.objectives[0].targetMinutes,25);
    const planLog=JSON.parse(fs.readFileSync(mockLog,'utf8'));
    assert(!planLog.input.includes('PRIVATE_DOMAIN') && !planLog.input.includes('PAGE_TEXT'), 'Daily planning request leaked raw browsing details');
    assert(!planLog.input.includes('PRIVATE_PLAN_TOPIC_DOMAIN.example') && !planLog.input.includes('PRIVATE_PLAN_EVIDENCE_DOMAIN.example'), 'Daily plan request leaked a domain or an unapproved topic hint');
    const sentPlanPayload = JSON.parse(planLog.input);
    assert.deepEqual(sentPlanPayload.snapshot.activity.topicHints, ['learning'], 'Daily plan must retain only allowlisted page-topic hints');
    assert.equal(sentPlanPayload.snapshot.activity.currentPageKind, 'lesson');
    assert.equal(sentPlanPayload.snapshot.learning.classifierEvidence.repeatedSites, 6, 'Daily plan should receive bounded aggregate classifier evidence');
    assert(planLog.input.includes('preferredActions'), 'Daily plan should receive a sanitised learned-preference summary');
    pass('Proactive AI endpoints: decision and plan schemas, topic-hint allowlisting, aggregate classifier evidence, opt-in/confidence-gated autonomous Focus, strict focus-in-session guard, sanitised learning summaries, and sensitive-field exclusion');
  } finally {
    child.kill('SIGTERM');
    await new Promise(resolve => { if (child.exitCode !== null) return resolve(); child.once('exit', resolve); setTimeout(resolve, 700).unref(); });
    for (const file of [dbPath, `${dbPath}.tmp`, mockLog, mockFile]) { try { fs.unlinkSync(file); } catch {} }
  }
}

async function testBackgroundAgentRuntime() {
  const output = execFileSync(process.execPath, [path.join(ROOT, 'tests/agent-runtime.cjs')], { encoding: 'utf8', timeout: 10000 });
  assert.match(output, /PASS\s+Background AI lifecycle/);
  assert.match(output, /PASS\s+Widget navigation runtime/);
  pass('Background AI lifecycle plus widget navigation runtime: AI safety/learning and actual mini-app/dashboard message routing, fallback and tab reuse');
}

(async () => {
  try { runStaticChecks(); } catch (error) { fail('static checks', error); }
  try { await testDataCollectorPrivacy(); } catch (error) { fail('collector privacy tests', error); }
  try { await testBackend(); } catch (error) { fail('backend integration tests', error); }
  try { await testAgentDecisionEndpoint(); } catch (error) { fail('AI agent integration tests', error); }
  try { await testBackgroundAgentRuntime(); } catch (error) { fail('AI background runtime tests', error); }
  for (const testFile of ['domain-utils.cjs','filter-list-updater.cjs','publisher-config.cjs','ai-content-detector.cjs','growth-engine.cjs','non-ai-foundation.cjs','ai-provider.cjs','public-ai-ready.cjs']) {
    try { const output = execFileSync(process.execPath, [path.join(ROOT, 'tests', testFile)], { encoding: 'utf8', timeout: 15000 }); process.stdout.write(output); report.push(`PASS  ${testFile} focused regression suite`); } catch (error) { fail(`${testFile} regression tests`, error); }
  }
  try { const output = execFileSync(process.execPath, [path.join(ROOT, 'tests/distraction-guard.cjs')], { encoding: 'utf8', timeout: 10000 }); process.stdout.write(output); report.push('PASS  Distraction/protection runtime integration: timed guard, reminders, explicit-block precedence, community filter refresh/rejection and last-known-good retention'); } catch (error) { fail('distraction guard runtime tests', error); }
  const releaseVersion = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8')).version;
  const result = `\nDigital Greenhouse ${releaseVersion} — Public AI Connection Readiness Verification\nDate: ${new Date().toISOString()}\n${report.join('\n')}\n\nNOT RUN  Live interactive Chrome acceptance: this environment did not verify every page interaction or host-specific Chrome permission state.\nNOT RUN  Live OISD list download: runtime tests used mocked approved-source responses because public network/DNS access was unavailable in this build environment; the extension reports failures and keeps the fallback cache.\nNOT RUN  Real Qwen/hosted-provider response quality and timing: mocked provider responses verify integration flow, not advice quality or this PC's performance.\nNOT RUN  Windows sign-in helper runtime: PowerShell/Windows Script Host are unavailable in this Linux environment.\n`;
  fs.writeFileSync(path.join(ROOT, 'TEST-RESULTS.txt'), result, 'utf8');
  if (!process.exitCode) console.log(result);
})();

