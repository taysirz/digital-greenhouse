'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const ROOT = path.resolve(__dirname, '..');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-publisher-config-'));
try {
  for (const file of ['service-config.js','configure-publisher.cjs']) fs.copyFileSync(path.join(ROOT,file), path.join(temp,file));
  const script = path.join(temp,'configure-publisher.cjs'), config = path.join(temp,'service-config.js');
  const missing = spawnSync(process.execPath,[script],{encoding:'utf8'});
  assert.notEqual(missing.status,0,'Publisher script must require a URL');
  const unsafe = spawnSync(process.execPath,[script,'http://remote.example.org'],{encoding:'utf8'});
  assert.notEqual(unsafe.status,0,'Publisher script must reject unencrypted remote services');
  assert.match(fs.readFileSync(config,'utf8'),/const apiBaseUrl = '';\s*\/\/ Publisher:/,'Rejected input must not alter the service config');
  const valid = spawnSync(process.execPath,[script,'https://dg-greenhouse-service.net'],{encoding:'utf8'});
  assert.equal(valid.status,0,valid.stderr||valid.stdout);
  assert.match(fs.readFileSync(config,'utf8'),/const apiBaseUrl = "https:\/\/dg-greenhouse-service\.net";/);
  console.log('PASS  Publisher setup: validates HTTPS origin, rejects unencrypted hosts, and changes only the hosted service URL');
} finally { fs.rmSync(temp,{recursive:true,force:true}); }
