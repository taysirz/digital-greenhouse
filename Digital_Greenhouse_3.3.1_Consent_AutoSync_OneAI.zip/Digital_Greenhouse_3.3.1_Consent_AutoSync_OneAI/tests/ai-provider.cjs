const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const net = require('node:net');
const http = require('node:http');
const { spawn } = require('node:child_process');
const root = path.resolve(__dirname, '..');

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close(error => error ? reject(error) : resolve(port));
    });
  });
}
async function waitForHealth(base, child, getLogs) {
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`Backend exited early: ${getLogs()}`);
    try { const response = await fetch(`${base}/health`); if (response.ok) return response.json(); } catch {}
    await new Promise(resolve => setTimeout(resolve, 70));
  }
  throw new Error(`Backend did not become healthy: ${getLogs()}`);
}
function mockOutput(messages) {
  const system = String(messages?.[0]?.content || '');
  if ((system.includes('You classify whether a webpage supports this person') || system.includes('You classify whether a webpage supports this person'))) return { category: 'productive', confidence: 0.82, pageKind: 'lesson', topicHints: ['learning'], rationale: 'Contains lesson headings and practice material.' };
  if (system.includes('adaptive daily planning brain')) return { summary: 'A balanced local plan', objectives: [
    { label: 'Study one priority', type: 'studying', targetMinutes: 25 },
    { label: 'Move or get outside', type: 'exercise', targetMinutes: 15 },
    { label: 'Make time for rest', type: 'rest', targetMinutes: 20 }
  ], strategy: 'Start with one small step.', focusMinutes: 25 };
  if (system.includes('adaptive reasoning engine')) return { action: 'nudge', title: 'A small check-in', message: 'Choose one small next step.', focusMinutes: 25, confidence: 0.7, reason: 'Mock response for provider integration.' };
  return 'A local-first coaching reply: choose one small improvement and make the first step easy.';
}
async function startBackend({ providerPort, dbPath, env, preloadPath, logPath }) {
  const port = providerPort || await freePort();
  let output = '';
  const childEnv = { ...process.env, PORT: String(port), HOST: '127.0.0.1', DG_DB_PATH: dbPath, ...env };
  if (preloadPath) childEnv.NODE_OPTIONS = `${process.env.NODE_OPTIONS || ''} --require="${preloadPath}"`.trim();
  if (logPath) childEnv.DG_TEST_CLOUD_LOG_PATH = logPath;
  const child = spawn(process.execPath, [path.join(root, 'server/server.js')], { cwd: path.join(root, 'server'), env: childEnv, stdio: ['ignore','pipe','pipe'] });
  child.stdout.on('data', chunk => { output += chunk.toString(); });
  child.stderr.on('data', chunk => { output += chunk.toString(); });
  const base = `http://127.0.0.1:${port}`;
  try { const health = await waitForHealth(base, child, () => output); return { child, base, health, getLogs: () => output }; }
  catch (error) { child.kill('SIGTERM'); throw error; }
}
async function stopBackend(child) {
  if (!child || child.exitCode !== null) return;
  child.kill('SIGTERM');
  await new Promise(resolve => { if (child.exitCode !== null) return resolve(); child.once('exit', resolve); setTimeout(resolve, 800).unref(); });
}
function listenLocalOllama({ delayMs = 0 } = {}) {
  const requests = [];
  let activeRequests = 0;
  let maxConcurrent = 0;
  const server = http.createServer(async (req, res) => {
    let raw = '';
    for await (const chunk of req) raw += chunk.toString();
    let body = {}; try { body = JSON.parse(raw || '{}'); } catch {}
    if (req.method === 'GET' && req.url === '/api/tags') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ models: [{ name: 'qwen2.5:3b', model: 'qwen2.5:3b', size: 1900000000 }] }));
      return;
    }
    if (req.method === 'POST' && req.url === '/api/chat') {
      requests.push(body);
      activeRequests += 1;
      maxConcurrent = Math.max(maxConcurrent, activeRequests);
      if (delayMs) await new Promise(resolve => setTimeout(resolve, delayMs));
      const answer = mockOutput(body.messages);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ model: body.model || 'qwen2.5:3b', message: { content: typeof answer === 'string' ? answer : JSON.stringify(answer) } }));
      activeRequests -= 1;
      return;
    }
    res.writeHead(404, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: 'not found' }));
  });
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => resolve({ server, port: server.address().port, requests, get maxConcurrent() { return maxConcurrent; } }));
  });
}
function makeCloudMock(logPath) {
  return `
    const fs = require('node:fs');
    const originalFetch = globalThis.fetch;
    globalThis.fetch = async (input, init = {}) => {
      const url = typeof input === 'string' ? input : input && input.url;
      if (url === 'https://ollama.com/api/chat') {
        let request = {}; try { request = JSON.parse(String(init.body || '{}')); } catch {}
        fs.appendFileSync(process.env.DG_TEST_CLOUD_LOG_PATH, JSON.stringify({model:request.model,system:request.messages?.[0]?.content||''}) + '\\n');
        const system = String(request.messages?.[0]?.content || '');
        let answer;
        if (system.includes('adaptive daily planning brain')) answer = {summary:'Cloud fallback plan',objectives:[{label:'Study one priority',type:'studying',targetMinutes:25},{label:'Move',type:'exercise',targetMinutes:15},{label:'Rest',type:'rest',targetMinutes:20}],strategy:'A small step is enough.',focusMinutes:25};
        else if (system.includes('adaptive reasoning engine')) answer = {action:'nudge',title:'Cloud check-in',message:'Choose one step.',focusMinutes:25,confidence:0.7,reason:'Mock cloud fallback.'};
        else answer = 'Mock cloud fallback reply.';
        return new Response(JSON.stringify({model:request.model||'mock-cloud',message:{content:typeof answer==='string'?answer:JSON.stringify(answer)}}),{status:200,headers:{'Content-Type':'application/json'}});
      }
      return originalFetch(input, init);
    };
  `;
}

function makeGroqMock() {
  return `
    const fs = require('node:fs');
    const originalFetch = globalThis.fetch;
    globalThis.fetch = async (input, init = {}) => {
      const url = typeof input === 'string' ? input : input && input.url;
      if (url === 'https://api.groq.com/openai/v1/chat/completions') {
        let request = {}; try { request = JSON.parse(String(init.body || '{}')); } catch {}
        const headers = init.headers || {};
        const auth = headers.Authorization || headers.authorization || '';
        fs.appendFileSync(process.env.DG_TEST_CLOUD_LOG_PATH, JSON.stringify({
          model: request.model, system: request.messages?.[0]?.content || '',
          authorizationPresent: /^Bearer\\s+/.test(String(auth)), authorizationValue: String(auth),
          payload: request, url
        }) + '\\n');
        const system = String(request.messages?.[0]?.content || '');
        let answer;
        if (system.includes('adaptive daily planning brain')) answer = {
          summary: 'Groq mock plan', objectives: [
            {label:'Study one priority',type:'studying',targetMinutes:25},
            {label:'Move or get outside',type:'exercise',targetMinutes:15},
            {label:'Make room for recovery',type:'rest',targetMinutes:20}
          ], strategy:'Start with one achievable task.', focusMinutes:25
        };
        else if (system.includes('adaptive reasoning engine')) answer = {
          action:'nudge',title:'Groq mock check-in',message:'Pick one small next step.',
          focusMinutes:25,confidence:0.7,reason:'Mock Groq provider response.'
        };
        else answer = 'Mock Groq fallback reply.';
        return new Response(JSON.stringify({
          model: request.model || 'mock-groq',
          choices: [{ message: { role: 'assistant', content: typeof answer === 'string' ? answer : JSON.stringify(answer) } }]
        }), {status:200,headers:{'Content-Type':'application/json'}});
      }
      return originalFetch(input, init);
    };
  `;
}

(async () => {
  const globalConsent = { dataConsentVersion: 5, dataConsentAt: new Date(Date.now() - 1000).toISOString() };
  const tempFiles = [];
  let localOllama, localBackend, fallbackBackend, cloudPrimaryBackend, groqBackend, hybridBackend;
  try {
    localOllama = await listenLocalOllama({ delayMs: 90 });
    const localDb = path.join(os.tmpdir(), `dg-local-ai-${process.pid}-${Date.now()}.json`); tempFiles.push(localDb, `${localDb}.tmp`);
    localBackend = await startBackend({ dbPath: localDb, env: {
      AI_PROVIDER: 'local', LOCAL_OLLAMA_URL: `http://127.0.0.1:${localOllama.port}`, LOCAL_OLLAMA_MODEL: 'qwen2.5:3b',
      AI_CLOUD_FALLBACK_ENABLED: 'false', OLLAMA_API_KEY: ''
    } });
    assert.equal(localBackend.health.aiProvider, 'local');
    assert.equal(localBackend.health.localOllamaReachable, true);
    assert.equal(localBackend.health.localModelInstalled, true);
    assert.equal(localBackend.health.aiConfigured, true);
    const noDataConsent = await fetch(`${localBackend.base}/v1/coach`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({mode:'routine',prompt:'Should not reach the model.'}) });
    assert.equal(noDataConsent.status, 403, 'Coach must stay locked until the single Setup data consent is accepted');
    assert.equal(localOllama.requests.length, 0, 'The backend must reject Coach without consent before the local model processes context');

    const coach = await fetch(`${localBackend.base}/v1/coach`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...globalConsent,  mode: 'routine', prompt: 'Help me make a realistic routine.', allowCloudFallback: false }) });
    const coachData = await coach.json();
    assert.equal(coach.status, 200, `Local coach failed: ${JSON.stringify(coachData)}`);
    assert.equal(coachData.provider, 'local');
    assert.equal(coachData.model, 'qwen2.5:3b');
    assert.match(coachData.answer, /local-first/);

    const decision = await fetch(`${localBackend.base}/v1/agent/decision`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...globalConsent,  allowCloudFallback: false, snapshot: { activity: { currentCategory: 'productive' }, focus: { active: false } } }) });
    const decisionData = await decision.json();
    assert.equal(decision.status, 200, `Local decision failed: ${JSON.stringify(decisionData)}`);
    assert.equal(decisionData.provider, 'local');
    assert.equal(decisionData.decision.action, 'nudge');

    const plan = await fetch(`${localBackend.base}/v1/agent/plan`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...globalConsent,  allowCloudFallback: false, tone: 'gentle', snapshot: {} }) });
    const planData = await plan.json();
    assert.equal(plan.status, 200, `Local plan failed: ${JSON.stringify(planData)}`);
    assert.equal(planData.provider, 'local');
    assert.equal(planData.plan.objectives.length, 3);
    const classify = await fetch(`${localBackend.base}/v1/classify`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...globalConsent,  title: 'Lesson: quadratic equations', headings: ['Worked examples', 'Practice questions'], excerpt: 'Explore the method and practise sample problems.', features: { headings: 2, codeBlocks: 0, videos: 0 }, baselineCategory: 'neutral', baselineConfidence: 0.35 }) });
    const classifyData = await classify.json();
    assert.equal(classify.status, 200, `Local page classification failed: ${JSON.stringify(classifyData)}`);
    assert.equal(classifyData.provider, 'local');
    assert.equal(classifyData.category, 'productive');
    assert.equal(classifyData.pageKind, 'lesson');
    assert.equal(classifyData.confidence, 0.82);
    assert.equal(localOllama.requests.length, 4, 'Coach, decision, plan, and page review should use the local Ollama endpoint');
    assert(localOllama.requests.every(request => request.model === 'qwen2.5:3b'));
    assert(!localOllama.requests.some(request => JSON.stringify(request).includes('OLLAMA_API_KEY')));
    const classifyInput = JSON.stringify(localOllama.requests.find(request => String(request.messages?.[0]?.content || '').includes('You classify whether a webpage supports this person')));
    assert(classifyInput.includes('Lesson: quadratic equations'));
    assert(!classifyInput.includes('https://example.com') && !classifyInput.includes('example.com/path'), 'Classifier payload should not require or include a URL');
    const hostileOrigin = await fetch(`${localBackend.base}/v1/classify`, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'https://untrusted.example' }, body: JSON.stringify({ ...globalConsent,  title: 'Blocked request', excerpt: 'Must not reach the model.' }) });
    assert.equal(hostileOrigin.status, 403, 'Page classifier must reject non-extension browser origins');
    assert.equal(localOllama.requests.length, 4, 'Rejected cross-origin page content must never reach local Ollama');

    // Burst across feature calls: local model requests must be serialized, and the bounded queue rejects overflow.
    const burst = await Promise.all(Array.from({ length: 4 }, (_, i) => fetch(`${localBackend.base}/v1/coach`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...globalConsent,  mode: 'routine', prompt: `Concurrent test ${i}`, allowCloudFallback: false })
    })));
    const burstStatuses = burst.map(response => response.status);
    assert.equal(burstStatuses.filter(status => status === 200).length, 3, `Expected one active plus two queued requests: ${burstStatuses.join(', ')}`);
    assert.equal(burstStatuses.filter(status => status === 429).length, 1, `Queue overflow should be rejected safely: ${burstStatuses.join(', ')}`);
    assert.equal(localOllama.maxConcurrent, 1, `Local Ollama received ${localOllama.maxConcurrent} concurrent requests`);
    await stopBackend(localBackend); localBackend = null;

    // Test local failure: cloud is not called without request-level consent, even when fallback is configured.
    const preload = path.join(os.tmpdir(), `dg-ai-cloud-mock-${process.pid}-${Date.now()}.cjs`); tempFiles.push(preload);
    const cloudMockLog = path.join(os.tmpdir(), `dg-ai-cloud-log-${process.pid}-${Date.now()}.jsonl`); tempFiles.push(cloudMockLog);
    fs.writeFileSync(preload, makeCloudMock(cloudMockLog), 'utf8');
    const fallbackDb = path.join(os.tmpdir(), `dg-ai-fallback-${process.pid}-${Date.now()}.json`); tempFiles.push(fallbackDb, `${fallbackDb}.tmp`);
    fallbackBackend = await startBackend({ dbPath: fallbackDb, preloadPath: preload, logPath: cloudMockLog, env: {
      AI_PROVIDER: 'local', LOCAL_OLLAMA_URL: 'http://127.0.0.1:1', LOCAL_OLLAMA_MODEL: 'qwen2.5:3b',
      AI_CLOUD_FALLBACK_ENABLED: 'true', OLLAMA_API_KEY: 'mock-only-key', OLLAMA_CLOUD_MODEL: 'mock-cloud'
    } });
    const noConsent = await fetch(`${fallbackBackend.base}/v1/coach`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...globalConsent,  mode: 'routine', prompt: 'Help me focus.', allowCloudFallback: false }) });
    assert.equal(noConsent.status, 503, 'Offline local model should report its error when cloud fallback has no per-request consent');
    assert(!fs.existsSync(cloudMockLog) || fs.readFileSync(cloudMockLog, 'utf8').trim() === '', 'Cloud must not be called without request-level consent');
    const classifyNoCloud = await fetch(`${fallbackBackend.base}/v1/classify`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...globalConsent,  title: 'Unclear page', headings: ['General information'], excerpt: 'A small sample.', baselineCategory: 'neutral', baselineConfidence: 0.35 }) });
    assert.equal(classifyNoCloud.status, 503, 'Page classification should fail closed when local Ollama is unavailable');
    assert(!fs.existsSync(cloudMockLog) || fs.readFileSync(cloudMockLog, 'utf8').trim() === '', 'Page classification must never use cloud fallback, even when the fallback setting is enabled');
    const withConsent = await fetch(`${fallbackBackend.base}/v1/coach`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...globalConsent,  mode: 'routine', prompt: 'Help me focus.', allowCloudFallback: true }) });
    const fallbackData = await withConsent.json();
    assert.equal(withConsent.status, 200, `Consented cloud fallback failed: ${JSON.stringify(fallbackData)}`);
    assert.equal(fallbackData.provider, 'cloud');
    assert.equal(fallbackData.fallbackUsed, true);
    assert.match(fallbackData.answer, /cloud fallback/i);
    assert(fs.readFileSync(cloudMockLog, 'utf8').includes('mock-cloud'), 'Expected fallback model call was not observed');
    await stopBackend(fallbackBackend); fallbackBackend = null;

    // Direct cloud mode is also gated by request consent.
    const cloudDb = path.join(os.tmpdir(), `dg-ai-cloud-primary-${process.pid}-${Date.now()}.json`); tempFiles.push(cloudDb, `${cloudDb}.tmp`);
    cloudPrimaryBackend = await startBackend({ dbPath: cloudDb, preloadPath: preload, logPath: cloudMockLog, env: {
      AI_PROVIDER: 'cloud', AI_CLOUD_FALLBACK_ENABLED: 'false', OLLAMA_API_KEY: 'mock-only-key', OLLAMA_CLOUD_MODEL: 'mock-cloud'
    } });
    const primaryNoConsent = await fetch(`${cloudPrimaryBackend.base}/v1/coach`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...globalConsent,  mode: 'routine', prompt: 'Help me focus.', allowCloudFallback: false }) });
    assert.equal(primaryNoConsent.status, 403, 'Cloud-primary mode must require per-request consent');
    const primaryConsent = await fetch(`${cloudPrimaryBackend.base}/v1/coach`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...globalConsent,  mode: 'routine', prompt: 'Help me focus.', allowCloudFallback: true }) });
    const primaryData = await primaryConsent.json();
    assert.equal(primaryConsent.status, 200);
    assert.equal(primaryData.provider, 'cloud');
    assert.equal(primaryData.fallbackUsed, false, 'Cloud primary use is not reported as fallback');
    await stopBackend(cloudPrimaryBackend); cloudPrimaryBackend = null;

    // Groq adapter: OpenAI-compatible request, key only in Authorization header, JSON mode, local-first consent gate.
    const groqPreload = path.join(os.tmpdir(), `dg-ai-groq-mock-${process.pid}-${Date.now()}.cjs`); tempFiles.push(groqPreload);
    const groqLog = path.join(os.tmpdir(), `dg-ai-groq-log-${process.pid}-${Date.now()}.jsonl`); tempFiles.push(groqLog);
    fs.writeFileSync(groqPreload, makeGroqMock(), 'utf8');
    const groqDb = path.join(os.tmpdir(), `dg-ai-groq-${process.pid}-${Date.now()}.json`); tempFiles.push(groqDb, `${groqDb}.tmp`);
    groqBackend = await startBackend({ dbPath: groqDb, preloadPath: groqPreload, logPath: groqLog, env: {
      AI_PROVIDER: 'local', LOCAL_OLLAMA_URL: 'http://127.0.0.1:1', LOCAL_OLLAMA_MODEL: 'qwen2.5:3b',
      AI_CLOUD_FALLBACK_ENABLED: 'true', CLOUD_AI_PROVIDER: 'groq', GROQ_API_KEY: 'mock-only-groq-key', GROQ_MODEL: 'mock-groq-model', OLLAMA_API_KEY: ''
    } });
    assert.equal(groqBackend.health.cloudProvider, 'groq');
    assert.equal(groqBackend.health.cloudModel, 'mock-groq-model');
    assert.equal(groqBackend.health.cloudConfigured, true);
    assert.equal(groqBackend.health.cloudFallbackEnabled, true);
    const groqNoConsent = await fetch(`${groqBackend.base}/v1/coach`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ...globalConsent, mode:'routine',prompt:'Test private routing.',allowCloudFallback:false}) });
    assert.equal(groqNoConsent.status, 503, 'Local failure should be surfaced if user did not consent to cloud');
    assert(!fs.existsSync(groqLog) || !fs.readFileSync(groqLog,'utf8').trim(), 'Groq must not be contacted without request consent');
    const groqClassify = await fetch(`${groqBackend.base}/v1/classify`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ...globalConsent, title:'Ambiguous page',headings:['Information'],excerpt:'Short sample.',baselineCategory:'neutral',baselineConfidence:0.3}) });
    assert.equal(groqClassify.status, 503, 'Page classification must remain local-only even with Groq enabled');
    assert(!fs.existsSync(groqLog) || !fs.readFileSync(groqLog,'utf8').trim(), 'Page classification must never call Groq');
    const groqPlan = await fetch(`${groqBackend.base}/v1/agent/plan`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ...globalConsent, allowCloudFallback:true,tone:'gentle',snapshot:{}}) });
    const groqPlanData = await groqPlan.json();
    assert.equal(groqPlan.status, 200, `Groq fallback plan failed: ${JSON.stringify(groqPlanData)}`);
    assert.equal(groqPlanData.provider, 'cloud');
    assert.equal(groqPlanData.fallbackUsed, true);
    assert.equal(groqPlanData.model, 'mock-groq-model');
    assert.equal(groqPlanData.plan.objectives.length, 3);
    const groqRecord = JSON.parse(fs.readFileSync(groqLog,'utf8').trim().split('\n')[0]);
    assert.equal(groqRecord.url, 'https://api.groq.com/openai/v1/chat/completions');
    assert.equal(groqRecord.model, 'mock-groq-model');
    assert.equal(groqRecord.authorizationPresent, true);
    assert.equal(groqRecord.authorizationValue, 'Bearer mock-only-groq-key');
    assert.deepEqual(groqRecord.payload.response_format, {type:'json_object'});
    assert.equal(groqRecord.payload.max_completion_tokens, 500);
    assert.equal('options' in groqRecord.payload, false, 'Groq payload must not contain Ollama-only options');
    assert(!JSON.stringify(groqRecord.payload).includes('mock-only-groq-key'), 'The API key must never enter request JSON');
    await stopBackend(groqBackend); groqBackend = null;

    // Hybrid router: simple tasks use local Qwen even with cloud consent; genuinely complex advice
    // prefers Groq only when the request consents, with the key kept server-side.
    fs.writeFileSync(groqLog, '', 'utf8');
    const hybridDb = path.join(os.tmpdir(), `dg-ai-hybrid-${process.pid}-${Date.now()}.json`); tempFiles.push(hybridDb, `${hybridDb}.tmp`);
    hybridBackend = await startBackend({ dbPath: hybridDb, preloadPath: groqPreload, logPath: groqLog, env: {
      AI_PROVIDER: 'hybrid', LOCAL_OLLAMA_URL: `http://127.0.0.1:${localOllama.port}`, LOCAL_OLLAMA_MODEL: 'qwen2.5:3b',
      AI_CLOUD_FALLBACK_ENABLED: 'true', CLOUD_AI_PROVIDER: 'groq', GROQ_API_KEY: 'mock-only-groq-key', GROQ_MODEL: 'mock-groq-model'
    } });
    assert.equal(hybridBackend.health.aiProvider, 'hybrid');
    const simpleHybrid = await fetch(`${hybridBackend.base}/v1/coach`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ...globalConsent, mode:'routine',prompt:'Give me one small hydration reminder.',allowCloudFallback:true}) });
    const simpleHybridData = await simpleHybrid.json();
    assert.equal(simpleHybrid.status, 200);
    assert.equal(simpleHybridData.provider, 'local', 'Simple coaching should remain on local Qwen');
    assert.equal(simpleHybridData.routingReason, 'simple-task-local-route');
    assert(!fs.existsSync(groqLog) || !fs.readFileSync(groqLog,'utf8').trim(), 'Simple tasks must not call Groq even when consent is available');
    const richPlan = await fetch(`${hybridBackend.base}/v1/agent/plan`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ...globalConsent, allowCloudFallback:true,tone:'gentle',snapshot:{activity:{activeDays7d:6,productiveTrendPct:24,distractingTrendPct:18},memory:{totalFeedback:12},learning:{classifierEvidence:{recentPageSamples:18}},lifePattern:{last7Days:{completed:8},previous7Days:{completed:6}},focus:{sessions7d:4}}}) });
    const richPlanData = await richPlan.json();
    assert.equal(richPlan.status, 200, `Rich-history hybrid plan failed: ${JSON.stringify(richPlanData)}`);
    assert.equal(richPlanData.provider, 'cloud', 'Data-rich, multi-signal plans should route to Groq with request consent');
    const hardHybrid = await fetch(`${hybridBackend.base}/v1/coach`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ...globalConsent, mode:'routine',prompt:'Please compare several different routine alternatives, analyze their trade-offs and constraints, evaluate which strategy is best long-term, and build a comprehensive step-by-step plan that balances studying, exercise, recovery and my other priorities.',allowCloudFallback:true}) });
    const hardHybridData = await hardHybrid.json();
    assert.equal(hardHybrid.status, 200, `Complex hybrid coaching failed: ${JSON.stringify(hardHybridData)}`);
    assert.equal(hardHybridData.provider, 'cloud', 'Complex advice should route to configured Groq when request-level consent exists');
    assert.equal(hardHybridData.routingReason, 'complex-task-cloud-route');
    assert.equal(hardHybridData.fallbackUsed, false, 'Intentional hybrid cloud routing is not misreported as an error fallback');
    assert(fs.readFileSync(groqLog,'utf8').includes('mock-groq-model'), 'Complex request should reach the mocked Groq endpoint');
    const deniedComplex = await fetch(`${hybridBackend.base}/v1/coach`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ...globalConsent, mode:'routine',prompt:'Please compare several different routine alternatives, analyze their trade-offs and constraints, evaluate which strategy is best long-term, and build a comprehensive step-by-step plan that balances studying, exercise, recovery and my other priorities.',allowCloudFallback:false}) });
    const deniedComplexData = await deniedComplex.json();
    assert.equal(deniedComplex.status, 200);
    assert.equal(deniedComplexData.provider, 'local', 'Complex tasks must stay local when cloud consent is absent');
    await stopBackend(hybridBackend); hybridBackend = null;

    console.log('PASS  AI provider integration: local Qwen routing, consent-gated complexity routing to Groq, local recovery/fallback, local-only page classification, bounded inference queue, server-only secrets, JSON normalization, and provider-primary consent gates');
  } catch (error) {
    console.error(error.stack || error);
    process.exitCode = 1;
  } finally {
    await stopBackend(localBackend); await stopBackend(fallbackBackend); await stopBackend(cloudPrimaryBackend); await stopBackend(groqBackend); await stopBackend(hybridBackend);
    if (localOllama?.server) { localOllama.server.closeAllConnections?.(); await new Promise(resolve => localOllama.server.close(resolve)); }
    for (const file of tempFiles) { try { fs.unlinkSync(file); } catch {} }
  }
})().finally(() => process.exit(process.exitCode || 0));
