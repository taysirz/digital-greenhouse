'use strict';
// Integration tests for public-mode auth, safe health response, hosted consent and token minting.
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const vm = require('node:vm');
const { spawn, spawnSync } = require('node:child_process');

const ROOT = path.resolve(__dirname, '..');
const SERVER_DIR = path.join(ROOT, 'server');
const secret = crypto.randomBytes(48).toString('base64url');
const adminToken = crypto.randomBytes(48).toString('base64url');
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-public-ai-test-'));
const dbPath = path.join(tempDir, 'data-store.json');
const mockCloudLog = path.join(tempDir, 'mock-cloud.log');
const mockCloudPreload = path.join(tempDir, 'mock-cloud-fetch.cjs');
fs.writeFileSync(mockCloudPreload, String.raw`
const fs = require('node:fs');
const originalFetch = globalThis.fetch;
globalThis.fetch = async (input, init = {}) => {
  const url = typeof input === 'string' ? input : input && input.url;
  if (url === 'https://ollama.com/api/chat') {
    let request = {}; try { request = JSON.parse(String(init.body || '{}')); } catch {}
    fs.appendFileSync(process.env.DG_TEST_CLOUD_LOG_PATH, JSON.stringify({model:request.model, system:request.messages?.[0]?.content || ''}) + '\\n');
    return new Response(JSON.stringify({model:request.model || 'mock-hosted-model', message:{content:'Mock hosted AI response: Greenhouse AI is responding.'}}), {status:200, headers:{'Content-Type':'application/json'}});
  }
  return originalFetch(input, init);
};
`);


function freePort() {
  return new Promise((resolve, reject) => {
    const probe = net.createServer();
    probe.once('error', reject);
    probe.listen(0, '127.0.0.1', () => {
      const port = probe.address().port;
      probe.close(error => error ? reject(error) : resolve(port));
    });
  });
}
function makeToken(subject = 'test-user', days = 7) {
  const now = Math.floor(Date.now() / 1000);
  const payload = Buffer.from(JSON.stringify({
    iss: 'digital-greenhouse', aud: 'dg-public-api', sub: subject,
    iat: now, exp: now + days * 86400, jti: crypto.randomBytes(12).toString('hex')
  })).toString('base64url');
  return `${payload}.${crypto.createHmac('sha256', secret).update(payload).digest('base64url')}`;
}
async function readJson(response) {
  return response.json().catch(() => ({}));
}
async function waitForHealth(url, child) {
  const end = Date.now() + 8000;
  let lastError;
  while (Date.now() < end) {
    if (child.exitCode !== null) throw new Error(`Public server exited early (${child.exitCode}).`);
    try {
      const response = await fetch(`${url}/health`, { signal: AbortSignal.timeout(800) });
      if (response.ok) return readJson(response);
    } catch (error) { lastError = error; }
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error(`Public server did not start: ${lastError?.message || 'health timeout'}`);
}
(async () => {
  let child;
  try {
    const captured = [];
    const clientSandbox = {
      URL,
      fetch: async (url, options) => { captured.push({ url, options }); return { ok: true, status: 200 }; },
      chrome: { storage: { local: { get: async () => ({ dgState: {} }) } } }
    };
    vm.createContext(clientSandbox);
    vm.runInContext(fs.readFileSync(path.join(ROOT, 'ai-client.js'), 'utf8'), clientSandbox);
    assert.equal(clientSandbox.DGAI.cleanEndpoint('https://greenhouse.example'), 'https://greenhouse.example');
    assert.equal(clientSandbox.DGAI.cleanEndpoint('http://127.0.0.1:8787'), 'http://127.0.0.1:8787');
    assert.throws(() => clientSandbox.DGAI.cleanEndpoint('http://greenhouse.example'), /must use HTTPS/i);
    assert.throws(() => clientSandbox.DGAI.cleanEndpoint('https://greenhouse.example/api'), /origin only/i);
    assert.throws(() => clientSandbox.DGAI.cleanEndpoint('https://user:pass@greenhouse.example'), /origin only/i);
    const clientState = { profile: { dataCollection: { endpoint: 'https://greenhouse.example' } }, aiCompanion: { serviceAccessToken: 'private-user-token' } };
    await clientSandbox.DGAI.request('/v1/coach', { method: 'POST', body: '{"prompt":"test"}' }, clientState);
    assert.equal(captured[0].url, 'https://greenhouse.example/v1/coach');
    assert.equal(captured[0].options.headers.Authorization, 'Bearer private-user-token');
    assert.equal(captured[0].options.body, '{"prompt":"test"}');
    console.log('PASS  Shared extension AI client uses the configured HTTPS origin and sends the user token only in the Authorization header');

    const localEnvPath = path.join(tempDir, 'local.env');
    fs.writeFileSync(localEnvPath, 'HOST=127.0.0.1\nDG_PUBLIC_MODE=false\n');
    const localGuard = spawnSync(process.execPath, [path.join(SERVER_DIR, 'check-local-mode.cjs'), localEnvPath], { encoding: 'utf8', timeout: 3000 });
    assert.equal(localGuard.status, 0, localGuard.stderr);
    fs.writeFileSync(localEnvPath, 'HOST=0.0.0.0\nDG_PUBLIC_MODE=true\n');
    const publicGuard = spawnSync(process.execPath, [path.join(SERVER_DIR, 'check-local-mode.cjs'), localEnvPath], { encoding: 'utf8', timeout: 3000 });
    assert.notEqual(publicGuard.status, 0, 'Personal Windows launchers must refuse public mode or non-loopback binds');
    assert.match(publicGuard.stderr, /refuses public mode or non-loopback HOST/i);
    console.log('PASS  Personal-use launch guard refuses a hosted/network-bound config');

    const noSecret = spawnSync(process.execPath, [path.join(SERVER_DIR, 'server.js')], {
      encoding: 'utf8', timeout: 2500,
      env: { ...process.env, DG_PUBLIC_MODE: 'true', DG_TOKEN_SECRET: 'REPLACE_WITH_SECRET', HOST: '127.0.0.1', PORT: '0', DG_DB_PATH: dbPath }
    });
    assert.notEqual(noSecret.status, 0, 'Public mode must refuse to start with a placeholder signing secret');
    assert.match(`${noSecret.stdout}\n${noSecret.stderr}`, /DG_PUBLIC_MODE requires a private random DG_TOKEN_SECRET/i);
    console.log('PASS  Public server refuses placeholder or weak signing secrets');

    const placeholderPort = await freePort();
    const placeholderChild = spawn(process.execPath, [path.join(SERVER_DIR, 'server.js')], {
      cwd: SERVER_DIR, stdio: ['ignore', 'ignore', 'ignore'],
      env: { ...process.env, DG_PUBLIC_MODE: 'true', DG_TOKEN_SECRET: secret, HOST: '127.0.0.1', PORT: String(placeholderPort), DG_DB_PATH: path.join(tempDir, 'placeholder-store.json'), AI_PROVIDER: 'cloud', CLOUD_AI_PROVIDER: 'ollama', OLLAMA_API_KEY: 'REPLACE_WITH_YOUR_PRIVATE_OLLAMA_CLOUD_KEY' }
    });
    try {
      const placeholderHealth = await waitForHealth(`http://127.0.0.1:${placeholderPort}`, placeholderChild);
      assert.equal(placeholderHealth.aiConfigured, false, 'A template placeholder must not masquerade as a configured provider key');
      console.log('PASS  Health correctly reports placeholder provider keys as unconfigured');
    } finally {
      if (placeholderChild.exitCode === null) { placeholderChild.kill('SIGTERM'); await new Promise(resolve => placeholderChild.once('exit', resolve)); }
    }

    const port = await freePort();
    const base = `http://127.0.0.1:${port}`;
    child = spawn(process.execPath, [path.join(SERVER_DIR, 'server.js')], {
      cwd: SERVER_DIR,
      env: {
        ...process.env,
        DG_PUBLIC_MODE: 'true', DG_TOKEN_SECRET: secret, DG_OWNER_ADMIN_TOKEN: adminToken,
        DG_PUBLIC_AI_PER_MINUTE_LIMIT: '6', DG_PUBLIC_AI_PER_DAY_LIMIT: '80',
        HOST: '127.0.0.1', PORT: String(port), DG_DB_PATH: dbPath,
        AI_PROVIDER: 'cloud', CLOUD_AI_PROVIDER: 'ollama', OLLAMA_API_KEY: 'test-only-not-a-real-key',
        DG_TEST_CLOUD_LOG_PATH: mockCloudLog, NODE_OPTIONS: [process.env.NODE_OPTIONS, `--require=${mockCloudPreload}`].filter(Boolean).join(' '),
        DG_ALLOWED_ORIGINS: 'chrome-extension://*'
      },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let logs = '';
    child.stdout.on('data', data => { logs += data.toString(); });
    child.stderr.on('data', data => { logs += data.toString(); });

    const health = await waitForHealth(base, child);
    assert.equal(health.mode, 'public');
    assert.equal(health.serviceMode, 'public');
    assert.equal(health.requiresAccessToken, true);
    assert.equal(health.aiConfigured, true);
    assert.equal(Object.hasOwn(health, 'localOllamaUrl'), false, 'Public health must not disclose local model/service details');
    assert.equal(Object.hasOwn(health, 'localOllamaModel'), false);
    assert.equal(Object.hasOwn(health, 'apiKey'), false);
    console.log('PASS  Public health exposes connection status without revealing local service details or provider secrets');

    const missingCoach = await fetch(`${base}/v1/coach`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: 'Help me make a plan' }) });
    assert.equal(missingCoach.status, 401);
    const missingIngest = await fetch(`${base}/v1/ingest`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    assert.equal(missingIngest.status, 401);
    const invalid = await fetch(`${base}/v1/coach`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer not-a-valid-token' }, body: '{}' });
    assert.equal(invalid.status, 401);
    console.log('PASS  Hosted AI and dataset ingestion reject missing and forged access tokens');

    const installId = crypto.randomUUID();
    const installToken = `${crypto.randomUUID()}${crypto.randomUUID()}`;
    const consentAt = new Date().toISOString();
    const enrolledResponse = await fetch(`${base}/v1/enroll`, {
      method:'POST',
      headers:{'Content-Type':'application/json','Origin':'chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','X-DG-Install-Id':installId,'X-DG-Install-Token':installToken},
      body:JSON.stringify({schemaVersion:1,consentVersion:5,consentAt})
    });
    const enrolled = await readJson(enrolledResponse);
    assert.equal(enrolledResponse.status,200,`Consent should trigger automatic enrollment: ${JSON.stringify(enrolled)}`);
    assert.equal(enrolled.ok,true); assert.equal(enrolled.requiresAccessToken,true); assert.ok(enrolled.accessToken);
    const token = enrolled.accessToken;
    console.log('PASS  One consented installation automatically enrolls and receives its own expiring service credential');

    // Prove a consented user's request reaches the configured hosted model and comes back successfully.
    // This provider is mocked; it verifies the HTTP integration path, not real-world model quality.
    const realRouteTest = await fetch(`${base}/v1/ai/test`, {
      method:'POST', headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},
      body:JSON.stringify({dataConsentVersion:5,dataConsentAt:consentAt})
    });
    const realRouteJson = await readJson(realRouteTest);
    assert.equal(realRouteTest.status,200,`A consented user should get a real AI-test route response without a second cloud toggle: ${JSON.stringify(realRouteJson)}`);
    assert.match(realRouteJson.reply,/Greenhouse AI is responding/i);
    assert.equal(realRouteJson.provider,'cloud');
    assert(fs.existsSync(mockCloudLog) && fs.readFileSync(mockCloudLog,'utf8').includes('You are testing Digital Greenhouse AI connectivity'), 'AI test should actually call the configured upstream provider route');
    console.log('PASS  The consented public AI test completes end-to-end against a mocked hosted provider without a second cloud-AI flag');

    const classifier = await fetch(`${base}/v1/classify`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ dataConsentVersion: 5, dataConsentAt: consentAt, title: '', headings: [], excerpt: '', allowCloudAI: false })
    });
    assert.equal(classifier.status, 400, 'With active Setup consent, request should pass consent gate and fail only because page context is empty; no second hosted-AI checkbox is required');
    assert.match((await readJson(classifier)).error, /Insufficient page context/i);

    const coach = await fetch(`${base}/v1/coach`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ dataConsentVersion: 5, dataConsentAt: consentAt, prompt: 'a', allowCloudFallback: false })
    });
    assert.equal(coach.status, 400, 'With active Setup consent, request should pass consent gate and fail only for too-short prompt; no second hosted-AI toggle is required');
    assert.match((await readJson(coach)).error, /at least 3 characters/i);
    console.log('PASS  One Setup consent authorizes hosted AI tasks without a separate cloud-AI checkbox');

    const upload = await fetch(`${base}/v1/ingest`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json', Authorization: `Bearer ${token}`,
        'X-DG-Install-Id': installId, 'X-DG-Install-Token': installToken
      },
      body: JSON.stringify({
        schemaVersion: 2, consentVersion: 5, consentAt,
        userData: {
          format: 'digital-greenhouse-user-dataset-v3', exportedAt: consentAt,
          includedStorageKeys: ['dgState'],
          storage: { dgState: { serviceAccessToken: 'should-not-survive-server-sanitizing', aiCompanion: { accessToken: 'also-must-be-removed' }, safeField: 'preserved' } }
        }
      })
    });
    assert.equal(upload.status, 202, `Valid signed access token should permit consented ingestion: ${JSON.stringify(await readJson(upload))}`);
    const remote = await fetch(`${base}/v1/data/${encodeURIComponent(installId)}`, { headers: { 'X-DG-Install-Token': installToken } });
    assert.equal(remote.status, 200);
    const remoteJson = await readJson(remote);
    const remoteSerialized = JSON.stringify(remoteJson);
    assert(!remoteSerialized.includes('should-not-survive-server-sanitizing') && !remoteSerialized.includes('also-must-be-removed'), 'The server must strip access-token fields from stored user datasets');
    assert(remoteSerialized.includes('preserved'), 'The server should retain safe fields within the consented dataset');
    console.log('PASS  Authenticated dataset sync stores the consented snapshot while stripping service-token fields');

    const noOwner = await fetch(`${base}/v1/admin/export`);
    assert.equal(noOwner.status,401,'Central dataset export must not be public');
    const ownerExportResponse = await fetch(`${base}/v1/admin/export`, {headers:{Authorization:`Bearer ${adminToken}`}});
    const ownerExport = await readJson(ownerExportResponse);
    assert.equal(ownerExportResponse.status,200,`Owner should be able to download all consented installations: ${JSON.stringify(ownerExport)}`);
    assert.equal(ownerExport.installationCount,1); assert.equal(ownerExport.snapshotCount,1);
    const ownerText=JSON.stringify(ownerExport);
    assert(ownerText.includes('preserved')); assert(!ownerText.includes('tokenHash') && !ownerText.includes(installToken));
    const ownerPage = await fetch(`${base}/owner-dashboard`);
    assert.equal(ownerPage.status,200); assert.match(await ownerPage.text(),/Download collected data/i);
    console.log('PASS  Private owner dashboard/export returns all consented snapshots without installation authentication secrets');

    const revokeResponse = await fetch(`${base}/v1/revoke`, {
      method:'POST', headers:{'Content-Type':'application/json','X-DG-Install-Id':installId,'X-DG-Install-Token':installToken},
      body:JSON.stringify({consentVersion:5,revokedAt:new Date().toISOString()})
    });
    const revokeJson = await readJson(revokeResponse);
    assert.equal(revokeResponse.status,200,`Unchecking consent should revoke future server collection: ${JSON.stringify(revokeJson)}`);
    assert.equal(revokeJson.consentActive,false);
    const afterRevoke = await fetch(`${base}/v1/coach`, {method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({dataConsentVersion:5,dataConsentAt:consentAt,prompt:'Please help me',allowCloudFallback:true})});
    assert.equal(afterRevoke.status,403,'Revoked consent must block future hosted AI even while a previously issued token is not expired');
    assert.match((await readJson(afterRevoke)).error,/no active current data-sharing consent/i);
    const retainedExport = await readJson(await fetch(`${base}/v1/admin/export`,{headers:{Authorization:`Bearer ${adminToken}`}}));
    assert.equal(retainedExport.snapshotCount,1,'Revocation stops future data flow but leaves prior data stored until deletion is requested');
    console.log('PASS  Consent withdrawal revokes future hosted AI and uploads while retaining prior snapshots until explicit deletion');

    const invalidExpiry = await fetch(`${base}/v1/coach`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${makeToken('expired-user', -1)}` },
      body: JSON.stringify({ prompt: 'Help me' })
    });
    assert.equal(invalidExpiry.status, 401);
    console.log('PASS  Expired tokens are rejected');

    // Check the actual trusted token issuer using the same environment variable contract as deployment.
    const issued = spawnSync(process.execPath, ['issue-access-token.cjs', 'test-user', '7'], {
      cwd: SERVER_DIR, encoding: 'utf8', timeout: 4000,
      env: { ...process.env, DG_TOKEN_SECRET: secret }
    });
    assert.equal(issued.status, 0, issued.stderr || issued.stdout);
    const issuedToken = issued.stdout.split('\n').map(line => line.trim()).find(line => /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(line));
    assert.ok(issuedToken, 'Token issuer should output one signed, expiring token');
    assert.equal((await fetch(`${base}/v1/coach`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${issuedToken}` },
      body: JSON.stringify({ dataConsentVersion: 5, dataConsentAt: consentAt, prompt: 'Help me make a plan', allowCloudFallback: false })
    })).status, 403, 'The issued token must pass authentication then stop at the single-choice consent gate');
    console.log('PASS  Admin token issuer creates a server-verifiable expiring access token');
  } catch (error) {
    console.error(`FAIL  Public AI connection tests\n${error?.stack || error}`);
    if (child && child.exitCode !== null) console.error(`Public server log:\n${childLog(child)}`);
    process.exitCode = 1;
  } finally {
    if (child && child.exitCode === null) { child.kill('SIGTERM'); await new Promise(resolve => child.once('exit', resolve)); }
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}
  }
})();
function childLog(child) { return `[pid=${child.pid}]`; }
