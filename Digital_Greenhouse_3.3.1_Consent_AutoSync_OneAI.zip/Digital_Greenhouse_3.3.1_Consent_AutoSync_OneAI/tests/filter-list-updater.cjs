'use strict';
const assert = require('node:assert/strict');
const filters = require('../filter-list-updater.js');
const parsed = filters.parseDomainList(`
# hosts-style and domain-list parsing
0.0.0.0 ads.example.com tracker.example.net # inline comment
127.0.0.1 metrics.example.org
||doubleclick.example^
||optioned.example^$third-party,script
plain.example.com
*.wildcard.example
@@||allow.example^
||path.example.com/path^
/a-regex-pattern/
127.0.0.1 localhost
0.0.0.0 bad..domain.com
http://not-a-domain.example/path
`);
assert.deepEqual(new Set(parsed), new Set([
  'ads.example.com','tracker.example.net','metrics.example.org','doubleclick.example','optioned.example','plain.example.com','wildcard.example'
]));
assert.equal(filters.AD_LIST_URL, 'https://small.oisd.nl/domainswild2');
assert.equal(filters.ADULT_LIST_URL, 'https://nsfw-small.oisd.nl/domainswild2');
assert.equal(filters.parseDomainList('oops\n<div>not a list</div>').length, 0);
assert.throws(() => filters.parseDomainList('x'.repeat(8*1024*1024+1)), /8 MiB/);
const spread = filters.boundedSpread(Array.from({length:100},(_,i)=>`d${i}.example`),10);
assert.equal(spread.length,10);
assert.equal(spread[0],'d0.example');
assert.equal(spread[9],'d99.example');
const rules = filters.buildRules({adDomains:['ads.example.com'],adultDomains:['adult.example.com'],adEnabled:true,adultEnabled:true,blockedPagePath:'/blocked.html?reason=adult-community'});
assert.equal(rules.length,2);
const adult = rules.find(r=>r.id>=filters.ADULT_ID_START&&r.id<filters.AD_ID_START);
const ad = rules.find(r=>r.id>=filters.AD_ID_START);
assert.equal(adult.action.type,'redirect');
assert.equal(adult.priority,400,'community adult protection must not be bypassed by low-priority temporary overrides');
assert.deepEqual(adult.condition.resourceTypes,['main_frame']);
assert.equal(ad.action.type,'block');
assert.equal(ad.condition.domainType,'thirdParty');
assert(!ad.condition.resourceTypes.includes('main_frame'),'ad list must not block navigation to the listed host itself');
assert.equal(filters.buildRules({communityEnabled:false,adEnabled:true,adultEnabled:true,adDomains:['ads.example.com'],adultDomains:['adult.example.com']}).length,0);
assert.equal(filters.buildRules({communityEnabled:true,adEnabled:false,adultEnabled:true,adDomains:['ads.example.com'],adultDomains:['adult.example.com']}).length,1);
assert.equal(filters.buildRules({communityEnabled:true,adEnabled:true,adultEnabled:false,adDomains:['ads.example.com'],adultDomains:['adult.example.com']}).length,1);
const manyAds=Array.from({length:filters.AD_LIMIT+500},(_,i)=>`ad${i}.example`);
assert.equal(filters.buildRules({adEnabled:true,adDomains:manyAds}).filter(r=>r.id>=filters.AD_ID_START).length,filters.AD_LIMIT);
const all=filters.buildRules({adEnabled:true,adultEnabled:true,adDomains:manyAds,adultDomains:Array.from({length:filters.ADULT_LIMIT+50},(_,i)=>`adult${i}.example`)});
assert.equal(all.length,filters.MAX_COMMUNITY_RULES);
assert.equal(new Set(all.map(r=>r.id)).size,all.length);
assert(all.every(r=>r.id>=filters.ADULT_ID_START&&r.id<filters.ID_END));
console.log('PASS  Community filter updater: safe parsing, bounded spread sampling, approved sources, independent toggles, reserved IDs and conservative request rules');
